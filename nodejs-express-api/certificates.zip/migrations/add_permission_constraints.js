/**
 * Migration Script: Add Unique Constraints to Permission Tables
 * 
 * This script adds unique constraints to prevent duplicate permissions.
 * Run this after deploying the updated models.
 * 
 * Usage: node migrations/add_permission_constraints.js
 */

import DB from '../models/db.js';
import { Sequelize } from 'sequelize';

async function migrate() {
    console.log('Starting permission constraints migration...');
    
    const queryInterface = DB.sequelize.getQueryInterface();
    
    try {
        // Add unique constraint to permissions table
        console.log('Adding unique constraint to permissions table...');
        await queryInterface.addConstraint('permissions', {
            fields: ['permission', 'role_id', 'user_id'],
            type: 'unique',
            name: 'unique_permission_role_user'
        });
        console.log('✓ Added unique constraint to permissions table');
    } catch (err) {
        if (err.message.includes('Duplicate key name') || err.code === 'ER_DUP_KEYNAME') {
            console.log('✓ Unique constraint already exists on permissions table');
        } else if (err.message.includes('already exists')) {
            console.log('✓ Unique constraint already exists on permissions table');
        } else {
            console.log('Note: Could not add constraint to permissions:', err.message);
        }
    }
    
    try {
        // Add unique constraint to role_permissions table
        console.log('Adding unique constraint to role_permissions table...');
        await queryInterface.addConstraint('role_permissions', {
            fields: ['role_id', 'page'],
            type: 'unique',
            name: 'unique_role_page'
        });
        console.log('✓ Added unique constraint to role_permissions table');
    } catch (err) {
        if (err.message.includes('Duplicate key name') || err.code === 'ER_DUP_KEYNAME') {
            console.log('✓ Unique constraint already exists on role_permissions table');
        } else if (err.message.includes('already exists')) {
            console.log('✓ Unique constraint already exists on role_permissions table');
        } else {
            console.log('Note: Could not add constraint to role_permissions:', err.message);
        }
    }
    
    try {
        // Add unique constraint to user_privileges table
        console.log('Adding unique constraint to user_privileges table...');
        await queryInterface.addConstraint('user_privileges', {
            fields: ['user_id', 'privilege'],
            type: 'unique',
            name: 'unique_user_privilege'
        });
        console.log('✓ Added unique constraint to user_privileges table');
    } catch (err) {
        if (err.message.includes('Duplicate key name') || err.code === 'ER_DUP_KEYNAME') {
            console.log('✓ Unique constraint already exists on user_privileges table');
        } else if (err.message.includes('already exists')) {
            console.log('✓ Unique constraint already exists on user_privileges table');
        } else {
            console.log('Note: Could not add constraint to user_privileges:', err.message);
        }
    }
    
    try {
        // Add unique constraint to assign_rights table
        console.log('Adding unique constraint to assign_rights table...');
        await queryInterface.addConstraint('assign_rights', {
            fields: ['permission'],
            type: 'unique',
            name: 'unique_assign_rights_permission'
        });
        console.log('✓ Added unique constraint to assign_rights table');
    } catch (err) {
        if (err.message.includes('Duplicate key name') || err.code === 'ER_DUP_KEYNAME') {
            console.log('✓ Unique constraint already exists on assign_rights table');
        } else if (err.message.includes('already exists')) {
            console.log('✓ Unique constraint already exists on assign_rights table');
        } else {
            console.log('Note: Could not add constraint to assign_rights:', err.message);
        }
    }
    
    console.log('\nMigration completed!');
    console.log('\nNote: If there were existing duplicates in your database,');
    console.log('you may need to manually clean them up before the constraints can be applied.');
    
    process.exit(0);
}

migrate().catch(err => {
    console.error('Migration failed:', err);
    process.exit(1);
});
