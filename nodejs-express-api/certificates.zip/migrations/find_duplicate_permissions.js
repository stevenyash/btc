/**
 * Utility Script: Find and Report Duplicate Permissions
 * 
 * This script finds all duplicate permissions in the database.
 * Run this before applying the unique constraints to see what needs to be cleaned up.
 * 
 * Usage: node migrations/find_duplicate_permissions.js
 */

import DB from '../models/db.js';
import { Sequelize } from 'sequelize';

async function findDuplicates() {
    console.log('Finding duplicate permissions...\n');
    
    // Find duplicate permissions
    console.log('=== Permissions Table ===');
    const [permResults] = await DB.sequelize.query(`
        SELECT permission, role_id, user_id, COUNT(*) as count
        FROM permissions
        GROUP BY permission, role_id, user_id
        HAVING COUNT(*) > 1
    `);
    
    if (permResults.length > 0) {
        console.log('Found duplicates:');
        console.table(permResults);
    } else {
        console.log('No duplicate permissions found.');
    }
    
    // Find duplicate role_permissions
    console.log('\n=== Role Permissions Table ===');
    const [rolePermResults] = await DB.sequelize.query(`
        SELECT role_id, page, COUNT(*) as count
        FROM role_permissions
        GROUP BY role_id, page
        HAVING COUNT(*) > 1
    `);
    
    if (rolePermResults.length > 0) {
        console.log('Found duplicates:');
        console.table(rolePermResults);
    } else {
        console.log('No duplicate role permissions found.');
    }
    
    // Find duplicate user_privileges
    console.log('\n=== User Privileges Table ===');
    const [userPrivResults] = await DB.sequelize.query(`
        SELECT user_id, privilege, COUNT(*) as count
        FROM user_privileges
        GROUP BY user_id, privilege
        HAVING COUNT(*) > 1
    `);
    
    if (userPrivResults.length > 0) {
        console.log('Found duplicates:');
        console.table(userPrivResults);
    } else {
        console.log('No duplicate user privileges found.');
    }
    
    // Find duplicate assign_rights
    console.log('\n=== Assign Rights Table ===');
    const [assignRightsResults] = await DB.sequelize.query(`
        SELECT permission, COUNT(*) as count
        FROM assign_rights
        GROUP BY permission
        HAVING COUNT(*) > 1
    `);
    
    if (assignRightsResults.length > 0) {
        console.log('Found duplicates:');
        console.table(assignRightsResults);
    } else {
        console.log('No duplicate assign rights found.');
    }
    
    console.log('\nDone!');
    process.exit(0);
}

findDuplicates().catch(err => {
    console.error('Error:', err);
    process.exit(1);
});
