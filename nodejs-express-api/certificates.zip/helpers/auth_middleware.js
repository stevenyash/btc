import passport from 'passport';


import Rbac from './rbac.js';


import passportLogin from './passport-auth.js';


const publicPages = ['auth', 'components_data','s3Sync' ,'fileuploader', 's3uploader', 'home','services','products','subscribe','viewlessons','guide','customlogin','subscriptionshow','buypackages','guestlessons','guestclass','guestwatching','weekendtutorials','oauthcallback','aboutus','contactus','newslettersubscribers/add','questions/add','transactions/add','users/subscribeuser','tutorialssettings','learningareas/index','grades/index','lessons/index','topics/index','subtopics/index','learninglevels/index','lessons/stream-url','migrationroutes/index','migrationroutes/syncstatus','migrationroutes/syncfolders','migrationroutes/syncvideos','userprivileges/index','userprivileges/available-privileges','userprivileges/user','userprivileges/view','userprivileges/edit','userprivileges/delete','users/index','users/view'];



async function passportJwtLogin (req, res, next) {


    passportLogin();


    passport.authenticate('jwt', async (err, user, info) => {


        req.login(user, { session: false }, async (error) => { });


        return next();


    }

    )(req, res, next);


}



async function authMiddleware(req, res, next) {


    try {


        if (req.user) {


            const userRoleId = req.user.user_role_id;


            const userId = req.user.id; // Get the user ID from req.user


            const rbac = new Rbac(userRoleId, userId); // Pass userId to Rbac


            await rbac.getUserPages(); // Fetch user-specific and global permissions


            const pageAccess = await rbac.getPageAccess(req.path);


            const roleName = await rbac.getRoleName();


            req.pageAccess = pageAccess;


            req.userRoleId = userRoleId;


            req.userRoleName = roleName;


            // Store role permissions for CRUD access checking
            req.rolePermissions = rbac.rolePermissions;


            // Helper method to check specific CRUD permission for a page
            req.hasPermission = (page, action) => {
                return rbac.hasPermission(page, action);
            };


            // Store userPages for backward compatibility
            req.userPages = rbac.userPages;


            switch (roleName) {


                case 'admin':


                    req.isAdmin = true;


                    break;


                case 'subscriber':


                    req.isSubscriber = true;


                    break;


                case 'marketer':


                    req.isMarketer = true;


                    break;


                case 'teacher':


                    req.isTeacher = true;


                    break;


                case 'superadmin':


                    req.isSuperadmin = true;


                    break;


                default:


                    req.isGuest = true;


            }


        }



        const arrPath = req.path.split('/').filter(Boolean);


        const page = arrPath[0];


        const action = arrPath[1] || 'index';


        const pagePath = `${page}/${action}`;


        const isPublicPage = publicPages.includes(pagePath) || publicPages.includes(page);

        if (isPublicPage || req.pageAccess == Rbac.AUTHORIZED || req.isSuperadmin) {

            return next();

        } else if (req.pageAccess == Rbac.FORBIDDEN) {

            return res.forbidden();

        } else if (req.pageAccess == Rbac.UNKNOWN_ROLE) {

            return res.forbidden('Unknown Role');

        }

        return res.unauthorized();


    } catch (err) {


        return res.serverError(err);


    }



}



export { passportJwtLogin, authMiddleware };
