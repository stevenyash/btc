import DB from '../models/db.js';

/**
 * Role Based Access Control
 * @category  RBAC Helper
 */

let excludePages = ['account', 'components_data', 'upload', 'services','']; // Pages to exclude from access authorization check

class Rbac {
    static AUTHORIZED = "authorized";
    static FORBIDDEN = "forbidden";
    static UNKNOWN_ROLE = "unknown_role";

    userPages = [];
    userRoleId = null;
    userId = null; // Add user ID for user-specific permission checking
    rolePermissions = {}; // Store page CRUD permissions from role_permissions table

    constructor(role, userId = null) { // Accept userId as optional
        this.userRoleId = role;
        this.userId = userId; // Store userId
    }

    async getUserPages() {
        if (this.userRoleId) {
            try {
                // Fetch global permissions (user_id = 0)
                const globalPermissions = await DB.Permissions.findAll({
                    where: {
                        role_id: this.userRoleId,
                        user_id: 0
                    },
                    attributes: ['permission']
                });
console.log('Global permissions fetched:', globalPermissions);
                // Fetch user-specific permissions (if userId is provided)
                let userPermissions = [];
                if (this.userId) {
                    userPermissions = await DB.Permissions.findAll({
                        where: {
                            role_id: this.userRoleId,
                            user_id: this.userId
                        },
                        attributes: ['permission']
                    });
                }
console.log('User-specific permissions fetched:', userPermissions);
                // Fetch user-specific privileges from user_privileges table
                // These are privileges granted by Super Admin that extend beyond role permissions
                let userPrivileges = [];
                if (this.userId) {
                    try {
                        userPrivileges = await DB.UserPrivileges.findAll({
                            where: {
                                user_id: this.userId,
                                is_active: true
                            },
                            attributes: ['privilege']
                        });
                    } catch (ex) {
                        console.error('Error fetching user privileges:', ex);
                        // Table might not exist yet, continue without user privileges
                    }
                }
console.log('User privileges fetched:', userPrivileges);
                // Merge global, user-specific permissions, and user privileges
                this.userPages = [
                    ...globalPermissions.map(e => e.permission),
                    ...userPermissions.map(e => e.permission),
                    ...userPrivileges.map(e => e.privilege)
                ];

                // Fetch role permissions from role_permissions table for page-based CRUD
                try {
                    const rolePerms = await DB.RolePermissions.findAll({
                        where: {
                            role_id: this.userRoleId
                        },
                        raw: true
                    });
                 console.log('Role permissions fetched:', rolePerms);   
                    // Store as object for easy lookup: { page: { list: 1, edit: 1, ... } }
                    this.rolePermissions = rolePerms.reduce((acc, perm) => {
                        acc[perm.page] = {
                            list: perm.list,
                            edit: perm.edit,
                            remove: perm.remove,
                            view: perm.view,
                            store: perm.store
                        };
                        console.log(`Processed role permission for page: ${perm.page}`, acc[perm.page]);
                        return acc;
                    }, {});
                } catch (ex) {
                    console.error('Error fetching role permissions:', ex);
                    // Table might not exist yet, continue without role permissions
                }
            } catch (ex) {
                console.error('Error fetching user pages:', ex);
            }
        }
        return this.userPages;
    }

    async getRoleName() {
        let roleName = '';
        if (this.userRoleId) {
            try {
                roleName = await DB.Roles.findValue('role_name', { role_id: this.userRoleId });
                roleName = (roleName || '').toLowerCase();
                console.log('Fetched role name:', roleName);
            } catch (ex) {
                console.error('Error fetching role name:', ex);
            }
        }
        return roleName;
    }

    async getPageAccess(path) {
        path = path.replace(/^\/|\/$/g, ''); // Trim slashes
        let arrPath = path.split("/");
        let page = arrPath[0];

        if (excludePages.includes(page)) {
            return Rbac.AUTHORIZED; // Always authorize excluded pages
        }

        let action = (arrPath[1] ? arrPath[1] : "index");

        // Map actions to CRUD permissions
        const actionToPermission = {
            'index': 'list',
            'list': 'list',
            'view': 'view',
            'add': 'store',
            'edit': 'edit',
            'delete': 'remove',
            'update': 'edit',
            'create': 'store',
            'grant': 'store',
            'grant-multiple': 'store',
            'revoke': 'edit',
            'revoke-all': 'remove'
        };

        // Normalize action for permission lookup
        let normalizedAction = actionToPermission[action] || action;

        if (this.userRoleId) {
            // First check specific permissions table (e.g., "users/add", "users/delete")
            const specificPermission = `${page}/${action}`;
            console.log('Checking specific permission:', specificPermission);
            if (this.userPages.includes(specificPermission)) {
                console.log('Permission GRANTED via specific permission:', specificPermission);
                return Rbac.AUTHORIZED;
            }

            // Also check without action (page-level permission)
            if (this.userPages.includes(page)) {
                console.log('Page-level permission found for page:', page);
                return Rbac.AUTHORIZED;
            }

            // Check role_permissions table for page CRUD permissions
            if (this.rolePermissions[page]) {
                const pagePerm = this.rolePermissions[page];
                // Check if the action's corresponding permission is granted
                console.log('Checking role permission for page:', page, 'action:', action, '-> normalized to:', normalizedAction, 'permission value:', pagePerm[normalizedAction]);
                if (pagePerm[normalizedAction] === 1) {
                    console.log('Role permission GRANTED for page:', page, 'action:', normalizedAction);
                    return Rbac.AUTHORIZED;
                }
                if (action === 'index' && pagePerm.list === 1) {
                    console.log('Role permission granted for page:', page, 'action: index via list permission');    
                    return Rbac.AUTHORIZED;
                }
            }

            // Dynamic permission handling for superadmin
            if (this.userRoleId === 3) { // Assuming 1 is the superadmin role ID
                // Check if permission exists, if not add it to the table
                const permissionExists = await DB.Permissions.findOne({
                    where: {
                        permission: specificPermission,
                        role_id: this.userRoleId
                    }
                });
                if (!permissionExists) {
                    try {
                        await DB.Permissions.create({
                            permission: specificPermission,
                            role_id: this.userRoleId,
                            user_id: 0 // Global permission
                        });
                        console.log('Added missing permission to table:', specificPermission);
                    } catch (ex) {
                        console.error('Error adding permission:', ex);
                    }
                }
                return Rbac.AUTHORIZED;
            }

            return Rbac.FORBIDDEN;
        } else {
            return Rbac.UNKNOWN_ROLE;
        }
    }

    /**
     * Check if user has specific permission for a page
     * @param {string} page - Page name
     * @param {string} action - Action (list, view, add, edit, delete)
     * @returns {boolean}
     */
    hasPermission(page, action) {
        const normalizedAction = action.toLowerCase();
        console.log('Checking permission for page:', page, 'action:', normalizedAction);
        // Check specific permissions
        const specificPermission = `${page}/${action}`;
        console.log('Specific permission to check:', specificPermission);
        if (this.userPages.includes(specificPermission)) {
            console.log('Specific permission granted for:', specificPermission);
            return true;
        }

        // Check role_permissions
        if (this.rolePermissions[page]) {
            console.log('Checking role permissions for page:', page);
            const pagePerm = this.rolePermissions[page];
            if (pagePerm[normalizedAction] === 1) {
                console.log('Role permission granted for page:', page, 'action:', normalizedAction);
                return true;
            }
        }

        return false;
    }
}

export default Rbac;
