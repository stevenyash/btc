import DB from '../models/db.js';

/**
 * Role Based Access Control
 * @category  RBAC Helper
 */

let excludePages = ['account', 'components_data', 'upload', 'services']; // Pages to exclude from access authorization check

class Rbac {
    static AUTHORIZED = "authorized";
    static FORBIDDEN = "forbidden";
    static UNKNOWN_ROLE = "unknown_role";

    userPages = [];
    userRoleId = null;
    userId = null; // Add user ID for user-specific permission checking

    constructor(role, userId = null) { // Accept userId as optional
        this.userRoleId = role;
        this.userId = userId; // Store userId
    }

    async getUserPages() {
        if (this.userRoleId) {
            try {
                // Fetch global permissions (user_id = 0)
                const globalPermissions = await DB.Permissions.findAll({
                    where: {
                        role_id: this.userRoleId,
                        user_id: 0
                    },
                    attributes: ['permission']
                });

                // Fetch user-specific permissions (if userId is provided)
                let userPermissions = [];
                if (this.userId) {
                    userPermissions = await DB.Permissions.findAll({
                        where: {
                            role_id: this.userRoleId,
                            user_id: this.userId
                        },
                        attributes: ['permission']
                    });
                }

                // Merge global and user-specific permissions
                this.userPages = [
                    ...globalPermissions.map(e => e.permission),
                    ...userPermissions.map(e => e.permission)
                ];

            } catch (ex) {
                console.error('Error fetching user pages:', ex);
            }
        }
        return this.userPages;
    }


    async getRoleName() {
        let roleName = '';
        if (this.userRoleId) {
            try {
                roleName = await DB.Roles.findValue('role_name', { role_id: this.userRoleId });
                roleName = (roleName || '').toLowerCase();
            } catch (ex) {
                console.error('Error fetching role name:', ex);
            }
        }
        return roleName;
    }

    getPageAccess(path) {
        path = path.replace(/^\/|\/$/g, ''); // Trim slashes
        let arrPath = path.split("/");
        let page = arrPath[0];

        if (excludePages.includes(page)) {
            return Rbac.AUTHORIZED; // Always authorize excluded pages
        }
        let action = (arrPath[1] ? arrPath[1] : "index");

        if (this.userRoleId) {
            if (this.userPages.includes(`${page}/${action}`)) {
                return Rbac.AUTHORIZED; // Authorized access
            } else {
                return Rbac.FORBIDDEN; // Forbidden access
            }
        } else {
            return Rbac.UNKNOWN_ROLE; // No role assigned
        }
    }
}

export default Rbac;