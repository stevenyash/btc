import { google } from "googleapis";

import fs from "fs/promises";

import path from "path";

import process from "process";

import { OAuth2Client } from "google-auth-library"; // Import OAuth2Client



// Scopes for Calendar and Meet access

const SCOPES = [

    "https://www.googleapis.com/auth/calendar",

    "https://www.googleapis.com/auth/calendar.events",

];



const CREDENTIALS_PATH = path.join(process.cwd(), "credentials.json");

const TOKEN_PATH = path.join(process.cwd(), "token.json");



// Function to load existing credentials from a file

async function loadSavedCredentials() {

    try {

        const content = await fs.readFile(TOKEN_PATH, "utf8");

        const credentials = JSON.parse(content);

        if (!credentials.refresh_token) {

            console.log("No refresh token found in saved credentials");

            return null; //  Return null, don't throw.  authorize() will handle.

        }

        const client = google.auth.fromJSON(credentials);

        // Set up automatic token refresh

        client.on('tokens', (tokens) => {

            if (tokens.refresh_token) {

                console.log('New refresh token received, saving...');

                saveCredentials(client).catch(err => {

                    console.error('Failed to save new tokens:', err);

                });

            }

        });

        return client;

    } catch (err) {

        console.log("Loading credentials failed:", err.message);

        return null;

    }

}



// Function to save credentials to a file

async function saveCredentials(client) {

    const content = await fs.readFile(CREDENTIALS_PATH, "utf8");

    const keys = JSON.parse(content);

    const key = keys.installed || keys.web;



    if (!client.credentials || !client.credentials.refresh_token) {

        throw new Error("Missing refresh token in client credentials");

    }

    const payload = {

        type: "authorized_user",

        client_id: key.client_id,

        client_secret: key.client_secret,

        refresh_token: client.credentials.refresh_token,

    };

    await fs.writeFile(TOKEN_PATH, JSON.stringify(payload, null, 2));

    console.log("Credentials saved with refresh token");

}



let oauth2Client; // Declare it outside the functions



// Function to authorize the client and get the URL

async function getAuthUrl() {

    const credentialsContent = await fs.readFile(CREDENTIALS_PATH, "utf8");

    const credentials = JSON.parse(credentialsContent);

    const { client_id, client_secret, redirect_uris } =

        credentials.web || credentials.installed;

    const redirectUri = redirect_uris[0];



    oauth2Client = new OAuth2Client({

        clientId: client_id,

        clientSecret: client_secret,

        redirectUri: redirectUri,

    });



    const authUrl = oauth2Client.generateAuthUrl({

        access_type: "offline",

        scope: SCOPES,

        prompt: "consent",

    });

    return authUrl;

}



// Function to get the oAuth2Client

async function getOAuthClient() {

    try {

        const credentialsContent = await fs.readFile(CREDENTIALS_PATH, "utf8");

        const credentials = JSON.parse(credentialsContent);

        const { client_id, client_secret, redirect_uris } =

            credentials.web || credentials.installed;

        const redirectUri = redirect_uris[0];



        const oauth2Client = new OAuth2Client({

            clientId: client_id,

            clientSecret: client_secret,

            redirectUri: redirectUri,

        });

        return oauth2Client;

    } catch (error) {

        console.error("Error getting OAuth client:", error);

        throw error;

    }

}

// Exchange code for tokens

async function exchangeCodeForTokens(code) {

    if (!oauth2Client) {

        const credentialsContent = await fs.readFile(CREDENTIALS_PATH, "utf8");

        const credentials = JSON.parse(credentialsContent);

        const { client_id, client_secret, redirect_uris } =

            credentials.web || credentials.installed;

        const redirectUri = redirect_uris[0];

        oauth2Client = new OAuth2Client({

            clientId: client_id,

            clientSecret: client_secret,

            redirectUri: redirectUri,

        });

    }

    const tokenResponse = await oauth2Client.getToken(code);

    oauth2Client.setCredentials(tokenResponse.tokens);

    await saveCredentials(oauth2Client);

    return oauth2Client;

}



// Function to authorize the client (either load from file or authenticate)

async function authorize() {

    let client = await loadSavedCredentials();

    if (client) {

        try {

            // Try to get access token - this will automatically refresh if needed

            const tokenInfo = await client.getAccessToken();

            console.log("Successfully authorized with existing credentials");

            return client;

        } catch (e) {

            console.error("Error with previous token:", e.message);

            console.log("Token may be expired or invalid. Attempting to refresh...");

            

            // Try to refresh the token explicitly

            try {

                await client.refreshAccessToken();

                console.log("Token refreshed successfully");

                return client;

            } catch (refreshError) {

                console.error("Token refresh failed:", refreshError.message);

                console.log("Re-authorization required");

            }

        }

    }

    //if no saved credentials or refresh failed

    const authUrl = await getAuthUrl();

    console.error(

        `\n========================================`

    );

    console.error(

        `GOOGLE AUTHENTICATION REQUIRED`

    );

    console.error(

        `========================================`

    );

    console.error(

        `Please visit this URL to authorize your application:`

    );

    console.error(

        `${authUrl}`

    );

    console.error(

        `========================================\n`

    );

    throw new Error(

        `Google Calendar authorization required. Please visit the authorization URL and complete the OAuth flow. Auth URL: ${authUrl}`

    );

}



// Function to create a Google Meet meeting

async function createMeetEvent({

    summary = "Google Meet Meeting",

    description = "",

    startTime,

    endTime,

    timeZone = "UTC",

    hostemail

}) {

    try {

        // Validate required fields

        if (!hostemail) {

            throw new Error("Host email is required");

        }

        if (!startTime || !endTime) {

            throw new Error("Both startTime and endTime are required");

        }



        const auth = await authorize();

        const calendar = google.calendar({ version: "v3", auth });



        // Convert and validate times

        const startDateTime = new Date(startTime);

        const endDateTime = new Date(endTime);



        if (isNaN(startDateTime.getTime())) {

            throw new Error("Invalid startTime format");

        }

        if (isNaN(endDateTime.getTime())) {

            throw new Error("Invalid endTime format");

        }

        if (startDateTime >= endDateTime) {

            throw new Error("End time must be after start time");

        }



        // Create the event

        const event = {

            summary,

            description,

            start: {

                dateTime: startDateTime.toISOString(),

                timeZone: timeZone,

            },

            end: {

                dateTime: endDateTime.toISOString(),

                timeZone: timeZone,

            },

            attendees: [{ email: hostemail }],

            conferenceData: {

                createRequest: {

                    requestId: `meet-${Date.now()}`,

                    conferenceSolutionKey: { type: "hangoutsMeet" },

                },

            },

        };



        const res = await calendar.events.insert({

            calendarId: "primary",

            resource: event,

            conferenceDataVersion: 1,

        });



        // Return the essential meeting information

        return {

            success: true,

            meetingUrl: res.data.hangoutLink,

            eventId: res.data.id,

            start: res.data.start || {

                dateTime: startTime,

                timeZone: timeZone

            },

            end: res.data.end || {

                dateTime: endTime,

                timeZone: timeZone

            },

            htmlLink: res.data.htmlLink,

            conferenceData: res.data.conferenceData

        };

    } catch (error) {

        console.error("Error in createMeetEvent:", error);

        console.error("Error details:", {

            message: error.message,

            code: error.code,

            status: error.response?.status,

            statusText: error.response?.statusText,

            data: error.response?.data

        });



        // Provide more specific error messages

        let errorMessage = error.message;

        

        if (error.message.includes("Authorization required") || error.message.includes("authorization")) {

            errorMessage = "Google Calendar authorization is required. Please complete the OAuth flow first.";

        } else if (error.code === 'ENOENT') {

            errorMessage = "Google credentials file not found. Please ensure credentials.json exists.";

        } else if (error.response?.status === 401) {

            errorMessage = "Google authentication failed. Token may be expired or invalid.";

        } else if (error.response?.status === 403) {

            errorMessage = "Permission denied. Please ensure the Google Calendar API is enabled and you have the necessary permissions.";

        } else if (error.response?.status === 404) {

            errorMessage = "Google Calendar not found. Please check the calendar ID.";

        }



        // Return error information in a consistent format

        return {

            success: false,

            error: errorMessage,

            originalError: error.message,

            details: error.response?.data || null

        };

    }

}

export {

    createMeetEvent,

    getAuthUrl,

    exchangeCodeForTokens,

    authorize,

    loadSavedCredentials,

    saveCredentials,

    getOAuthClient,

};

