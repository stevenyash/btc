import DB from '../models/db.js';

/**
 * Award commission to marketer when a referred user makes a purchase
 * @param {object} transaction - The transaction record
 * @param {number} userId - The user who made the purchase
 * @param {string} purchaseType - 'subscription', 'package', or 'tutorial'
 */
async function awardCommission(transaction, userId, purchaseType) {
    try {
        // 1. Look up user's referred_by
        const user = await DB.Users.findOne({ where: { id: userId } });
        if (!user || !user.referred_by || user.referred_by === 'NULL') return;

        // 2. Find marketer by referral code
        const marketer = await DB.Marketers.findOne({ where: { referral_code: user.referred_by } });
        if (!marketer) return;

        // 3. Get commission rate (marketer-specific or global default)
        let commissionRate = parseFloat(marketer.commission_rate);
        if (!commissionRate || commissionRate <= 0) {
            const setting = await DB.SystemSettings.findOne({ where: { setting_key: 'default_commission_rate' } });
            commissionRate = parseFloat(setting?.setting_value || '0.10');
        }

        // 4. Calculate commission
        const purchaseAmount = parseFloat(transaction.amount);
        const commissionAmount = Math.round(purchaseAmount * commissionRate * 100) / 100;

        // 5. Record commission
        await DB.MarketerCommissions.create({
            marketer_id: marketer.id,
            user_id: userId,
            transaction_id: transaction.id,
            purchase_type: purchaseType,
            purchase_amount: purchaseAmount,
            commission_rate: commissionRate,
            commission_amount: commissionAmount,
            status: 'approved'
        });

        // 6. Update marketer earnings
        await DB.Marketers.increment(
            { total_earnings: commissionAmount, pending_earnings: commissionAmount },
            { where: { id: marketer.id } }
        );

        console.log(`[Commission] Awarded ${commissionAmount} to marketer ${marketer.id} for ${purchaseType}`);
        return { marketer_id: marketer.id, commission_amount: commissionAmount };
    } catch (err) {
        console.error('[Commission Error]', err.message);
        return null;
    }
}

export { awardCommission };
