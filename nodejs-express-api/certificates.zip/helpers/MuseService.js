import { apiKey, baseURL } from '../muse.config.js';

import axios from 'axios';

import FormData from 'form-data';

import fs from 'fs';

import path from 'path';





// Muse.ai API Configuration

const MUSE_API_KEY = apiKey;

const BASE_URL = baseURL;



// Axios instance for Muse.ai

const museApi = axios.create({

    baseURL: BASE_URL,

    headers: {

        Key: MUSE_API_KEY,

    },

    timeout: 30000000, // 5 seconds

});





// Upload a video





export async function uploadVideo(filePath, fileName, options = {}) {

        // Resolve and verify the file path

        const resolvedFilePath = path.resolve(`assets/${filePath}`);

  const {

    collection,

    visibility = 'private',

    title,

    description,

    category,

    parent,

    customFields = {},

  } = options;



  try {



    console.log('Resolved File Path:', resolvedFilePath);



    if (!fs.existsSync(resolvedFilePath)) {

      throw new Error(`File not found at path: ${resolvedFilePath}`);

    }



    // Prepare the form data

    const form = new FormData();

    form.append('file', fs.createReadStream(resolvedFilePath), fileName);



    // Add optional fields

    if (collection) form.append('collection', collection);

    if (visibility) form.append('visibility', visibility);

    if (title) form.append('title', title);

    if (description) form.append('description', description);

    if (category) form.append('category', category);

  

form.append('domains',"*bitstutorconnect.co.ke");

    // Add custom fields dynamically



    Object.entries(customFields).forEach(([key, value]) => {

      form.append(key, value);

    });



    // Send request to Muse API

    console.log(form)

    const response = await museApi.post('/upload', form, {

      headers: {...form.getHeaders()},

    });



    console.log('Upload successful:', response.data);

    return response.data;

  } catch (error) {

    console.error('Error uploading video:', error.message);

    throw error;

  }

}





// Cut a clip

export async function cutVideo(lesson_id, start, end) {

    const form = new FormData();

    form.append('lesson_id', lesson_id);

    form.append('start', start);

    form.append('end', end);



    try {

        const response = await museApi.post('/cut', form, {

            headers: form.getHeaders(),

        });

        return response.data;

    } catch (error) {

        console.error('Error cutting video:', error);

        throw error;

    }

}



// List all videos

export async function listLearningAreas

    try {

        const response = await museApi.get('/videos');

        return response.data;

    } catch (error) {

        console.error('Error listing videos:', error);

        throw error;

    }

}



// Get a specific video

export async function getVideo(lesson_id) {

    try {

        const response = await museApi.get(`/videos/${lesson_id}`);

        return response.data;

    } catch (error) {

        console.error('Error getting video details:', error);

        throw error;

    }

}



// Delete a video

export async function deleteVideo(fid) {

    try {

        const response = await museApi.delete(`/delete/${fid}`);

        return response.data;

    } catch (error) {

        console.error('Error deleting video:', error);

        throw error;

    }

}



// Update video details

export async function updateVideo(fid, data) {

    try {

        const response = await museApi.post(`/set/${fid}`, data);

        return response.data;

    } catch (error) {

        console.error('Error updating video:', error);

        throw error;

    }

}



// Upload subtitles

export async function uploadSubtitles(lesson_id, subtitlePath, subtitleName) {

    const form = new FormData();

    form.append('subtitles', fs.createReadStream(subtitlePath), subtitleName);



    try {

        const response = await museApi.post(`/subtitles/${lesson_id}`, form, {

            headers: form.getHeaders(),

        });

        return response.data;

    } catch (error) {

        console.error('Error uploading subtitles:', error);

        throw error;

    }

}



// List subtitles

export async function listSubtitles(lesson_id) {

    try {

        const response = await museApi.get(`/subtitles/${lesson_id}`);

        return response.data;

    } catch (error) {

        console.error('Error listing subtitles:', error);

        throw error;

    }

}



// Delete subtitles

export async function deleteSubtitles(lesson_id, subtitleId) {

    try {

        const response = await museApi.post(`/subtitles/${lesson_id}/${subtitleId}/delete`);

        return response.data;

    } catch (error) {

        console.error('Error deleting subtitles:', error);

        throw error;

    }

}



// Update thumbnail

export async function updateThumbnail(fid, thumbnailPath) {

    const form = new FormData();

    form.append('file', fs.createReadStream(thumbnailPath));



    try {

        const response = await museApi.post(`/set/${fid}/cover`, form, {

            headers: form.getHeaders(),

        });

        return response.data;

    } catch (error) {

        console.error('Error updating thumbnail:', error);

        throw error;

    }

}

// List collections

export async function listCollections() {

   

    try {

        const response = await museApi.get('/collections');



        return response.data;

    } catch (error) {

        console.log('Error listing collections:', error);

        throw error;

    }

}



// Get a collection

export async function getCollection(scid) {

    try {

        const response = await museApi.get(`/collections/${scid}`);

        return response.data;

    } catch (error) {

        console.error('Error getting collection:', error);

        throw error;

    }

}



// Create a collection

export async function createCollection(formData) {

    try {

        console.log('Creating collection with:', formData);

        const response = await museApi.post('/collections',  formData);

        console.log('Response:', response.data);

        return response.data;

    } catch (error) {

        console.error('Error creating collection:', {

            message: error.message,

            status: error.response?.status,

            data: error.response?.data,

        });

        throw error;

    }

}





// Delete a collection

export async function deleteCollection(scid) {

    try {

        const response = await museApi.delete(`/collections/${scid}`);

        return response.data;

    } catch (error) {

        console.error('Error deleting collection:', error);

        throw error;

    }

}



// Add a video to a collection

export async function addVideoToCollection(scid, lesson_id) {

    try {

        const response = await museApi.post(`/collections/${scid}/add`, { lesson_id });

        return response.data;

    } catch (error) {

        console.error('Error adding video to collection:', error);

        throw error;

    }

}



// Remove a video from a collection

export async function removeVideoFromCollection(scid, lesson_id) {

    try {

        const response = await museApi.delete(`/collections/${scid}/${lesson_id}`);

        return response.data;

    } catch (error) {

        console.error('Error removing video from collection:', error);

        throw error;

    }

}

// Search owned videos

export async function searchOwnedVideos(query) {

    try {

        const response = await museApi.get('/search', {

            params: { q: query },

        });

        return response.data;

    } catch (error) {

        console.error('Error searching owned videos:', error);

        throw error;

    }

}



// Search channel

export async function searchChannel(channelId, query) {

    try {

        const response = await museApi.get(`/search/channel/${channelId}`, {

            params: { q: query },

        });

        return response.data;

    } catch (error) {

        console.error('Error searching channel:', error);

        throw error;

    }

}



// Search public collection

export async function searchPublicCollection(collectionId, query) {

    try {

        const response = await museApi.get(`/search/collection/${collectionId}`, {

            params: { q: query },

        });

        return response.data;

    } catch (error) {

        console.error('Error searching public collection:', error);

        throw error;

    }

}



// Search public video

export async function searchPublicVideo(videoId, query) {

    try {

        const response = await museApi.get(`/search/video/${videoId}`, {

            params: { q: query },

        });

        return response.data;

    } catch (error) {

        console.error('Error searching public video:', error);

        throw error;

    }

}