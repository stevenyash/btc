import axios from "axios";

import mpesaConfig from "../mpesaconfig.js";
import config from "../config.js";
import moment from "moment";
import crypto from "crypto";
import fs from "fs";

class MpesaService {

  constructor() {
    this.consumerKey = mpesaConfig.mpesa.APP_KEY;
    this.consumerSecret = mpesaConfig.mpesa.APP_SECRET;
    this.organizationShortCode = mpesaConfig.mpesa.SHORTCODE;
    this.passKey = mpesaConfig.mpesa.LNM_PASSKEY;
    this.environment = "production";
    this.InitiatorName = mpesaConfig.mpesa.INITIATOR_NAME || "bitstutorconnect";
    this.securityCredential = mpesaConfig.mpesa.SECURITY_CREDENTIAL;
  }

  /**
   * Generate Security Credential for B2C, reversal, etc.
   * This encrypts the initiator password with the M-Pesa public certificate
   * @returns {string} - Encrypted security credential
   */
  generateSecurityCredential() {
    try {
      const certificatePath = mpesaConfig.mpesa.CERTIFICATE_PATH;
      const password = mpesaConfig.mpesa.INITPASSWORD;
      
      if (!fs.existsSync(certificatePath)) {
        console.error(`Certificate not found at ${certificatePath}`);
        console.log("Please download the M-Pesa certificate from Safaricom Developer Portal");
        return "";
      }

      const certificate = fs.readFileSync(certificatePath, 'utf8');
      const encrypted = crypto.publicEncrypt(
        {
          key: certificate,
          padding: crypto.constants.RSA_PKCS1_PADDING
        },
        Buffer.from(password)
      );
      
      return encrypted.toString('base64');
    } catch (error) {
      console.error("Error generating security credential:", error);
      return "";
    }
  }

  /**
   * Get or generate security credential
   */
  getSecurityCredential() {
    if (this.securityCredential) {
      return this.securityCredential;
    }
    return this.generateSecurityCredential();
  }



  async getAccessToken() {

    const auth = Buffer.from(`${this.consumerKey}:${this.consumerSecret}`).toString("base64");

    try {

      const response = await axios.get(

        `https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials`,

        { headers: { Authorization: `Basic ${auth}` } }

      );

      return response.data.access_token;

    } catch (error) {

      console.error("Error fetching access token:", error);

      throw new Error("Failed to obtain access token.");

    }

  }



  async lipaNaMpesaOnline(amount, phoneNumber, callback_Url) {

    const timestamp = moment().format("YYYYMMDDHHmmss");

    const password = Buffer.from(

      `${this.organizationShortCode}${this.passKey}${timestamp}`

    ).toString("base64");

    const callbackUrl = `${config.app.url}/api/${callback_Url}`;

    const accessToken = await this.getAccessToken();

    

    const payload = {

      BusinessShortCode: this.organizationShortCode,

      Password: password,

      Timestamp: timestamp,

      TransactionType: "CustomerPayBillOnline",

      Amount: amount,

      PartyA: phoneNumber,

      PartyB: this.organizationShortCode,

      PhoneNumber: phoneNumber,

      CallBackURL: callbackUrl,

      AccountReference: "btc",

      TransactionDesc: "Payment"

    };



    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

     // console.log(response.data)

      return response.data;

    } catch (error) {

      console.error("STK Push Error:", error);

      return { error: "An error occurred while initiating the payment." };

    }

  }



  async queryStkStatus(checkoutRequestID) {

    const timestamp = moment().format("YYYYMMDDHHmmss");

    const password = Buffer.from(

      `${this.organizationShortCode}${this.passKey}${timestamp}`

    ).toString("base64");

    const accessToken = await this.getAccessToken();



    const payload = {

      BusinessShortCode: this.organizationShortCode,

      Password: password,

      Timestamp: timestamp,

      CheckoutRequestID: checkoutRequestID

    };



    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/stkpushquery/v1/query",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      console.log(response.data)

      return response.data;

    } catch (error) {

      console.error("STK Query Error:", error);

      return { error: "An error occurred while querying the STK status." };

    }

  }



  async simulateC2B(amount, phoneNumber, accountNumber) {

    const accessToken = await this.getAccessToken();

    const payload = {

      ShortCode: this.organizationShortCode,

      CommandID: "CustomerPayBillOnline",

      Amount: amount,

      Msisdn: phoneNumber,

      BillRefNumber: accountNumber

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/c2b/v1/simulate",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("C2B Simulation Error:", error);

      return { error: "An error occurred while simulating the C2B transaction." };

    }

  }

  

  async registerC2BUrls(confirmationURL, validationURL) {

    const accessToken = await this.getAccessToken();

    const payload = {

      ShortCode: this.organizationShortCode,

      ResponseType: "Completed",

      ConfirmationURL: confirmationURL,

      ValidationURL: validationURL

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/c2b/v1/registerurl",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("C2B Register URL Error:", error);

      return { error: "An error occurred while registering C2B URLs." };

    }

  }



  async b2cTransfer(amount, phoneNumber, resultURL, timeoutURL) {



    const accessToken = await this.getAccessToken();



    const securityCredential = this.getSecurityCredential();
    if (!securityCredential) {
      return { error: "Security credential not configured. Please set up the M-Pesa certificate." };
    }

    const payload = {



      InitiatorName: this.InitiatorName,



      SecurityCredential: securityCredential,



      CommandID: "BusinessPayment",

      Amount: amount,

      PartyA: this.organizationShortCode,

      PartyB: phoneNumber,

      Remarks: "Payment",

      QueueTimeOutURL: timeoutURL,

      ResultURL: resultURL,

      Occasion: ""

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/b2c/v1/paymentrequest",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("B2C Transfer Error:", error);

      return { error: "An error occurred while initiating B2C transfer." };

    }

  }



  async queryTransactionStatus(transactionID, resultURL, timeoutURL) {



    const accessToken = await this.getAccessToken();



    const payload = {



      Initiator: this.InitiatorName,



      SecurityCredential: this.securityCredential,

      CommandID: "TransactionStatusQuery",

      TransactionID: transactionID,

      PartyA: this.organizationShortCode,

      IdentifierType: "4",

      ResultURL: resultURL,

      QueueTimeOutURL: timeoutURL,

      Remarks: "Transaction Status Query",

      Occasion: ""

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/transactionstatus/v1/query",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("Transaction Status Error:", error);

      return { error: "An error occurred while querying the transaction status." };

    }

  }



  async getAccountBalance(resultURL, timeoutURL) {



    const accessToken = await this.getAccessToken();



    const payload = {



      Initiator: this.InitiatorName,



      SecurityCredential: this.securityCredential,

      CommandID: "AccountBalance",

      PartyA: this.organizationShortCode,

      IdentifierType: "4",

      Remarks: "Balance Inquiry",

      QueueTimeOutURL: timeoutURL,

      ResultURL: resultURL

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/accountbalance/v1/query",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("Account Balance Error:", error);

      return { error: "An error occurred while fetching the account balance." };

    }

  }



  async reversal(amount, transactionID, resultURL, timeoutURL) {



    const accessToken = await this.getAccessToken();



    const payload = {



      Initiator: this.InitiatorName,



      SecurityCredential: this.securityCredential,

      CommandID: "TransactionReversal",

      TransactionID: transactionID,

      Amount: amount,

      ReceiverParty: this.organizationShortCode,

      RecieverIdentifierType: "4",

      ResultURL: resultURL,

      QueueTimeOutURL: timeoutURL,

      Remarks: "Reversal Request",

      Occasion: ""

    };

    

    try {

      const response = await axios.post(

        "https://api.safaricom.co.ke/mpesa/reversal/v1/request",

        payload,

        { headers: { Authorization: `Bearer ${accessToken}` } }

      );

      return response.data;

    } catch (error) {

      console.error("Reversal Error:", error);

      return { error: "An error occurred while reversing the transaction." };

    }

  }

}





export default MpesaService;

