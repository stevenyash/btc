import axios from 'axios';
import googleConfig from '../googleConfig.js';
const CLIENT_ID = googleConfig.web.client_id;
const CLIENT_SECRET = googleConfig.web.client_secret;
const REDIRECT_URI = googleConfig.web.redirect_uris[0]; // Use the first redirect URI

/**
 * Generate Google OAuth URL
 * @returns {string} The Google OAuth URL
 */
export const generateGoogleOAuthUrl = () => {
  return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&response_type=code&scope=profile email`;
};

/**
 * Exchange authorization code for tokens
 * @param {string} code - The authorization code
 * @returns {Promise<object>} The tokens received from Google
 */
export const exchangeCodeForTokens = async (code) => {
  const response = await axios.post('https://oauth2.googleapis.com/token', {
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    code,
    redirect_uri: REDIRECT_URI,
    grant_type: 'authorization_code',
  });
  return response.data;
};

/**
 * Fetch user profile using access token
 * @param {string} accessToken - The access token
 * @returns {Promise<object>} The user profile data
 */
export const fetchUserProfile = async (accessToken) => {
  const response = await axios.get('https://www.googleapis.com/oauth2/v1/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return response.data;
};
