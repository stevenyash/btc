import { google } from 'googleapis';
import fs from 'fs/promises';
import path from 'path';
import process from 'process';
import { authenticate } from '@google-cloud/local-auth';

// Scopes for Calendar and Meet access
const SCOPES = [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/calendar.events'
];

const CREDENTIALS_PATH = path.join(process.cwd(), 'credentials.json');
const TOKEN_PATH = path.join(process.cwd(), 'token.json');
/**
 * Load saved credentials if they exist
 */
export async function loadSavedCredentials() {
    try {
        await fs.access(TOKEN_PATH);
        const content = await fs.readFile(TOKEN_PATH, 'utf8');
        const credentials = JSON.parse(content);

        // Validate credentials structure
        if (!credentials.refresh_token) {
            console.log('No refresh token found in credentials');
            return null;
        }

        const auth = google.auth.fromJSON(credentials);

        // Verify we have valid tokens
        if (!auth.credentials || !auth.credentials.refresh_token) {
            console.log('Invalid credentials structure');
            return null;
        }

        return auth;
    } catch (err) {
        console.log('No valid credentials found');
        return null;
    }
}

/**
 * Save credentials to file
 */
export async function saveCredentials(credentials) {
    // First validate the credentials
    if (!credentials.refresh_token) {
        throw new Error('Refusing to save credentials without refresh token');
    }

    const content = await fs.readFile(CREDENTIALS_PATH, 'utf8');
    const { web } = JSON.parse(content);

    const payload = {
        type: 'authorized_user',
        client_id: web.client_id,
        client_secret: web.client_secret,
        refresh_token: credentials.refresh_token,
        access_token: credentials.access_token,
        expiry_date: credentials.expiry_date,
    };

    await fs.writeFile(TOKEN_PATH, JSON.stringify(payload, null, 2));
    console.log('Credentials saved with refresh token');
}

/**
 * Authorize or re-authenticate with Google
 */
export async function authorize() {
  try {
      let auth = await loadSavedCredentials();

      if (auth) {
          // Check if token is still valid
          const tokenInfo = await auth.getAccessToken();
          if (tokenInfo.token) {
              console.log("Using saved credentials.");
              return auth; // Use existing credentials
          }
      }

      // If no valid token, authenticate
      console.log("No valid credentials found, authenticating...");
      auth = await authenticate({
          scopes: SCOPES,
          keyfilePath: CREDENTIALS_PATH,
          access_type: 'offline',
          prompt: 'consent', // Only when needed
      });

      if (!auth.credentials.refresh_token) {
          throw new Error('Google did not provide a refresh token');
      }

      await saveCredentials(auth.credentials);
      return auth;
  } catch (error) {
      console.error('Authentication failed:', error);
      throw error;
  }
}

/**
 * Create a new Google Meet event
 */
export async function createMeetEvent({
    summary = 'Google Meet Meeting',
    description = '',
    startTime,
    endTime,
    timeZone = 'UTC',
    attendees = [],
    hostEmail
}) {
    try {
      console.log("hostmail",hostEmail)
        const auth = await authorize();
        if (!auth) {
            throw new Error('Authentication failed');
        }

        const calendar = google.calendar({ version: 'v3', auth });

        // Set default times if not provided
        const startDateTime = startTime ? new Date(startTime) : new Date();
        const endDateTime = endTime ? new Date(endTime) : new Date(startDateTime.getTime() + 3600000); // Default 1 hour duration

        // Validate times
        if (startDateTime >= endDateTime) {
            throw new Error('End time must be after start time');
        }

        // Prepare attendees list
        const attendeeList = [...attendees];
        if (hostEmail) {
            attendeeList.push({ email: hostEmail });
        }

        // Create event with Meet conference
        const event = {
            summary,
            description,
            start: {
                dateTime: startDateTime.toISOString(),
                timeZone,
            },
            end: {
                dateTime: endDateTime.toISOString(),
                timeZone,
            },
            conferenceData: {
                createRequest: {
                    requestId: `${Date.now()}`,
                    conferenceSolutionKey: {
                        type: 'hangoutsMeet',
                    },
                },
            },
            attendees: attendeeList,
        };

        // Insert event
        const res = await calendar.events.insert({
            calendarId: 'primary',
            resource: event,
            conferenceDataVersion: 1,
            sendUpdates: 'none',
        });

        if (!res.data.hangoutLink) {
            throw new Error('Failed to create Meet link');
        }

        return {
            meetingUrl: res.data.hangoutLink,
            meetingId: res.data.id,
            startTime: res.data.start.dateTime,
            endTime: res.data.end.dateTime,
            eventData: res.data,
        };
    } catch (error) {
        console.error('Error creating Meet event:', error);

        // Handle authentication errors
        if (error.response?.status === 401) {
            throw new Error('Authentication expired. Please authenticate again.');
        }

        throw new Error(`Failed to create meeting: ${error.message}`);
    }
}

export async function getOAuthClient() {
    try {
        const auth = await authorize();
        if (!auth) {
            throw new Error('Failed to authenticate');
        }

        // Create and return OAuth2 client instance
        return google.oauth2({
            version: 'v2',
            auth: auth
        });
    } catch (error) {
        console.error('Error getting OAuth client:', error);
        throw error;
    }
}

/**
 * Get basic user profile information
 * Demonstrates usage of getOAuthClient()
 */
export async function getUserProfile() {
    try {
        const oauth2Client = await getOAuthClient();
        const { data } = await oauth2Client.userinfo.get();
        return {
            id: data.id,
            email: data.email,
            name: data.name,
            picture: data.picture,
            verifiedEmail: data.verified_email
        };
    } catch (error) {
        console.error('Error getting user profile:', error);
        throw error;
    }
}

/**
 * Explicitly refresh the access token using the stored refresh token
 * Useful when you need to ensure a fresh token before sensitive operations
 */
export async function refreshAccessToken() {
    try {
        // Load existing credentials
        const authClient = await loadSavedCredentials();

        if (!authClient || !authClient.credentials || !authClient.credentials.refresh_token) {
            console.log('No valid refresh token available - need to reauthenticate');
            return null;
        }

        console.log('Refreshing access token...');

        // Refresh the token
        const { credentials } = await authClient.refreshToken(authClient.credentials.refresh_token);

        // Save the new credentials
        await saveCredentials(credentials);

        console.log('Access token refreshed successfully');
        console.log(`New token expires at: ${new Date(credentials.expiry_date).toISOString()}`);

        // Return the new auth client
        return google.auth.fromJSON(credentials);
    } catch (error) {
        console.error('Failed to refresh access token:', error);

        // If refresh fails, clear credentials and require reauthentication
        if (error.response && error.response.status === 401) {
            return null;
        }

        return null;
    }
}

/**
 * Test function to verify authentication and event creation
 */
export async function testGoogleAuth() {
    try {
        console.log('Starting authentication test...');

        // Authenticate fresh
        const auth = await authorize();
        if (!auth) {
            throw new Error('Authentication failed');
        }
        console.log('Authentication successful!');

        // Test creating an event
        console.log('Testing event creation...');
        const startTime = new Date(Date.now() + 3600000); // 1 hour from now
        const endTime = new Date(startTime.getTime() + 3600000); // 1 hour duration

        const event = await createMeetEvent({
            summary: 'Test Google Meet Meeting',
            description: 'This is a test meeting created via API',
            startTime: startTime.toISOString(),
            endTime: endTime.toISOString(),
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            hostEmail: auth.credentials.client_email
        });

        console.log('Meeting created successfully!');
        console.log('Meeting URL:', event.meetingUrl);
        console.log('Start Time:', event.startTime);
        console.log('End Time:', event.endTime);

        return event;
    } catch (error) {
        console.error('Test failed:', error);
        throw error;
    }
}

// Run the test if this file is executed directly
if (process.argv[1] === import.meta.filename) {
    testGoogleAuth().catch(console.error);
}