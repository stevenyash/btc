// routes/learningHierarchyRoutes.js
import { Router } from 'express';
import learningHierarchyService from '../services/learningHierarchyService.js';

const router = Router();

/**
 * Get complete learning hierarchy
 * @GET /api/learning-hierarchy
 */
router.get('/', async (req, res) => {
  try {
    const hierarchy = await learningHierarchyService.getCompleteHierarchy();
    res.json({ success: true, data: hierarchy });
  } catch (error) {
    console.error('Error getting learning hierarchy:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Search lessons across all learning areas
 * @GET /api/learning-hierarchy/search
 */
router.get('/search', async (req, res) => {
  try {
    const { q: query } = req.query;
    if (!query) {
      return res.status(400).json({ success: false, message: 'Search query is required' });
    }
    
    const results = await learningHierarchyService.searchLessons(query);
    res.json({ success: true, data: results, query });
  } catch (error) {
    console.error('Error searching lessons:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get learning path for a specific lesson
 * @GET /api/learning-hierarchy/lessons/:lessonId/path
 */
router.get('/lessons/:lessonId/path', async (req, res) => {
  try {
    const path = await learningHierarchyService.getLearningPath(req.params.lessonId);
    if (!path) {
      return res.status(404).json({ success: false, message: 'Lesson not found' });
    }
    res.json({ success: true, data: path });
  } catch (error) {
    console.error('Error getting learning path:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get popular learning areas for dashboard
 * @GET /api/learning-hierarchy/popular-areas
 */
router.get('/popular-areas', async (req, res) => {
  try {
    const { limit = 6 } = req.query;
    const areas = await learningHierarchyService.getPopularLearningAreas(parseInt(limit));
    res.json({ success: true, data: areas });
  } catch (error) {
    console.error('Error getting popular areas:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get learning levels with their grades
 * @GET /api/learning-hierarchy/levels
 */
router.get('/levels', async (req, res) => {
  try {
    const levels = await learningHierarchyService.getLearningLevels();
    res.json({ success: true, data: levels });
  } catch (error) {
    console.error('Error getting learning levels:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get grades by learning level
 * @GET /api/learning-hierarchy/levels/:levelId/grades
 */
router.get('/levels/:levelId/grades', async (req, res) => {
  try {
    const grades = await learningHierarchyService.getGradesByLevel(req.params.levelId);
    res.json({ success: true, data: grades });
  } catch (error) {
    console.error('Error getting grades by level:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get learning areas by grade
 * @GET /api/learning-hierarchy/grades/:gradeId/areas
 */
router.get('/grades/:gradeId/areas', async (req, res) => {
  try {
    const areas = await learningHierarchyService.getLearningAreasByGrade(req.params.gradeId);
    res.json({ success: true, data: areas });
  } catch (error) {
    console.error('Error getting learning areas by grade:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Get lessons by learning area
 * @GET /api/learning-hierarchy/areas/:areaId/lessons
 */
router.get('/areas/:areaId/lessons', async (req, res) => {
  try {
    const lessons = await learningHierarchyService.getLessonsByArea(req.params.areaId);
    res.json({ success: true, data: lessons });
  } catch (error) {
    console.error('Error getting lessons by area:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;