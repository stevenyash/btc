import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list transactions records
 * @GET /transactions/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Transactions.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(req.query.status){
			queryFilters.push(DB.filterBy("transactions.status", req.query.status))
		}
		if(req.query.payment_status){
			queryFilters.push(DB.filterBy("transactions.payment_status", req.query.payment_status))
		}
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Transactions.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Transactions.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Transactions record
 * @GET /transactions/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Transactions.viewFields();
		let record = await DB.Transactions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Transactions record
 * @POST /transactions/add
 */
router.post('/add/', 
	[
		body('user_id').not().isEmpty(),
		body('phone_number').not().isEmpty(),
		body('amount').not().isEmpty().isNumeric(),
		body('transaction_reference').optional({nullable: true, checkFalsy: true}),
		body('checkout_request_id').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('response_code').optional({nullable: true, checkFalsy: true}),
		body('response_description').optional({nullable: true, checkFalsy: true}),
		body('transactiondate').not().isEmpty(),
		body('payment_status').not().isEmpty(),
		body('details_id').not().isEmpty().isNumeric(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save Transactions record
		let record = await DB.Transactions.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  Transactions record for edit
 * @GET /transactions/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Transactions.editFields();
		let record = await DB.Transactions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Transactions record
 * @POST /transactions/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('user_id').optional({nullable: true}).not().isEmpty(),
		body('phone_number').optional({nullable: true}).not().isEmpty(),
		body('amount').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('transaction_reference').optional({nullable: true, checkFalsy: true}),
		body('checkout_request_id').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('response_code').optional({nullable: true, checkFalsy: true}),
		body('response_description').optional({nullable: true, checkFalsy: true}),
		body('transactiondate').optional({nullable: true}).not().isEmpty(),
		body('payment_status').optional({nullable: true}).not().isEmpty(),
		body('details_id').optional({nullable: true}).not().isEmpty().isNumeric(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Transactions.editFields();
		let record = await DB.Transactions.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Transactions.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Transactions record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /transactions/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Transactions.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Transactions.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
