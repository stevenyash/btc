import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';
import { Op } from 'sequelize';

const router = Router();

/**
 * Route to list user privileges records
 * @GET /userprivileges/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can access this resource');
		}
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		
		let search = req.query.search;
		if(search){
			let searchFields = DB.UserPrivileges.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		// Filter by user_id if provided
		if(req.query.user_id){
			queryFilters.push(DB.filterBy("user_privileges.user_id", req.query.user_id));
		}
		
		// Filter by is_active if provided
		if(req.query.is_active !== undefined){
			where.is_active = req.query.is_active === 'true';
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.UserPrivileges.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.UserPrivileges.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});

/**
 * Route to get all available privileges that can be assigned
 * @GET /userprivileges/available-privileges
 */
router.get('/available-privileges', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			console.log('Available privileges - Access denied. User role:', req.userRoleName);
			return res.forbidden('Only Super Admin or Admin can access this resource');
		}
		
		// Get all unique permissions from the permissions table
		const permissions = await DB.Permissions.findAll({
			attributes: ['permission'],
			group: ['permission'],
			raw: true
		});
		
		// Also get all page actions from role_permissions table
		// The role_permissions table has individual action columns (list, edit, remove, view, store)
		const rolePermRecords = await DB.RolePermissions.findAll({ raw: true });
		const rolePrivs = [];
		for (const rp of rolePermRecords) {
			if (rp.list) rolePrivs.push(`${rp.page}/list`);
			if (rp.view) rolePrivs.push(`${rp.page}/view`);
			if (rp.store) rolePrivs.push(`${rp.page}/add`);
			if (rp.edit) rolePrivs.push(`${rp.page}/edit`);
			if (rp.remove) rolePrivs.push(`${rp.page}/delete`);
		}
		
		const privilegeList = [
			...permissions.map(p => p.permission),
			...rolePrivs
		];
		
		// Get unique privileges
		const uniquePrivileges = [...new Set(privilegeList)].sort();
		
		// Debug logging
		console.log('========== AVAILABLE PRIVILEGES ==========');
		console.log('Total unique privileges:', uniquePrivileges.length);
		console.log('From permissions table:', permissions.length);
		console.log('From role_permissions table:', rolePrivs.length);
		console.log('Full list:', JSON.stringify(uniquePrivileges, null, 2));
		console.log('===========================================');
		
		return res.ok(uniquePrivileges);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to view UserPrivileges record
 * @GET /userprivileges/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can access this resource');
		}
		
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserPrivileges.viewFields();
		let record = await DB.UserPrivileges.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get privileges for a specific user
 * @GET /userprivileges/user/:userId
 */
router.get('/user/:userId', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin or the user themselves (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		const requestedUserId = parseInt(req.params.userId);
		const currentUserId = req.user.id;
		
		if(!allowedRoles.includes(userRole) && requestedUserId !== currentUserId){
			return res.forbidden('You can only view your own privileges');
		}
		
		const privileges = await DB.UserPrivileges.findAll({
			where: {
				user_id: requestedUserId,
				is_active: true
			},
			attributes: ['privilege', 'granted_at', 'granted_by'],
			raw: true
		});
		
		return res.ok(privileges);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to grant a privilege to a user
 * @POST /userprivileges/grant
 */
router.post('/grant', 
	[
		body('user_id').isInt(),
		body('privilege').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		// Check if user is Super Admin or Admin (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			console.log('Grant - Access denied. User role:', req.userRoleName);
			return res.forbidden('Only Super Admin or Admin can grant privileges');
		}
		
		let modeldata = req.getValidFormData();
		modeldata.granted_by = req.user.id;
		
		// Normalize privilege (trim and lowercase for consistency)
		modeldata.privilege = modeldata.privilege.trim();
		
		// Check if this privilege already exists for this user (active or inactive)
		const existingPrivilege = await DB.UserPrivileges.findOne({
			where: {
				user_id: modeldata.user_id,
				privilege: modeldata.privilege
			}
		});
		
		if(existingPrivilege){
			if(!existingPrivilege.is_active){
				// If exists and is inactive, reactivate it
				existingPrivilege.is_active = true;
				existingPrivilege.granted_at = new Date();
				existingPrivilege.granted_by = req.user.id;
				existingPrivilege.expires_at = null;
				await existingPrivilege.save();
				return res.ok({ message: 'Privilege reactivated successfully', privilege: existingPrivilege });
			}
			return res.badRequest('This privilege is already granted to this user');
		}
		
		// Save new privilege
		let record = await DB.UserPrivileges.create(modeldata);
		const recid = record['id'];
		
		return res.ok({ message: 'Privilege granted successfully', privilege: record });
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to grant multiple privileges to a user
 * @POST /userprivileges/grant-multiple
 */
router.post('/grant-multiple', 
	[
		body('user_id').isInt(),
		body('privileges').isArray({ min: 1 }),
	], validateFormData
, async function (req, res) {
	try{
		// Check if user is Super Admin or Admin (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			console.log('Access denied. User role:', req.userRoleName, 'Allowed roles:', allowedRoles);
			return res.forbidden('Only Super Admin or Admin can grant privileges');
		}
		
		let modeldata = req.getValidFormData();
		const userId = modeldata.user_id;
		let privileges = modeldata.privileges;
		const grantedBy = req.user.id;
		
		// Normalize privileges
		privileges = privileges.map(p => typeof p === 'string' ? p.trim() : p);
		
		// Remove duplicates in the input array
		privileges = [...new Set(privileges)];
		
		const results = [];
		const errors = [];
		
		for(const privilege of privileges){
			try {
				// Check if this privilege already exists for this user
				const existingPrivilege = await DB.UserPrivileges.findOne({
					where: {
						user_id: userId,
						privilege: privilege
					}
				});
				
				if(existingPrivilege){
					if(!existingPrivilege.is_active){
						existingPrivilege.is_active = true;
						existingPrivilege.granted_at = new Date();
						existingPrivilege.granted_by = grantedBy;
						existingPrivilege.expires_at = null;
						await existingPrivilege.save();
						results.push({ privilege, status: 'reactivated' });
					} else {
						results.push({ privilege, status: 'already_granted' });
					}
				} else {
					const newPrivilege = await DB.UserPrivileges.create({
						user_id: userId,
						privilege: privilege,
						granted_by: grantedBy
					});
					results.push({ privilege, status: 'granted', id: newPrivilege.id });
				}
			} catch (err) {
				errors.push({ privilege, error: err.message });
			}
		}
		
		return res.ok({ 
			message: 'Privileges processed successfully', 
			results,
			errors: errors.length > 0 ? errors : undefined
		});
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to revoke a privilege from a user
 * @POST /userprivileges/revoke
 */
router.post('/revoke', 
	[
		body('user_id').isInt(),
		body('privilege').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		// Check if user is Super Admin or Admin (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			console.log('Revoke - Access denied. User role:', req.userRoleName);
			return res.forbidden('Only Super Admin or Admin can revoke privileges');
		}
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can revoke privileges');
		}
		
		let modeldata = req.getValidFormData();
		
		const privilege = await DB.UserPrivileges.findOne({
			where: {
				user_id: modeldata.user_id,
				privilege: modeldata.privilege.trim()
			}
		});
		
		if(!privilege){
			return res.notFound('Privilege not found for this user');
		}
		
		if(!privilege.is_active){
			return res.badRequest('This privilege is already revoked');
		}
		
		// Soft delete - just mark as inactive
		privilege.is_active = false;
		await privilege.save();
		
		return res.ok({ message: 'Privilege revoked successfully' });
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to revoke all privileges from a user
 * @POST /userprivileges/revoke-all/:userId
 */
router.post('/revoke-all/:userId', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin (case-insensitive)
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			console.log('Revoke all - Access denied. User role:', req.userRoleName);
			return res.forbidden('Only Super Admin or Admin can revoke privileges');
		}
		
		const userId = parseInt(req.params.userId);
		
		const count = await DB.UserPrivileges.update(
			{ is_active: false },
			{ 
				where: { 
					user_id: userId,
					is_active: true
				}
			}
		);
		
		return res.ok({ message: 'All privileges revoked successfully', count });
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get UserPrivileges record for edit
 * @GET /userprivileges/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can access this resource');
		}
		
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserPrivileges.editFields();
		let record = await DB.UserPrivileges.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to update UserPrivileges record
 * @POST /userprivileges/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('privilege').optional({nullable: true}).not().isEmpty().trim(),
		body('is_active').optional().isBoolean(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserPrivileges.editFields();
		let record = await DB.UserPrivileges.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		// Check for duplicate if privilege is being updated
		if (modeldata.privilege) {
			const existingPrivilege = await DB.UserPrivileges.findOne({
				where: {
					user_id: record.user_id,
					privilege: modeldata.privilege.trim(),
					id: { [DB.op.ne]: recid }
				}
			});
			
			if (existingPrivilege) {
				return res.badRequest('This privilege already exists for this user');
			}
		}
		
		await DB.UserPrivileges.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to delete UserPrivileges record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /userprivileges/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can delete privileges');
		}
		
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.UserPrivileges.findAll(query);
		records.forEach(async (record) => { 
			// Perform action on each record before delete
		});
		await DB.UserPrivileges.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to check if a user privilege already exists
 * @GET /userprivileges/check-duplicate
 */
router.get('/check-duplicate', async (req, res) => {
	try{
		const userId = req.query.user_id;
		const privilege = req.query.privilege;
		const excludeId = req.query.exclude_id;
		
		if (!userId || !privilege) {
			return res.badRequest('User ID and privilege are required');
		}
		
		const where = {
			user_id: userId,
			privilege: privilege.trim()
		};
		
		if (excludeId) {
			where.id = { [DB.op.ne]: excludeId };
		}
		
		const existing = await DB.UserPrivileges.findOne({ where });
		
		return res.ok({ exists: !!existing });
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to sync user privileges with role permissions
 * @POST /userprivileges/sync-with-role/:userId
 */
router.post('/sync-with-role/:userId', async (req, res) => {
	try{
		// Check if user is Super Admin
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin can sync privileges');
		}
		
		const userId = parseInt(req.params.userId);
		const roleId = req.body.role_id;
		
		if (!roleId) {
			return res.badRequest('Role ID is required');
		}
		
		// Get user's current role permissions
		const rolePermissions = await DB.RolePermissions.findAll({
			where: { role_id: roleId },
			raw: true
		});
		
		// Generate privilege names from role permissions
		const privileges = rolePermissions.map(rp => `${rp.page}/list`);
		if (rolePermissions.some(rp => rp.edit)) {
			privileges.push(...rolePermissions.filter(rp => rp.edit).map(rp => `${rp.page}/edit`));
		}
		if (rolePermissions.some(rp => rp.view)) {
			privileges.push(...rolePermissions.filter(rp => rp.view).map(rp => `${rp.page}/view`));
		}
		if (rolePermissions.some(rp => rp.remove)) {
			privileges.push(...rolePermissions.filter(rp => rp.remove).map(rp => `${rp.page}/remove`));
		}
		
		const grantedBy = req.user.id;
		const results = [];
		
		for (const privilege of privileges) {
			const existingPrivilege = await DB.UserPrivileges.findOne({
				where: { user_id: userId, privilege }
			});
			
			if (existingPrivilege) {
				if (!existingPrivilege.is_active) {
					existingPrivilege.is_active = true;
					existingPrivilege.granted_at = new Date();
					existingPrivilege.granted_by = grantedBy;
					await existingPrivilege.save();
					results.push({ privilege, status: 'reactivated' });
				} else {
					results.push({ privilege, status: 'already_granted' });
				}
			} else {
				const newPrivilege = await DB.UserPrivileges.create({
					user_id: userId,
					privilege,
					granted_by: grantedBy
				});
				results.push({ privilege, status: 'granted', id: newPrivilege.id });
			}
		}
		
		return res.ok({ 
			message: 'Privileges synced with role successfully', 
			results 
		});
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to add a new permission to the permissions table
 * @POST /userprivileges/add-permission
 */
router.post('/add-permission', 
	[
		body('permission').not().isEmpty().trim(),
		body('role_id').optional().isInt(),
		body('user_id').optional().isInt(),
	], validateFormData
, async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can add permissions');
		}
		
		let modeldata = req.getValidFormData();
		const permission = modeldata.permission.trim();
		
		// Check if permission already exists
		const existing = await DB.Permissions.findOne({
			where: { permission }
		});
		
		if(existing){
			return res.badRequest('This permission already exists');
		}
		
		// Create the permission
		const record = await DB.Permissions.create(modeldata);
		const recid = record['id'];
		
		console.log('New permission added:', permission, 'by user:', req.user.id);
		
		return res.ok({ message: 'Permission added successfully', id: recid, permission });
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to add a new role permission
 * @POST /userprivileges/add-role-permission
 */
router.post('/add-role-permission', 
	[
		body('page').not().isEmpty().trim(),
		body('role_id').isInt(),
		body('list').optional().isBoolean(),
		body('view').optional().isBoolean(),
		body('store').optional().isBoolean(),
		body('edit').optional().isBoolean(),
		body('remove').optional().isBoolean(),
	], validateFormData
, async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can add role permissions');
		}
		
		let modeldata = req.getValidFormData();
		
		// Check if this role permission already exists
		const existing = await DB.RolePermissions.findOne({
			where: {
				page: modeldata.page,
				role_id: modeldata.role_id
			}
		});
		
		if(existing){
			// Update existing
			await DB.RolePermissions.update(modeldata, {
				where: { id: existing.id }
			});
			console.log('Role permission updated:', modeldata.page, 'for role:', modeldata.role_id);
			return res.ok({ message: 'Role permission updated successfully', id: existing.id });
		}
		
		// Create new
		const record = await DB.RolePermissions.create(modeldata);
		const recid = record['id'];
		
		console.log('New role permission added:', modeldata.page, 'for role:', modeldata.role_id);
		
		return res.ok({ message: 'Role permission added successfully', id: recid });
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to list all available roles
 * @GET /userprivileges/roles
 */
router.get('/roles', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can access roles');
		}
		
		const roles = await DB.Roles.findAll({
			attributes: ['role_id', 'role_name'],
			raw: true
		});
		
		return res.ok(roles);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to list all pages with role permissions
 * @GET /userprivileges/pages
 */
router.get('/pages', async (req, res) => {
	try{
		// Check if user is Super Admin or Admin
		let allowedRoles = ["superadmin", "admin"];
		let userRole = req.userRoleName?.toLowerCase();
		if(!allowedRoles.includes(userRole)){
			return res.forbidden('Only Super Admin or Admin can access pages');
		}
		
		const pages = await DB.RolePermissions.findAll({
			attributes: ['page', 'role_id'],
			group: ['page', 'role_id'],
			raw: true
		});
		
		// Get unique pages
		const uniquePages = [...new Set(pages.map(p => p.page))];
		
		return res.ok({
			allPages: pages,
			uniquePages: uniquePages
		});
	}
	catch(err){
		return res.serverError(err);
	}
});

export default router;
