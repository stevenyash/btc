import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';
import MpesaService from '../helpers/MpesaService.js';
import config from '../config.js';

const router = Router();
const mpesaService = new MpesaService();

// Helper to get system setting
async function getSetting(key, defaultValue = null) {
    const record = await DB.SystemSettings.findOne({ where: { setting_key: key } });
    return record ? record.setting_value : defaultValue;
}

// Helper to find marketer by user
async function getMarketerByUser(user) {
    return await DB.Marketers.findOne({ where: { phone: user.username } });
}

// ==================== MARKETER ENDPOINTS ====================

/**
 * GET /marketer_earnings/summary
 * Returns points, earnings, withdrawals summary for logged-in marketer
 */
router.get('/summary', async (req, res) => {
    try {
        const marketer = await getMarketerByUser(req.user);
        if (!marketer) return res.notFound('Marketer profile not found');

        const availablePoints = (marketer.points || 0) - (marketer.redeemed_points || 0);
        const pointValue = parseFloat(await getSetting('point_value', '10.00'));
        const potentialCash = availablePoints * pointValue;

        return res.ok({
            points: marketer.points || 0,
            redeemed_points: marketer.redeemed_points || 0,
            available_points: availablePoints,
            point_value: pointValue,
            potential_cash: potentialCash,
            commission_rate: parseFloat(marketer.commission_rate) || 0.10,
            total_earnings: parseFloat(marketer.total_earnings) || 0,
            pending_earnings: parseFloat(marketer.pending_earnings) || 0,
            withdrawn_earnings: parseFloat(marketer.withdrawn_earnings) || 0,
        });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/commissions
 * Paginated list of commission records for logged-in marketer
 */
router.get('/commissions', async (req, res) => {
    try {
        const marketer = await getMarketerByUser(req.user);
        if (!marketer) return res.notFound('Marketer profile not found');

        const query = {
            raw: true,
            where: { marketer_id: marketer.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerCommissions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 10;
        let result = await DB.MarketerCommissions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/redemptions
 * Paginated list of point redemption requests for logged-in marketer
 */
router.get('/redemptions', async (req, res) => {
    try {
        const marketer = await getMarketerByUser(req.user);
        if (!marketer) return res.notFound('Marketer profile not found');

        const query = {
            raw: true,
            where: { marketer_id: marketer.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerPointRedemptions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 10;
        let result = await DB.MarketerPointRedemptions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/redeem-points
 * Marketer requests point redemption (pending admin approval)
 */
router.post('/redeem-points',
    [
        body('points_to_redeem').isInt({ min: 1 }).withMessage('Points must be a positive integer'),
    ],
    validateFormData,
    async (req, res) => {
        try {
            const marketer = await getMarketerByUser(req.user);
            if (!marketer) return res.notFound('Marketer profile not found');

            const pointsToRedeem = parseInt(req.body.points_to_redeem);
            const availablePoints = (marketer.points || 0) - (marketer.redeemed_points || 0);

            // Validate minimum redemption
            const minRedemption = parseInt(await getSetting('min_points_redemption', '10'));
            if (pointsToRedeem < minRedemption) {
                return res.badRequest(`Minimum ${minRedemption} points required for redemption`);
            }

            // Validate sufficient points
            if (pointsToRedeem > availablePoints) {
                return res.badRequest(`Insufficient points. Available: ${availablePoints}`);
            }

            // Check for existing pending redemption
            const pendingRedemption = await DB.MarketerPointRedemptions.findOne({
                where: { marketer_id: marketer.id, status: 'pending' }
            });
            if (pendingRedemption) {
                return res.badRequest('You have a pending redemption request. Please wait for admin approval.');
            }

            // Get point value
            const pointValue = parseFloat(await getSetting('point_value', '10.00'));
            const cashAmount = pointsToRedeem * pointValue;

            // Record redemption request (pending approval)
            const redemption = await DB.MarketerPointRedemptions.create({
                marketer_id: marketer.id,
                points_redeemed: pointsToRedeem,
                point_value: pointValue,
                cash_amount: cashAmount,
                status: 'pending'
            });

            return res.ok({
                redemption_id: redemption.id,
                points_requested: pointsToRedeem,
                cash_amount: cashAmount,
                status: 'pending',
                message: 'Redemption request submitted. Awaiting admin approval.'
            });
        } catch (err) {
            return res.serverError(err);
        }
    }
);

/**
 * GET /marketer_earnings/withdrawals
 * Paginated list of withdrawal requests for logged-in marketer
 */
router.get('/withdrawals', async (req, res) => {
    try {
        const marketer = await getMarketerByUser(req.user);
        if (!marketer) return res.notFound('Marketer profile not found');

        const query = {
            raw: true,
            where: { marketer_id: marketer.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerWithdrawals.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 10;
        let result = await DB.MarketerWithdrawals.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/withdraw
 * Marketer requests M-Pesa withdrawal
 */
router.post('/withdraw',
    [
        body('amount').isFloat({ min: 1 }).withMessage('Amount must be a positive number'),
        body('phone_number').not().isEmpty().withMessage('Phone number is required'),
    ],
    validateFormData,
    async (req, res) => {
        try {
            const marketer = await getMarketerByUser(req.user);
            if (!marketer) return res.notFound('Marketer profile not found');

            const amount = parseFloat(req.body.amount);
            const phoneNumber = req.body.phone_number;

            // Validate minimum withdrawal
            const minWithdrawal = parseFloat(await getSetting('min_withdrawal_amount', '100.00'));
            if (amount < minWithdrawal) {
                return res.badRequest(`Minimum withdrawal amount is KES ${minWithdrawal}`);
            }

            // Validate sufficient balance
            const pendingEarnings = parseFloat(marketer.pending_earnings) || 0;
            if (amount > pendingEarnings) {
                return res.badRequest(`Insufficient balance. Available for withdrawal: KES ${pendingEarnings}`);
            }

            // Check for existing pending withdrawal
            const pendingWithdrawal = await DB.MarketerWithdrawals.findOne({
                where: { marketer_id: marketer.id, status: 'pending' }
            });
            if (pendingWithdrawal) {
                return res.badRequest('You have a pending withdrawal request. Please wait for processing.');
            }

            // Create withdrawal record
            const withdrawal = await DB.MarketerWithdrawals.create({
                marketer_id: marketer.id,
                amount: amount,
                phone_number: phoneNumber,
                source: 'both',
                status: 'pending'
            });

            return res.ok({
                withdrawal_id: withdrawal.id,
                amount: amount,
                phone_number: phoneNumber,
                status: 'pending',
                message: 'Withdrawal request submitted. Awaiting processing.'
            });
        } catch (err) {
            return res.serverError(err);
        }
    }
);

// ==================== ADMIN ENDPOINTS ====================

/**
 * GET /marketer_earnings/pending-redemptions
 * Admin: List all pending redemption requests
 */
router.get('/pending-redemptions', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            where: { status: 'pending' },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerPointRedemptions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.MarketerPointRedemptions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/approve-redemption/:id
 * Admin: Approve point redemption request
 */
router.post('/approve-redemption/:id', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const redemption = await DB.MarketerPointRedemptions.findOne({ where: { id: req.params.id } });
        if (!redemption) return res.notFound('Redemption request not found');
        if (redemption.status !== 'pending') return res.badRequest('Redemption already processed');

        const marketer = await DB.Marketers.findOne({ where: { id: redemption.marketer_id } });
        if (!marketer) return res.notFound('Marketer not found');

        // Verify marketer still has enough points
        const availablePoints = (marketer.points || 0) - (marketer.redeemed_points || 0);
        if (redemption.points_redeemed > availablePoints) {
            return res.badRequest(`Marketer only has ${availablePoints} available points now`);
        }

        // Approve and apply
        await DB.MarketerPointRedemptions.update(
            {
                status: 'approved',
                reviewed_by: req.user.id,
                reviewed_at: new Date()
            },
            { where: { id: redemption.id } }
        );

        await DB.Marketers.update(
            {
                redeemed_points: marketer.redeemed_points + redemption.points_redeemed,
                total_earnings: parseFloat(marketer.total_earnings) + parseFloat(redemption.cash_amount),
                pending_earnings: parseFloat(marketer.pending_earnings) + parseFloat(redemption.cash_amount)
            },
            { where: { id: marketer.id } }
        );

        return res.ok({
            message: 'Redemption approved',
            cash_amount: redemption.cash_amount,
            points_redeemed: redemption.points_redeemed
        });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/reject-redemption/:id
 * Admin: Reject point redemption request
 */
router.post('/reject-redemption/:id', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const redemption = await DB.MarketerPointRedemptions.findOne({ where: { id: req.params.id } });
        if (!redemption) return res.notFound('Redemption request not found');
        if (redemption.status !== 'pending') return res.badRequest('Redemption already processed');

        await DB.MarketerPointRedemptions.update(
            {
                status: 'rejected',
                remarks: req.body.remarks || 'Rejected by admin',
                reviewed_by: req.user.id,
                reviewed_at: new Date()
            },
            { where: { id: redemption.id } }
        );

        return res.ok({ message: 'Redemption rejected' });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/withdrawals
 * Admin: List all pending withdrawal requests
 */
router.get('/admin/withdrawals', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const status = req.query.status || 'pending';
        const query = {
            raw: true,
            where: { status },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerWithdrawals.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.MarketerWithdrawals.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/process-withdrawal/:id
 * Admin: Process withdrawal via M-Pesa B2C
 */
router.post('/process-withdrawal/:id', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const withdrawal = await DB.MarketerWithdrawals.findOne({ where: { id: req.params.id } });
        if (!withdrawal) return res.notFound('Withdrawal not found');
        if (withdrawal.status !== 'pending') return res.badRequest('Withdrawal already processed');

        // Update status to processing
        await DB.MarketerWithdrawals.update(
            { status: 'processing' },
            { where: { id: withdrawal.id } }
        );

        // Initiate M-Pesa B2C transfer
        const baseUrl = config.app.url || `${req.protocol}://${req.get('host')}`;
        const resultUrl = `${baseUrl}/api/marketer_earnings/b2c-result`;
        const timeoutUrl = `${baseUrl}/api/marketer_earnings/b2c-timeout`;

        const b2cResponse = await mpesaService.b2cTransfer(
            withdrawal.amount,
            withdrawal.phone_number,
            resultUrl,
            timeoutUrl
        );

        if (b2cResponse.error) {
            await DB.MarketerWithdrawals.update(
                { status: 'failed', remarks: b2cResponse.error },
                { where: { id: withdrawal.id } }
            );
            return res.serverError(b2cResponse.error);
        }

        // Store conversation ID for tracking
        await DB.MarketerWithdrawals.update(
            {
                mpesa_conversation_id: b2cResponse.ConversationID,
                mpesa_originator_conversation_id: b2cResponse.OriginatorConversationID
            },
            { where: { id: withdrawal.id } }
        );

        return res.ok({
            message: 'B2C transfer initiated',
            conversation_id: b2cResponse.ConversationID
        });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * POST /marketer_earnings/b2c-result
 * M-Pesa B2C callback for successful transfer
 */
router.post('/b2c-result', async (req, res) => {
    try {
        const result = req.body.Result;
        if (!result) return res.ok({ message: 'No result data' });

        const conversationId = result.ConversationID;
        const resultType = result.ResultType;
        const resultCode = result.ResultCode;
        const resultDesc = result.ResultDesc;

        // Find withdrawal by conversation ID
        const withdrawal = await DB.MarketerWithdrawals.findOne({
            where: { mpesa_conversation_id: conversationId }
        });

        if (!withdrawal) return res.ok({ message: 'Withdrawal not found' });

        if (resultCode === 0) {
            // Success - extract receipt number from ResultParameters
            let mpesaReceipt = '';
            if (result.ResultParameters && result.ResultParameters.ResultParameter) {
                const receiptParam = result.ResultParameters.ResultParameter.find(
                    p => p.Key === 'TransactionReceipt'
                );
                if (receiptParam) mpesaReceipt = receiptParam.Value;
            }

            // Update withdrawal status
            await DB.MarketerWithdrawals.update(
                {
                    status: 'completed',
                    mpesa_receipt: mpesaReceipt,
                    processed_at: new Date()
                },
                { where: { id: withdrawal.id } }
            );

            // Update marketer earnings
            const marketer = await DB.Marketers.findOne({ where: { id: withdrawal.marketer_id } });
            if (marketer) {
                await DB.Marketers.update(
                    {
                        pending_earnings: Math.max(0, parseFloat(marketer.pending_earnings) - parseFloat(withdrawal.amount)),
                        withdrawn_earnings: parseFloat(marketer.withdrawn_earnings) + parseFloat(withdrawal.amount)
                    },
                    { where: { id: marketer.id } }
                );
            }
        } else {
            // Failed
            await DB.MarketerWithdrawals.update(
                {
                    status: 'failed',
                    remarks: resultDesc,
                    processed_at: new Date()
                },
                { where: { id: withdrawal.id } }
            );
        }

        return res.ok({ message: 'Callback processed' });
    } catch (err) {
        console.error('B2C Result Error:', err);
        return res.ok({ message: 'Error processing callback' });
    }
});

/**
 * POST /marketer_earnings/b2c-timeout
 * M-Pesa B2C timeout callback
 */
router.post('/b2c-timeout', async (req, res) => {
    try {
        console.log('B2C Timeout:', req.body);
        return res.ok({ message: 'Timeout received' });
    } catch (err) {
        return res.ok({ message: 'Error processing timeout' });
    }
});

// ==================== SETTINGS ENDPOINTS ====================

/**
 * GET /marketer_earnings/settings
 * Admin: Get system settings for commissions
 */
router.get('/settings', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const settings = await DB.SystemSettings.findAll({ raw: true });
        const settingsMap = {};
        settings.forEach(s => {
            settingsMap[s.setting_key] = s.setting_value;
        });

        return res.ok(settingsMap);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * PUT /marketer_earnings/settings
 * Admin: Update system settings for commissions
 */
router.put('/settings', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const { default_commission_rate, point_value, min_withdrawal_amount, min_points_redemption } = req.body;

        if (default_commission_rate !== undefined) {
            await DB.SystemSettings.upsert({ setting_key: 'default_commission_rate', setting_value: String(default_commission_rate), description: 'Default commission rate for marketers' });
        }
        if (point_value !== undefined) {
            await DB.SystemSettings.upsert({ setting_key: 'point_value', setting_value: String(point_value), description: 'Monetary value per point in KES' });
        }
        if (min_withdrawal_amount !== undefined) {
            await DB.SystemSettings.upsert({ setting_key: 'min_withdrawal_amount', setting_value: String(min_withdrawal_amount), description: 'Minimum withdrawal amount in KES' });
        }
        if (min_points_redemption !== undefined) {
            await DB.SystemSettings.upsert({ setting_key: 'min_points_redemption', setting_value: String(min_points_redemption), description: 'Minimum points required for redemption' });
        }

        return res.ok({ message: 'Settings updated' });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * PUT /marketer_earnings/commission-rate/:id
 * Admin: Update individual marketer commission rate
 */
router.put('/commission-rate/:id',
    [
        body('commission_rate').isFloat({ min: 0, max: 1 }).withMessage('Commission rate must be between 0 and 1'),
    ],
    validateFormData,
    async (req, res) => {
        try {
            if (!req.isAdmin && !req.isSuperadmin) {
                return res.forbidden('Admin access required');
            }

            const marketer = await DB.Marketers.findOne({ where: { id: req.params.id } });
            if (!marketer) return res.notFound('Marketer not found');

            await DB.Marketers.update(
                { commission_rate: parseFloat(req.body.commission_rate) },
                { where: { id: req.params.id } }
            );

            return res.ok({
                message: 'Commission rate updated',
                commission_rate: parseFloat(req.body.commission_rate)
            });
        } catch (err) {
            return res.serverError(err);
        }
    }
);

// ==================== SUPERADMIN: ALL MARKETER MANAGEMENT ====================

/**
 * GET /marketer_earnings/admin/marketers
 * Superadmin: List all marketers with earnings summary
 */
router.get('/admin/marketers', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            order: DB.getOrderBy(req, 'id', 'desc'),
            attributes: DB.Marketers.listFields()
        };

        const search = req.query.search;
        if (search) {
            const searchFields = DB.Marketers.searchFields();
            query.where = { [DB.op.or]: searchFields };
            query.replacements = { search: `%${search}%` };
        }

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.Marketers.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/marketer/:id/summary
 * Superadmin: View specific marketer's earnings summary
 */
router.get('/admin/marketer/:id/summary', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const marketer = await DB.Marketers.findOne({ where: { id: req.params.id }, raw: true });
        if (!marketer) return res.notFound('Marketer not found');

        const availablePoints = (marketer.points || 0) - (marketer.redeemed_points || 0);
        const pointValue = parseFloat(await getSetting('point_value', '10.00'));

        // Get counts
        const commissionsCount = await DB.MarketerCommissions.count({ where: { marketer_id: marketer.id } });
        const redemptionsCount = await DB.MarketerPointRedemptions.count({ where: { marketer_id: marketer.id } });
        const withdrawalsCount = await DB.MarketerWithdrawals.count({ where: { marketer_id: marketer.id } });

        return res.ok({
            ...marketer,
            available_points: availablePoints,
            point_value: pointValue,
            potential_cash: availablePoints * pointValue,
            commissions_count: commissionsCount,
            redemptions_count: redemptionsCount,
            withdrawals_count: withdrawalsCount
        });
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/marketer/:id/commissions
 * Superadmin: View specific marketer's commission history
 */
router.get('/admin/marketer/:id/commissions', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            where: { marketer_id: req.params.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerCommissions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.MarketerCommissions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/marketer/:id/redemptions
 * Superadmin: View specific marketer's redemption history
 */
router.get('/admin/marketer/:id/redemptions', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            where: { marketer_id: req.params.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerPointRedemptions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.MarketerPointRedemptions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/marketer/:id/withdrawals
 * Superadmin: View specific marketer's withdrawal history
 */
router.get('/admin/marketer/:id/withdrawals', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            where: { marketer_id: req.params.id },
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerWithdrawals.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 20;
        let result = await DB.MarketerWithdrawals.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * PUT /marketer_earnings/admin/marketer/:id/points
 * Superadmin: Adjust marketer's points (add or subtract)
 */
router.put('/admin/marketer/:id/points',
    [
        body('adjustment').isInt().withMessage('Adjustment must be an integer'),
        body('reason').optional().isString().withMessage('Reason must be a string'),
    ],
    validateFormData,
    async (req, res) => {
        try {
            if (!req.isAdmin && !req.isSuperadmin) {
                return res.forbidden('Admin access required');
            }

            const marketer = await DB.Marketers.findOne({ where: { id: req.params.id } });
            if (!marketer) return res.notFound('Marketer not found');

            const adjustment = parseInt(req.body.adjustment);
            const newPoints = Math.max(0, (marketer.points || 0) + adjustment);

            await DB.Marketers.update(
                { points: newPoints },
                { where: { id: req.params.id } }
            );

            return res.ok({
                message: 'Points adjusted',
                previous_points: marketer.points,
                adjustment: adjustment,
                new_points: newPoints
            });
        } catch (err) {
            return res.serverError(err);
        }
    }
);

/**
 * GET /marketer_earnings/admin/all-commissions
 * Superadmin: View all commissions across all marketers
 */
router.get('/admin/all-commissions', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const query = {
            raw: true,
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerCommissions.listFields()
        };

        if (req.query.marketer_id) {
            query.where = { marketer_id: req.query.marketer_id };
        }
        if (req.query.status) {
            query.where = { ...query.where, status: req.query.status };
        }
        if (req.query.purchase_type) {
            query.where = { ...query.where, purchase_type: req.query.purchase_type };
        }

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 50;
        let result = await DB.MarketerCommissions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/all-redemptions
 * Superadmin: View all redemption requests
 */
router.get('/admin/all-redemptions', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const status = req.query.status || undefined;
        const query = {
            raw: true,
            where: status ? { status } : {},
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerPointRedemptions.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 50;
        let result = await DB.MarketerPointRedemptions.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/all-withdrawals
 * Superadmin: View all withdrawal requests
 */
router.get('/admin/all-withdrawals', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        const status = req.query.status || undefined;
        const query = {
            raw: true,
            where: status ? { status } : {},
            order: DB.getOrderBy(req, 'created_at', 'desc'),
            attributes: DB.MarketerWithdrawals.listFields()
        };

        let page = parseInt(req.query.page) || 1;
        let limit = parseInt(req.query.limit) || 50;
        let result = await DB.MarketerWithdrawals.paginate(query, page, limit);

        return res.ok(result);
    } catch (err) {
        return res.serverError(err);
    }
});

/**
 * GET /marketer_earnings/admin/dashboard-stats
 * Superadmin: Dashboard statistics for marketer system
 */
router.get('/admin/dashboard-stats', async (req, res) => {
    try {
        if (!req.isAdmin && !req.isSuperadmin) {
            return res.forbidden('Admin access required');
        }

        // Total marketers
        const totalMarketers = await DB.Marketers.count();

        // Total earnings distributed
        const totalEarningsSql = `SELECT COALESCE(SUM(total_earnings), 0) as total FROM marketers`;
        const totalEarnings = await DB.rawQueryValue(totalEarningsSql) || 0;

        // Total pending payouts
        const pendingPayoutsSql = `SELECT COALESCE(SUM(pending_earnings), 0) as total FROM marketers`;
        const pendingPayouts = await DB.rawQueryValue(pendingPayoutsSql) || 0;

        // Total withdrawn
        const withdrawnSql = `SELECT COALESCE(SUM(withdrawn_earnings), 0) as total FROM marketers`;
        const withdrawnTotal = await DB.rawQueryValue(withdrawnSql) || 0;

        // Pending redemptions count
        const pendingRedemptions = await DB.MarketerPointRedemptions.count({ where: { status: 'pending' } });

        // Pending withdrawals count
        const pendingWithdrawals = await DB.MarketerWithdrawals.count({ where: { status: 'pending' } });

        // Total commissions this month
        const commissionsThisMonthSql = `
            SELECT COALESCE(SUM(commission_amount), 0) as total 
            FROM marketer_commissions 
            WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) 
            AND YEAR(created_at) = YEAR(CURRENT_DATE())
        `;
        const commissionsThisMonth = await DB.rawQueryValue(commissionsThisMonthSql) || 0;

        return res.ok({
            total_marketers: totalMarketers,
            total_earnings: parseFloat(totalEarnings),
            pending_payouts: parseFloat(pendingPayouts),
            withdrawn_total: parseFloat(withdrawnTotal),
            pending_redemptions: pendingRedemptions,
            pending_withdrawals: pendingWithdrawals,
            commissions_this_month: parseFloat(commissionsThisMonth)
        });
    } catch (err) {
        return res.serverError(err);
    }
});

export default router;
