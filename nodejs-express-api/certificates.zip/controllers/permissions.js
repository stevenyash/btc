import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';
import PermissionService from '../services/permissionService.js';



const router = Router();



/**
 * Route to list permissions records
 * @GET /permissions/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Permissions.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'permission_id', 'desc');
		query.attributes = DB.Permissions.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Permissions.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});



/**
 * Route to view Permissions record
 * @GET /permissions/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['permission_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Permissions.viewFields();
		let record = await DB.Permissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert a single permission
 * @POST /permissions/add
 */
router.post('/add/', 
	[
		body('permission').not().isEmpty().trim(),
		body('role_id').optional({nullable: true, checkFalsy: true}),
		body('user_id').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		// Use the permission service for insertion with duplicate checking
		const result = await PermissionService.insertPermission({
			permission: modeldata.permission,
			role_id: modeldata.role_id || null,
			user_id: modeldata.user_id || req.user.id
		});
		
		if (!result.success) {
			return res.badRequest(result.error);
		}
		
		return res.ok({
			message: 'Permission created successfully',
			permission: result.permission
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert multiple permissions at once
 * @POST /permissions/bulk-add
 * 
 * Request body:
 * {
 *   "permissions": [
 *     { "permission": "read_users", "role_id": 1 },
 *     { "permission": "write_users", "role_id": 1 },
 *     { "permission": "delete_users", "role_id": 2 }
 *   ]
 * }
 */
router.post('/bulk-add', 
	[
		body('permissions').isArray({ min: 1 }),
		body('permissions.*.permission').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		const permissions = modeldata.permissions;
		
		// Use the service for bulk insertion
		const result = await PermissionService.insertMultiplePermissions(permissions);
		
		return res.ok({
			message: 'Bulk insertion completed',
			created: result.created,
			duplicates: result.duplicates,
			errors: result.errors
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert permission for a role
 * @POST /permissions/add-for-role/{roleId}
 */
router.post('/add-for-role/:roleId', 
	[
		body('permission').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		const roleId = parseInt(req.params.roleId);
		
		if (isNaN(roleId)) {
			return res.badRequest('Invalid role ID');
		}
		
		let modeldata = req.getValidFormData();
		
		const result = await PermissionService.insertPermission({
			permission: modeldata.permission,
			role_id: roleId,
			user_id: null
		});
		
		if (!result.success) {
			return res.badRequest(result.error);
		}
		
		return res.ok({
			message: 'Permission added for role successfully',
			permission: result.permission
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert permission for a user
 * @POST /permissions/add-for-user/{userId}
 */
router.post('/add-for-user/:userId', 
	[
		body('permission').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		const userId = parseInt(req.params.userId);
		
		if (isNaN(userId)) {
			return res.badRequest('Invalid user ID');
		}
		
		let modeldata = req.getValidFormData();
		
		const result = await PermissionService.insertPermission({
			permission: modeldata.permission,
			role_id: null,
			user_id: userId
		});
		
		if (!result.success) {
			return res.badRequest(result.error);
		}
		
		return res.ok({
			message: 'Permission added for user successfully',
			permission: result.permission
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to copy permissions from one role to another
 * @POST /permissions/copy-from-role/{sourceRoleId}/to/{targetRoleId}
 */
router.post('/copy-from-role/:sourceRoleId/to/:targetRoleId', async (req, res) => {
	try{
		const sourceRoleId = parseInt(req.params.sourceRoleId);
		const targetRoleId = parseInt(req.params.targetRoleId);
		
		if (isNaN(sourceRoleId) || isNaN(targetRoleId)) {
			return res.badRequest('Invalid role IDs');
		}
		
		const result = await PermissionService.copyPermissions(sourceRoleId, targetRoleId);
		
		if (!result.success) {
			return res.badRequest(result.error);
		}
		
		return res.ok({
			message: `Successfully copied ${result.copied} permissions`,
			copied: result.copied
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get all permissions for a role
 * @GET /permissions/by-role/{roleId}
 */
router.get('/by-role/:roleId', async (req, res) => {
	try{
		const roleId = parseInt(req.params.roleId);
		
		if (isNaN(roleId)) {
			return res.badRequest('Invalid role ID');
		}
		
		const permissions = await PermissionService.findPermissionsByRole(roleId);
		
		return res.ok(permissions);
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get all permissions for a user
 * @GET /permissions/by-user/{userId}
 */
router.get('/by-user/:userId', async (req, res) => {
	try{
		const userId = parseInt(req.params.userId);
		
		if (isNaN(userId)) {
			return res.badRequest('Invalid user ID');
		}
		
		const permissions = await PermissionService.findPermissionsByUser(userId);
		
		return res.ok(permissions);
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get all unique permission names
 * @GET /permissions/unique
 */
router.get('/unique', async (req, res) => {
	try{
		const permissions = await PermissionService.getAllUniquePermissions();
		
		return res.ok(permissions);
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get  Permissions record for edit
 * @GET /permissions/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['permission_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Permissions.editFields();
		let record = await DB.Permissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to update  Permissions record
 * @POST /permissions/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('permission').optional({nullable: true}).not().isEmpty().trim(),
		body('role_id').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['permission_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Permissions.editFields();
		let record = await DB.Permissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		// Check for duplicate if permission or role_id is being updated
		if (modeldata.permission || modeldata.role_id) {
			const duplicateWhere = {
				permission: modeldata.permission || record.permission,
				permission_id: { [DB.op.ne]: recid } // Exclude current record
			};
			if (modeldata.role_id) {
				duplicateWhere.role_id = modeldata.role_id;
			} else {
				duplicateWhere.role_id = record.role_id;
			}
			
			const existingPermission = await DB.Permissions.findOne({
				where: duplicateWhere
			});
			
			if (existingPermission) {
				return res.badRequest('This permission already exists for the specified role/user');
			}
		}
		
		await DB.Permissions.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to delete Permissions record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /permissions/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		let allowedRoles = ["superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['permission_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Permissions.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Permissions.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to check if a permission already exists
 * @GET /permissions/check-duplicate
 */
router.get('/check-duplicate', async (req, res) => {
	try{
		const permission = req.query.permission;
		const roleId = req.query.role_id;
		const userId = req.query.user_id;
		const excludeId = req.query.exclude_id;
		
		if (!permission) {
			return res.badRequest('Permission name is required');
		}
		
		const exists = await PermissionService.permissionExists(
			permission,
			roleId || null,
			userId || null,
			excludeId || null
		);
		
		return res.ok({ exists });
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get permission statistics
 * @GET /permissions/statistics
 */
router.get('/statistics', async (req, res) => {
	try{
		const stats = await PermissionService.getStatistics();
		
		return res.ok(stats);
	} catch(err){
		return res.serverError(err);
	}
});



export default router;
