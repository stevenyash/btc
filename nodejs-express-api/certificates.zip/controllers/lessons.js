import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';
import uploader from '../helpers/uploader.js';
import s3CloudFrontService from '../services/s3CloudFrontService.js';

// Import services and middleware
import { LessonAccessService } from '../services/lessonAccessService.js';
import { FileUploadService } from '../services/fileUploadService.js';
import { 
    validateLessonAccess, 
    validateLessonCreate, 
    validateLessonUpdate, 
    validateSessionComplete 
} from '../middleware/validationMiddleware.js';
import { handleAsync } from '../middleware/asyncHandler.js';
import { streamLimiter, generalLimiter, uploadLimiter } from '../middleware/rateLimiters.js';
import config from '../config/lessons.js';

const router = Router();

// Initialize services
const lessonAccessService = new LessonAccessService();
const fileUploadService = new FileUploadService(config.s3);

// Apply general rate limiting to all routes
router.use(generalLimiter);

/**
 * Before create new record
 */
async function beforeAdd(postdata, req) {
    console.log('Before add - preparing lesson data:', postdata);
    
    if (postdata.topic_id) {
        const topic = await DB.Topics.findOne({
            where: { topic_id: postdata.topic_id },
            raw: true
        });
        if (!topic) {
            throw new Error('Invalid topic ID');
        }
    }
    
    if (postdata.subtopic_id) {
        const subtopic = await DB.Subtopics.findOne({
            where: { subtopic_id: postdata.subtopic_id },
            raw: true
        });
        if (!subtopic) {
            throw new Error('Invalid subtopic ID');
        }
    }
}

/**
 * After a new lesson record is created, upload only the video to S3
 */
async function afterAdd(record, req) {
    try {
        console.log('Starting afterAdd S3 upload for lesson:', record.id);
        
        if (!record.file) {
            console.log('No video file to upload to S3');
            return;
        }

        const pathInfo = await fileUploadService.getCollectionPath(
            record.area_id, 
            record.topic_id, 
            record.subtopic_id
        );
        
        const options = {
            collection: pathInfo.collection,
            title: record.title,
            description: record.description,
            visibility: 'private',
            category: 'lesson',
            metadata: {
                topic_id: record.topic_id,
                topic_title: pathInfo.topic,
                subtopic_id: record.subtopic_id,
                subtopic_title: pathInfo.subtopic
            }
        };

        console.log("Uploading lesson video to S3:", record.file, record.filename);

        const uploadResponse = await fileUploadService.uploadLessonToS3WithRetries(
            record.file, 
            record.filename, 
            options
        );
        
        console.log('S3 Upload successful:', uploadResponse);

        if (uploadResponse.key) {
            let where = {'id': record.id};
            let modeldata = {
                s3_key: uploadResponse.key,
                s3_url: uploadResponse.url,
                file_size: uploadResponse.size,
                is_active: true,
                uploaded_at: new Date()
            };
            
            await DB.Lessons.update(modeldata, { where });
            
            await uploader.deleteRecordFiles(record.file, 'file');
            
            console.log(`Lesson ${record.id} video successfully uploaded to S3 and local file cleaned up`);
        }

    } catch (error) {
        console.error('Error in afterAdd S3 upload:', error.message);
        
        try {
            let where = {'id': record.id};
            let modeldata = {
                is_active: false,
                upload_error: error.message
            };
            await DB.Lessons.update(modeldata, { where });
        } catch (updateError) {
            console.error('Failed to update lesson status:', updateError);
        }
    }
}

/**
 * Route to list lessons records
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], 
    handleAsync(async (req, res) => {  
        try {
            const query = {};
            let queryFilters = [];
            let where = {};
            let replacements = {};
            let fieldName = req.params.fieldname;
            let fieldValue = req.params.fieldvalue;
            
            if (fieldName) {
                if (fieldName === 'subtopic_id') {
                    queryFilters.push(DB.filterBy('lessons.subtopic_id', fieldValue));
                } else if (fieldName === 'topic_id') {
                    queryFilters.push(DB.filterBy('lessons.topic_id', fieldValue));
                } else if (fieldName === 'area_id') {
                    queryFilters.push(DB.filterBy('lessons.area_id', fieldValue));
                } else {
                    queryFilters.push(DB.filterBy(fieldName, fieldValue));
                }
            }
            
            let search = req.query.search;
            if (search) {
                let searchFields = DB.Lessons.searchFields();
                where[DB.op.or] = searchFields;
                replacements.search = `%${search}%`;
            }
            
            if (queryFilters.length) {
                where[DB.op.and] = queryFilters;
            }
            
            query.raw = false;
            query.where = where;
            query.replacements = replacements;
            query.order = DB.getOrderBy(req, 'sort_order', 'desc');
            
            let baseAttributes = [
                'id', 'area_id', 'title', 'description', 'duration', 
                'thumbnail_url', 'price', 'is_preview_available', 
                'preview_duration', 'sort_order', 'is_active', 
                'created_at', 'updated_at', 'subtopic_id', 'topic_id',
                'file', 'filename', 'primary_thumbnail'
            ];
            
            if (!req.user || req.userRoleName !== 'admin') {
                const fieldsToExclude = ['s3_key','s3_url'];
                query.attributes = baseAttributes.filter(field => !fieldsToExclude.includes(field));
            } else {
                query.attributes = baseAttributes;
            }
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name'] 
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name'] 
                }
            ];
            
            let page = parseInt(req.query.page) || 1;
            let limit = parseInt(req.query.limit) || 10;
            let result = await DB.Lessons.paginate(query, page, limit);
            return res.ok(result);
        }
        catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Route to view Lessons record
 */
router.get('/view/:recid', 
    handleAsync(async (req, res) => {
        try {
            const recid = req.params.recid || null;
            const query = {};
            const where = {};
            where['id'] = recid;
            
            query.raw = false;
            query.where = where;
            query.attributes = DB.Lessons.viewFields();
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name'] 
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name'] 
                }
            ];
            
            let record = await DB.Lessons.findOne(query);
            if (!record) {
                return res.notFound();
            }
            return res.ok(record);
        }
        catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Route to insert Lessons record
 */
router.post('/add/', 
    uploadLimiter,
    validateLessonCreate,
    validateFormData,
    handleAsync(async (req, res) => {
        try {
            let modeldata = req.getValidFormData();
            console.log("Received modeldata for new lesson:", modeldata);
            
            // Process files
            modeldata = await fileUploadService.processLessonFiles(modeldata);
            
            await beforeAdd(modeldata, req);
            console.log('Creating Lessons record with data:', modeldata);
            
            let record = await DB.Lessons.create(modeldata);
            console.log("record created:", record);
            
            // Process S3 upload in background
            afterAdd(record, req).catch(error => {
                console.error('Background S3 upload error:', error);
            });
            
            return res.ok(record);
        } catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Route to get Lessons record for edit
 */
router.get('/edit/:recid', 
    handleAsync(async (req, res) => {
        try {
            const recid = req.params.recid;
            const query = {};
            const where = {};
            where['id'] = recid;
            
            query.raw = false;
            query.where = where;
            query.attributes = DB.Lessons.editFields();
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name']
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name']
                }
            ];
            
            let record = await DB.Lessons.findOne(query);
            if (!record) {
                return res.notFound();
            }
            return res.ok(record);
        }
        catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Route to update Lessons record
 */
router.post('/edit/:recid',
    uploadLimiter,
    validateLessonUpdate,
    validateFormData,
    handleAsync(async (req, res) => {
        try {
            const recid = req.params.recid;
            let modeldata = req.getValidFormData({ includeOptionals: true });
            
            const currentRecord = await DB.Lessons.findOne({ 
                where: { id: recid },
                include: [
                    {
                        model: DB.LearningAreas,
                        as: 'learning_area',
                        attributes: ['id', 'name', 'grade_id']
                    },
                    {
                        model: DB.Topics,
                        as: 'topic',
                        attributes: ['topic_id', 'name'] 
                    },
                    {
                        model: DB.Subtopics,
                        as: 'subtopic',
                        attributes: ['subtopic_id', 'name'] 
                    }
                ]
            });

            if (!currentRecord) {
                return res.notFound('Lesson not found');
            }

            // Process files
            modeldata = await fileUploadService.processLessonFiles(modeldata, currentRecord);

            if (modeldata.file !== undefined && modeldata.file !== currentRecord.file) {
                const pathInfo = await fileUploadService.getCollectionPath(
                    modeldata.area_id || currentRecord.area_id,
                    modeldata.topic_id || currentRecord.topic_id,
                    modeldata.subtopic_id || currentRecord.subtopic_id
                );
                
                const options = {
                    collection: pathInfo.collection,
                    title: modeldata.title || currentRecord.title,
                    description: modeldata.description || currentRecord.description,
                    visibility: 'private',
                    category: 'lesson',
                    metadata: {
                        topic_id: modeldata.topic_id || currentRecord.topic_id,
                        topic_title: pathInfo.topic,
                        subtopic_id: modeldata.subtopic_id || currentRecord.subtopic_id,
                        subtopic_title: pathInfo.subtopic
                    }
                };
                
                const uploadResponse = await fileUploadService.uploadLessonToS3WithRetries(
                    modeldata.file, 
                    modeldata.filename, 
                    options
                );
                
                modeldata.s3_key = uploadResponse.key;
                modeldata.s3_url = uploadResponse.url;
                modeldata.file_size = uploadResponse.size;
                
                // Clean up old files
                await fileUploadService.cleanupOldFiles(currentRecord, ['file']);
            }

            if (modeldata.thumbnail_url !== undefined && modeldata.thumbnail_url !== currentRecord.thumbnail_url) {
                // Clean up old thumbnail
                await fileUploadService.cleanupOldFiles(currentRecord, ['thumbnail']);
            }
            
            const query = {};
            const where = {};
            where['id'] = recid;
            query.raw = false;
            query.where = where;
            query.attributes = DB.Lessons.editFields();
            
            let record = await DB.Lessons.findOne(query);
            if (!record) {
                return res.notFound();
            }
            
            await DB.Lessons.update(modeldata, {where: where});
            
            return res.ok(modeldata);
        }
        catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Route to delete Lessons record
 */
router.get('/delete/:recid', 
    handleAsync(async (req, res) => {
        try {
            const recid = (req.params.recid || '').split(',');
            const query = {};
            const where = {};
            where['id'] = recid;
            query.raw = true;
            query.where = where;
            let records = await DB.Lessons.findAll(query);
            
            for (let record of records) {
                // Clean up all files
                await fileUploadService.cleanupOldFiles(record, ['file', 'thumbnail']);
            }
            
            await DB.Lessons.destroy(query);
            
            return res.ok(recid);
        }
        catch(err) {
            return res.serverError(err);
        }
    })
);

/**
 * Enhanced Route to get AWS CloudFront streaming URL with comprehensive security
 */
router.get('/stream-url/:recid',
    streamLimiter,
    validateLessonAccess,
    handleAsync(async (req, res) => {
        try {
            console.log('=== ENHANCED SECURE STREAM URL REQUEST START ===');
            const recid = req.params.recid;
            const { signed = 'true', expiresIn = 3600, guest = 'false' } = req.query;
            
            // Extract user info and client details for security
            const user_id = req.user?.id || req.query.user_id;
            const phone = req.query.phone;
            const clientInfo = {
                ipAddress: req.ip,
                userAgent: req.get('User-Agent')
            };

            console.log('Enhanced Request Parameters:', {
                recid,
                signed,
                expiresIn,
                guest,
                user_id,
                phone,
                clientInfo
            });

            let accessValidation;
            let accessType = '';
            let sessionExpiresAt;
            let sessionId = `${user_id || phone}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

            console.log('=== ENHANCED ACCESS VALIDATION ===');
            // Validate access based on user type
            if (guest === 'true') {
                console.log('Validating guest access for phone:', phone);
                accessValidation = await lessonAccessService.validateGuestSubscriptionAccess(phone, recid);
                accessType = accessValidation.canResumeSession ? 'guest_resumed' : 'guest';
            } else {
                console.log('Validating subscriber access for user_id:', user_id);
                accessValidation = await lessonAccessService.validateNonGuestSubscriptionAccess(user_id);
                accessType = accessValidation.canResumeSession ? 'subscriber_resumed' : 'subscriber';
            }

            if (!accessValidation.valid) {
                console.log('❌ ACCESS DENIED:', accessValidation.reason, 'Code:', accessValidation.code);
                await s3CloudFrontService.logSecurityEvent('ACCESS_DENIED', {
                    userId: user_id,
                    phone,
                    lessonId: recid,
                    reason: accessValidation.reason,
                    code: accessValidation.code,
                    ip: clientInfo.ipAddress
                });
                return res.unauthorized({
                    message: accessValidation.reason,
                    code: accessValidation.code
                });
            }
            console.log('✅ ACCESS GRANTED - Type:', accessType);

            console.log('=== LESSON SETTINGS CHECK ===');
            const subscriptionType = guest === 'true' ? 'non_subscribed' : 'subscribed';
            const lessonSetting = await DB.LessonSetting.findOne({
                where: { subscription_type: subscriptionType }
            });

            if (!lessonSetting) {
                console.log('❌ Lesson settings not found for type:', subscriptionType);
                await s3CloudFrontService.logSecurityEvent('SETTINGS_NOT_FOUND', {
                    userId: user_id,
                    lessonId: recid,
                    subscriptionType
                });
                return res.serverError('Lesson settings not found for subscription type: ' + subscriptionType);
            }

            const now = new Date();
            let existingSession = accessValidation.activeSession;

            console.log('=== ENHANCED SESSION MANAGEMENT ===');
            if (existingSession) {
                console.log('🔄 RESUMING EXISTING SESSION');
                sessionExpiresAt = existingSession.expires_at;
                sessionId = existingSession.session_id;
            } else {
                console.log('🆕 CREATING NEW SESSION');
                sessionExpiresAt = new Date(now.getTime() + (lessonSetting.duration * 60 * 1000));
                
                // For subscribers, consume a lesson if this is a new session
                if (guest === 'false' && !accessValidation.canResumeSession) {
                    console.log('📊 CONSUMING LESSON FOR SUBSCRIBER');
                    const subscription = accessValidation.subscription;
                    
                    await DB.LessonTrack.update({
                        lessons_viewed: (subscription.lessons_viewed || 0) + 1,
                        lesson_balance: (subscription.lesson_balance || 0) - 1,
                        last_accessed: now
                    }, {
                        where: { id: subscription.id }
                    });
                    
                    await s3CloudFrontService.logSecurityEvent('LESSON_CONSUMED', {
                        userId: user_id,
                        lessonId: recid,
                        previousBalance: subscription.lesson_balance,
                        newBalance: (subscription.lesson_balance || 0) - 1,
                        sessionId
                    });
                }
            }

            console.log('=== LESSON RECORD FETCH ===');
            const record = await DB.Lessons.findOne({ 
                where: { id: recid },
                include: [
                    {
                        model: DB.LearningAreas,
                        as: 'learning_area',
                        attributes: ['id', 'name']
                    },
                    {
                        model: DB.Topics,
                        as: 'topic',
                        attributes: ['topic_id', 'name'] 
                    },
                    {
                        model: DB.Subtopics,
                        as: 'subtopic',
                        attributes: ['subtopic_id', 'name'] 
                    }
                ]
            });
            
            if (!record) {
                console.log('❌ Lesson not found with ID:', recid);
                await s3CloudFrontService.logSecurityEvent('LESSON_NOT_FOUND', {
                    userId: user_id,
                    lessonId: recid
                });
                return res.notFound('Lesson not found');
            }
            
            if (!record.s3_key) {
                console.log('❌ Lesson video not available on AWS S3');
                await s3CloudFrontService.logSecurityEvent('S3_KEY_MISSING', {
                    userId: user_id,
                    lessonId: recid,
                    lessonTitle: record.title
                });
                return res.badRequest('Lesson video not available on AWS S3');
            }
            
            console.log('=== ENHANCED SECURE URL GENERATION ===');
            // Calculate URL expiration based on session expiration
            const sessionTimeRemaining = Math.floor((new Date(sessionExpiresAt) - now) / 1000);
            const urlExpiresIn = Math.min(
                parseInt(expiresIn), 
                sessionTimeRemaining,
                config.session.maxDuration
            );
            
            console.log('Generating SECURE signed URL for S3 key:', record.s3_key);
            
            // Generate SECURE signed URL with enhanced security features
            const secureStreamData = await s3CloudFrontService.generateSecureSignedUrl(
                record.s3_key, 
                user_id || phone, // Use user_id for subscribers, phone for guests
                recid,
                {
                    ipAddress: clientInfo.ipAddress,
                    userAgent: clientInfo.userAgent,
                    disableDownload: true,
                    maxPlays: 3, // Allow up to 3 plays per token
                    expiresIn: urlExpiresIn
                }
            );

            console.log('✅ Enhanced secure URL generated with token:', secureStreamData.tokenId);

            console.log('=== ENHANCED ACCESS LOGGING ===');
            // Create or update lesson access log with security context
            try {
                await lessonAccessService.createOrUpdateAccessLog({
                    user_id: guest === 'true' ? null : user_id,
                    phone: guest === 'true' ? phone : null,
                    lesson_id: recid,
                    access_type: accessType,
                    ip_address: clientInfo.ipAddress,
                    user_agent: clientInfo.userAgent,
                    session_id: sessionId,
                    expires_at: sessionExpiresAt,
                    lesson_setting_id: lessonSetting.id,
                    security_token: secureStreamData.tokenId, // Store security token
                    security_level: 'enhanced'
                }, existingSession);
                
                await s3CloudFrontService.logSecurityEvent('SECURE_STREAM_ACCESS_GRANTED', {
                    userId: user_id,
                    phone,
                    lessonId: recid,
                    sessionId,
                    tokenId: secureStreamData.tokenId,
                    expiresAt: new Date(secureStreamData.expiresAt).toISOString(),
                    security: secureStreamData.security,
                    accessType
                });
                
                console.log('✅ Enhanced access log created with security token');
            } catch (logError) {
                console.warn('⚠️ Failed to log enhanced access:', logError.message);
                await s3CloudFrontService.logSecurityEvent('ACCESS_LOG_ERROR', {
                    error: logError.message,
                    userId: user_id,
                    lessonId: recid
                });
            }

            console.log('=== VIEW COUNT CALCULATION ===');
            const viewCount = await DB.LessonAccessLogs.count({
                where: {
                    lesson_id: recid,
                    ...(guest === 'true' ? { phone } : { user_id })
                }
            });
            
            // Prepare enhanced response with security information
            const response = {
                success: true,
                video_url: secureStreamData.signedUrl,
                thumbnail_url: record.thumbnail_url,
                title: record.title,
                duration: record.duration,
                area: record.learning_area?.name,
                topic: record.topic?.name,
                subtopic: record.subtopic?.name,
                expires_in: urlExpiresIn,
                session_expires_in: sessionTimeRemaining,
                is_signed: true,
                access_type: accessType,
                session_id: sessionId,
                session_expires: sessionExpiresAt,
                view_count: viewCount,
                is_new_session: !existingSession,
                can_refresh: accessType.includes('resumed'),
                
                // Enhanced security information
                security: {
                    token_id: secureStreamData.tokenId,
                    token_expires: secureStreamData.expiresAt,
                    features: {
                        ip_restricted: secureStreamData.security.ipRestricted,
                        user_agent_restricted: secureStreamData.security.userAgentRestricted,
                        download_disabled: secureStreamData.security.disableDownload,
                        max_plays: secureStreamData.security.maxPlays,
                        requires_token_validation: true
                    }
                }
            };

            console.log('=== BALANCE INFORMATION ===');
            if (guest === 'true') {
                response.lessons_remaining = 'infinite';
                response.access_type_display = 'guest_resumed';
            } else {
                const subscription = accessValidation.subscription;
                if (subscription) {
                    response.lesson_balance = existingSession ? 
                        subscription.lesson_balance : 
                        Math.max(0, (subscription.lesson_balance || 0) - 1);
                    response.total_lessons = subscription.no_of_lessons;
                    response.lessons_viewed = existingSession ?
                        subscription.lessons_viewed :
                        (subscription.lessons_viewed || 0) + 1;
                    response.lessons_remaining = response.lesson_balance;
                }
            }

            console.log('=== ENHANCED RESPONSE COMPLETE ===');
            console.log('Enhanced security response prepared:', {
                hasSecureUrl: !!response.video_url,
                hasSecurityToken: !!response.security.token_id,
                securityFeatures: response.security.features,
                sessionId: response.session_id
            });

            console.log('=== ENHANCED SECURE STREAM URL REQUEST COMPLETED SUCCESSFULLY ===');
            return res.ok(response);
            
        } catch (error) {
            console.error('❌ ENHANCED STREAM URL REQUEST FAILED:', error);
            await s3CloudFrontService.logSecurityEvent('STREAM_URL_ERROR', {
                error: error.message,
                lessonId: req.params.recid,
                userId: req.user?.id,
                stack: error.stack
            });
            return res.serverError(error);
        }
    })
);

/**
 * Validate security token for video playback
 */
router.post('/validate-token/:sessionId',
    handleAsync(async (req, res) => {
        try {
            console.log('=== TOKEN VALIDATION REQUEST ===');
            const { sessionId } = req.params;
            const { tokenId, userId, clientInfo } = req.body;

            if (!tokenId || !userId || !clientInfo) {
                return res.badRequest({
                    message: 'Missing required fields: tokenId, userId, clientInfo',
                    code: 'MISSING_FIELDS'
                });
            }

            console.log('Token validation request:', {
                sessionId,
                tokenId,
                userId,
                clientInfo: {
                    ip: clientInfo.ipAddress,
                    userAgent: clientInfo.userAgent ? 'provided' : 'missing'
                }
            });

            // Validate the security token
            const videoKey = await s3CloudFrontService.validateVideoAccessToken(
                tokenId, 
                userId, 
                clientInfo
            );

            console.log('✅ Token validated successfully:', {
                tokenId,
                videoKey,
                sessionId
            });

            // Log successful validation
            await s3CloudFrontService.logSecurityEvent('TOKEN_VALIDATED_SUCCESS', {
                tokenId,
                userId,
                sessionId,
                videoKey,
                ip: clientInfo.ipAddress
            });

            res.json({
                success: true,
                valid: true,
                video_key: videoKey,
                message: 'Token validated successfully'
            });

        } catch (error) {
            console.error('❌ Token validation failed:', error.message);
            
            await s3CloudFrontService.logSecurityEvent('TOKEN_VALIDATION_FAILED', {
                tokenId: req.body.tokenId,
                userId: req.body.userId,
                sessionId: req.params.sessionId,
                error: error.message,
                ip: req.body.clientInfo?.ipAddress
            });

            res.status(403).json({
                success: false,
                valid: false,
                error: error.message,
                code: 'TOKEN_VALIDATION_FAILED'
            });
        }
    })
);
/**
 * Get security analytics and system stats
 */
router.get('/security/analytics',
    handleAsync(async (req, res) => {
        try {
            // Only allow admins
            if (req.user?.roleName !== 'admin') {
                return res.unauthorized({
                    message: 'Admin access required',
                    code: 'ADMIN_ACCESS_REQUIRED'
                });
            }

            const { timeframe = '7d' } = req.query;
            
            if (!['24h', '7d', '30d'].includes(timeframe)) {
                return res.badRequest({
                    error: 'Invalid timeframe. Use: 24h, 7d, or 30d',
                    code: 'INVALID_TIMEFRAME'
                });
            }

            const analytics = await s3CloudFrontService.getSecurityAnalytics(timeframe);
            const systemStats = s3CloudFrontService.getSystemStats();

            res.json({
                success: true,
                data: {
                    analytics,
                    system_stats: systemStats,
                    generated_at: new Date().toISOString()
                },
                message: 'Security analytics retrieved successfully'
            });

        } catch (error) {
            console.error('Error getting security analytics:', error);
            res.status(500).json({
                error: 'Failed to retrieve security analytics',
                code: 'ANALYTICS_ERROR'
            });
        }
    })
);
/**
 * Cache management endpoints (Admin only)
 */
router.get('/cache/stats',
    handleAsync(async (req, res) => {
        try {
            if (req.user?.role !== 'admin') {
                return res.unauthorized({
                    message: 'Admin access required',
                    code: 'ADMIN_ACCESS_REQUIRED'
                });
            }

            const cacheStats = s3CloudFrontService.getCacheStats();
            const systemStats = s3CloudFrontService.getSystemStats();

            res.json({
                success: true,
                data: {
                    cache_stats: cacheStats,
                    system_stats: systemStats
                },
                message: 'Cache statistics retrieved successfully'
            });

        } catch (error) {
            console.error('Error getting cache stats:', error);
            res.status(500).json({
                error: 'Failed to retrieve cache statistics',
                code: 'CACHE_STATS_ERROR'
            });
        }
    })
);

router.post('/cache/clear',
    handleAsync(async (req, res) => {
        try {
            if (req.user?.role !== 'admin') {
                return res.unauthorized({
                    message: 'Admin access required',
                    code: 'ADMIN_ACCESS_REQUIRED'
                });
            }

            s3CloudFrontService.clearCache();
            
            await s3CloudFrontService.logSecurityEvent('CACHE_CLEARED_ADMIN', {
                userId: req.user.id,
                clearedBy: req.user.email
            });

            res.json({
                success: true,
                message: 'Cache cleared successfully',
                data: {
                    cleared_at: new Date().toISOString(),
                    cleared_by: req.user.email
                }
            });

        } catch (error) {
            console.error('Error clearing cache:', error);
            res.status(500).json({
                error: 'Failed to clear cache',
                code: 'CACHE_CLEAR_ERROR'
            });
        }
    })
);
/*
 * Enhanced Route to get AWS CloudFront streaming URL with comprehensive security
 */
router.get('/stream-url/:recid',
    streamLimiter,
    validateLessonAccess,
    handleAsync(async (req, res) => {
        try {
            console.log('=== ENHANCED SECURE STREAM URL REQUEST START ===');
            const recid = req.params.recid;
            const { signed = 'true', expiresIn = 3600, guest = 'false' } = req.query;
            
            // Extract user info and client details for security
            const user_id = req.user?.id || req.query.user_id;
            const phone = req.query.phone;
            const clientInfo = {
                ipAddress: req.ip,
                userAgent: req.get('User-Agent')
            };

            console.log('Enhanced Request Parameters:', {
                recid,
                signed,
                expiresIn,
                guest,
                user_id,
                phone,
                clientInfo
            });

            let accessValidation;
            let accessType = '';
            let sessionExpiresAt;
            let sessionId = `${user_id || phone}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

            console.log('=== ENHANCED ACCESS VALIDATION ===');
            // Validate access based on user type
            if (guest === 'true') {
                console.log('Validating guest access for phone:', phone);
                accessValidation = await lessonAccessService.validateGuestSubscriptionAccess(phone, recid);
                accessType = accessValidation.canResumeSession ? 'guest_resumed' : 'guest';
            } else {
                console.log('Validating subscriber access for user_id:', user_id);
                accessValidation = await lessonAccessService.validateNonGuestSubscriptionAccess(user_id);
                accessType = accessValidation.canResumeSession ? 'subscriber_resumed' : 'subscriber';
            }

            if (!accessValidation.valid) {
                console.log('❌ ACCESS DENIED:', accessValidation.reason, 'Code:', accessValidation.code);
                await s3CloudFrontService.logSecurityEvent('ACCESS_DENIED', {
                    userId: user_id,
                    phone,
                    lessonId: recid,
                    reason: accessValidation.reason,
                    code: accessValidation.code,
                    ip: clientInfo.ipAddress
                });
                return res.unauthorized({
                    message: accessValidation.reason,
                    code: accessValidation.code
                });
            }
            console.log('✅ ACCESS GRANTED - Type:', accessType);

            console.log('=== LESSON SETTINGS CHECK ===');
            const subscriptionType = guest === 'true' ? 'non_subscribed' : 'subscribed';
            const lessonSetting = await DB.LessonSetting.findOne({
                where: { subscription_type: subscriptionType }
            });

            if (!lessonSetting) {
                console.log('❌ Lesson settings not found for type:', subscriptionType);
                await s3CloudFrontService.logSecurityEvent('SETTINGS_NOT_FOUND', {
                    userId: user_id,
                    lessonId: recid,
                    subscriptionType
                });
                return res.serverError('Lesson settings not found for subscription type: ' + subscriptionType);
            }

            const now = new Date();
            let existingSession = accessValidation.activeSession;

            console.log('=== ENHANCED SESSION MANAGEMENT ===');
            if (existingSession) {
                console.log('🔄 RESUMING EXISTING SESSION');
                sessionExpiresAt = existingSession.expires_at;
                sessionId = existingSession.session_id;
            } else {
                console.log('🆕 CREATING NEW SESSION');
                sessionExpiresAt = new Date(now.getTime() + (lessonSetting.duration * 60 * 1000));
                
                // For subscribers, consume a lesson if this is a new session
                if (guest === 'false' && !accessValidation.canResumeSession) {
                    console.log('📊 CONSUMING LESSON FOR SUBSCRIBER');
                    const subscription = accessValidation.subscription;
                    
                    await DB.LessonTrack.update({
                        lessons_viewed: (subscription.lessons_viewed || 0) + 1,
                        lesson_balance: (subscription.lesson_balance || 0) - 1,
                        last_accessed: now
                    }, {
                        where: { id: subscription.id }
                    });
                    
                    await s3CloudFrontService.logSecurityEvent('LESSON_CONSUMED', {
                        userId: user_id,
                        lessonId: recid,
                        previousBalance: subscription.lesson_balance,
                        newBalance: (subscription.lesson_balance || 0) - 1,
                        sessionId
                    });
                }
            }

            console.log('=== LESSON RECORD FETCH ===');
            const record = await DB.Lessons.findOne({ 
                where: { id: recid },
                include: [
                    {
                        model: DB.LearningAreas,
                        as: 'learning_area',
                        attributes: ['id', 'name']
                    },
                    {
                        model: DB.Topics,
                        as: 'topic',
                        attributes: ['topic_id', 'name'] 
                    },
                    {
                        model: DB.Subtopics,
                        as: 'subtopic',
                        attributes: ['subtopic_id', 'name'] 
                    }
                ]
            });
            
            if (!record) {
                console.log('❌ Lesson not found with ID:', recid);
                await s3CloudFrontService.logSecurityEvent('LESSON_NOT_FOUND', {
                    userId: user_id,
                    lessonId: recid
                });
                return res.notFound('Lesson not found');
            }
            
            if (!record.s3_key) {
                console.log('❌ Lesson video not available on AWS S3');
                await s3CloudFrontService.logSecurityEvent('S3_KEY_MISSING', {
                    userId: user_id,
                    lessonId: recid,
                    lessonTitle: record.title
                });
                return res.badRequest('Lesson video not available on AWS S3');
            }
            
            console.log('=== ENHANCED SECURE URL GENERATION ===');
            // Calculate URL expiration based on session expiration
            const sessionTimeRemaining = Math.floor((new Date(sessionExpiresAt) - now) / 1000);
            const urlExpiresIn = Math.min(
                parseInt(expiresIn), 
                sessionTimeRemaining,
                config.session.maxDuration
            );
            
            console.log('Generating SECURE signed URL for S3 key:', record.s3_key);
            
            // Generate SECURE signed URL with enhanced security features
            const secureStreamData = await s3CloudFrontService.generateSecureSignedUrl(
                record.s3_key, 
                user_id || phone, // Use user_id for subscribers, phone for guests
                recid,
                {
                    ipAddress: clientInfo.ipAddress,
                    userAgent: clientInfo.userAgent,
                    disableDownload: true,
                    maxPlays: 3, // Allow up to 3 plays per token
                    expiresIn: urlExpiresIn
                }
            );

            console.log('✅ Enhanced secure URL generated with token:', secureStreamData.tokenId);

            console.log('=== ENHANCED ACCESS LOGGING ===');
            // Create or update lesson access log with security context
            try {
                await lessonAccessService.createOrUpdateAccessLog({
                    user_id: guest === 'true' ? null : user_id,
                    phone: guest === 'true' ? phone : null,
                    lesson_id: recid,
                    access_type: accessType,
                    ip_address: clientInfo.ipAddress,
                    user_agent: clientInfo.userAgent,
                    session_id: sessionId,
                    expires_at: sessionExpiresAt,
                    lesson_setting_id: lessonSetting.id,
                    security_token: secureStreamData.tokenId, // Store security token
                    security_level: 'enhanced'
                }, existingSession);
                
                await s3CloudFrontService.logSecurityEvent('SECURE_STREAM_ACCESS_GRANTED', {
                    userId: user_id,
                    phone,
                    lessonId: recid,
                    sessionId,
                    tokenId: secureStreamData.tokenId,
                    expiresAt: new Date(secureStreamData.expiresAt).toISOString(),
                    security: secureStreamData.security,
                    accessType
                });
                
                console.log('✅ Enhanced access log created with security token');
            } catch (logError) {
                console.warn('⚠️ Failed to log enhanced access:', logError.message);
                await s3CloudFrontService.logSecurityEvent('ACCESS_LOG_ERROR', {
                    error: logError.message,
                    userId: user_id,
                    lessonId: recid
                });
            }

            console.log('=== VIEW COUNT CALCULATION ===');
            const viewCount = await DB.LessonAccessLogs.count({
                where: {
                    lesson_id: recid,
                    ...(guest === 'true' ? { phone } : { user_id })
                }
            });
            
            // Prepare enhanced response with security information
            const response = {
                success: true,
                video_url: secureStreamData.signedUrl,
                thumbnail_url: record.thumbnail_url,
                title: record.title,
                duration: record.duration,
                area: record.learning_area?.name,
                topic: record.topic?.name,
                subtopic: record.subtopic?.name,
                expires_in: urlExpiresIn,
                session_expires_in: sessionTimeRemaining,
                is_signed: true,
                access_type: accessType,
                session_id: sessionId,
                session_expires: sessionExpiresAt,
                view_count: viewCount,
                is_new_session: !existingSession,
                can_refresh: accessType.includes('resumed'),
                
                // Enhanced security information
                security: {
                    token_id: secureStreamData.tokenId,
                    token_expires: secureStreamData.expiresAt,
                    features: {
                        ip_restricted: secureStreamData.security.ipRestricted,
                        user_agent_restricted: secureStreamData.security.userAgentRestricted,
                        download_disabled: secureStreamData.security.disableDownload,
                        max_plays: secureStreamData.security.maxPlays,
                        requires_token_validation: true
                    }
                }
            };

            console.log('=== BALANCE INFORMATION ===');
            if (guest === 'true') {
                response.lessons_remaining = 'infinite';
                response.access_type_display = 'guest_resumed';
            } else {
                const subscription = accessValidation.subscription;
                if (subscription) {
                    response.lesson_balance = existingSession ? 
                        subscription.lesson_balance : 
                        Math.max(0, (subscription.lesson_balance || 0) - 1);
                    response.total_lessons = subscription.no_of_lessons;
                    response.lessons_viewed = existingSession ?
                        subscription.lessons_viewed :
                        (subscription.lessons_viewed || 0) + 1;
                    response.lessons_remaining = response.lesson_balance;
                }
            }

            console.log('=== ENHANCED RESPONSE COMPLETE ===');
            console.log('Enhanced security response prepared:', {
                hasSecureUrl: !!response.video_url,
                hasSecurityToken: !!response.security.token_id,
                securityFeatures: response.security.features,
                sessionId: response.session_id
            });

            console.log('=== ENHANCED SECURE STREAM URL REQUEST COMPLETED SUCCESSFULLY ===');
            return res.ok(response);
            
        } catch (error) {
            console.error('❌ ENHANCED STREAM URL REQUEST FAILED:', error);
            await s3CloudFrontService.logSecurityEvent('STREAM_URL_ERROR', {
                error: error.message,
                lessonId: req.params.recid,
                userId: req.user?.id,
                stack: error.stack
            });
            return res.serverError(error);
        }
    })
);
/**
 * Additional endpoint to check subscription status without consuming lessons
 */
router.get('/check-access/:recid',
    validateLessonAccess,
    handleAsync(async (req, res) => {
        try {
            const recid = req.params.recid;
            const { guest = 'false' } = req.query;
            const user_id = req.user?.uid || req.query.user_id;
            const phone = req.query.phone;

            let accessValidation;
            
            if (guest === 'true') {
                accessValidation = await lessonAccessService.validateGuestSubscriptionAccess(phone, recid);
            } else {
                accessValidation = await lessonAccessService.validateNonGuestSubscriptionAccess(user_id);
            }

            return res.ok({
                has_access: accessValidation.valid,
                reason: accessValidation.reason,
                code: accessValidation.code,
                type: accessValidation.type,
                ...(accessValidation.valid && guest === 'true' && {
                    views_remaining: accessValidation.views_remaining
                }),
                ...(accessValidation.valid && guest === 'false' && {
                    lesson_balance: accessValidation.lesson_balance,
                    total_lessons: accessValidation.no_of_lessons, // FIXED: Use no_of_lessons
                    lessons_viewed: accessValidation.lessons_viewed,
                    can_resume: accessValidation.canResumeSession
                })
            });
            
        } catch (error) {
            console.error('Error checking access:', error);
            return res.serverError(error);
        }
    })
);
// Endpoint to mark session as completed or expired
router.post('/session-complete/:sessionId',
    validateSessionComplete,
    handleAsync(async (req, res) => {
        try {
            const { sessionId } = req.params;
            const completionData = req.body;

            const result = await lessonAccessService.completeSession(sessionId, completionData);
            return res.ok(result);
            
        } catch (error) {
            console.error('Error updating session:', error);
            return res.serverError(error);
        }
    })
);

/**
 * Route to get lessons by learning area
 */
router.get('/by-area/:areaId',
    handleAsync(async (req, res) => {
        try {
            const areaId = req.params.areaId;
            const { page = 1, limit = 10 } = req.query;
            
            const query = {};
            const where = {};
            where['area_id'] = areaId;
            where['is_active'] = true;
            
            query.raw = false;
            query.where = where;
            query.order = DB.getOrderBy(req, 'sort_order', 'asc');
            query.attributes = DB.Lessons.listFields();
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name'] 
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name'] 
                }
            ];
            
            let result = await DB.Lessons.paginate(query, parseInt(page), parseInt(limit));
            return res.ok(result);
            
        } catch (error) {
            console.error('Error getting lessons by area:', error);
            return res.serverError(error);
        }
    })
);

/**
 * Route to get lessons by topic
 */
router.get('/by-topic/:topicId',
    handleAsync(async (req, res) => {
        try {
            const topicId = req.params.topicId;
            const { page = 1, limit = 10 } = req.query;
            
            const query = {};
            const where = {};
            where['topic_id'] = topicId;
            where['is_active'] = true;
            
            query.raw = false;
            query.where = where;
            query.order = DB.getOrderBy(req, 'sort_order', 'asc');
            query.attributes = DB.Lessons.listFields();
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name'] 
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name'] 
                }
            ];
            
            let result = await DB.Lessons.paginate(query, parseInt(page), parseInt(limit));
            return res.ok(result);
            
        } catch (error) {
            console.error('Error getting lessons by topic:', error);
            return res.serverError(error);
        }
    })
);

/**
 * Route to get lessons by subtopic
 */
router.get('/by-subtopic/:subtopicId',
    handleAsync(async (req, res) => {
        try {
            const subtopicId = req.params.subtopicId;
            const { page = 1, limit = 10 } = req.query;
            
            const query = {};
            const where = {};
            where['subtopic_id'] = subtopicId;
            where['is_active'] = true;
            
            query.raw = false;
            query.where = where;
            query.order = DB.getOrderBy(req, 'sort_order', 'asc');
            query.attributes = DB.Lessons.listFields();
            
            query.include = [
                {
                    model: DB.LearningAreas,
                    as: 'learning_area',
                    attributes: ['id', 'name']
                },
                {
                    model: DB.Topics,
                    as: 'topic',
                    attributes: ['topic_id', 'name'] 
                },
                {
                    model: DB.Subtopics,
                    as: 'subtopic',
                    attributes: ['subtopic_id', 'name'] 
                }
            ];
            
            let result = await DB.Lessons.paginate(query, parseInt(page), parseInt(limit));
            return res.ok(result);
            
        } catch (error) {
            console.error('Error getting lessons by subtopic:', error);
            return res.serverError(error);
        }
    })
);

// Global error handler for this router
router.use((error, req, res, next) => {
    console.error('Lesson router error:', error);
    
    if (error.name === 'ValidationError') {
        return res.badRequest({
            message: 'Validation failed',
            errors: error.errors
        });
    }
    
    if (error.code === 'RATE_LIMIT_EXCEEDED') {
        return res.tooManyRequests(error);
    }
    
    return res.serverError(error);
});

export default router;