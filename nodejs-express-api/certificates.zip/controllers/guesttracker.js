import { Router } from 'express';

import { body } from 'express-validator';

import validateFormData from '../helpers/validate_form.js';

import DB from '../models/db.js';





const router = Router();









/**

 * Route to list guesttracker records

 * @GET /guesttracker/index/{fieldname}/{fieldvalue}

 */

router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  

	try{

		const query = {};

		let queryFilters = [];

		let where = {};

		let replacements = {};

		let fieldName = req.params.fieldname;

		let fieldValue = req.params.fieldvalue;

		

		if (fieldName){

			queryFilters.push(DB.filterBy(fieldName, fieldValue));

		}

		let search = req.query.search;

		if(search){

			let searchFields = DB.GuestTracker.searchFields();

			where[DB.op.or] = searchFields;

			replacements.search = `%${search}%`;

		}

		

		if(queryFilters.length){

			where[DB.op.and] = queryFilters;

		}

		query.raw = true;

		query.where = where;

		query.replacements = replacements;

		query.order = DB.getOrderBy(req, 'id', 'desc');

		query.attributes = DB.GuestTracker.listFields();

		let page = parseInt(req.query.page) || 1;

		let limit = parseInt(req.query.limit) || 10;

		let relesson_id = await DB.GuestTracker.paginate(query, page, limit);

		return res.ok(result);

	}

	catch(err) {

		return res.serverError(err);

	}

});





/**

 * Route to view GuestTracker record

 * @GET /guesttracker/view/{recid}

 */

router.get('/view/:recid', async (req, res) => {

	try{

		const recid = req.params.recid || null;

		const query = {}

		const where = {}

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.GuestTracker.viewFields();

		let record = await DB.GuestTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		return res.ok(record);

	}

	catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to insert GuestTracker record

 * @POST /guesttracker/add

 */

router.post('/add/', 

	[

		body('phone').optional({nullable: true, checkFalsy: true}),

		body('fingerprint').optional({nullable: true, checkFalsy: true}),

		body('resumetime').optional({nullable: true, checkFalsy: true}),

		body('timeviewtime').optional({nullable: true, checkFalsy: true}),

		body('lesson_id').not().isEmpty(),

		body('status').optional({nullable: true, checkFalsy: true}),

		body('transaction_id').optional({nullable: true, checkFalsy: true}),

	], validateFormData

, async function (req, res) {

	try{

		let modeldata = req.getValidFormData();

		

		//save GuestTracker record

		let record = await DB.GuestTracker.create(modeldata);

		//await record.reload(); //reload the record from database

		const recid =  record['id'];

		

		return res.ok(record);

	} catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to get  GuestTracker record for edit

 * @GET /guesttracker/edit/{recid}

 */

router.get('/edit/:recid', async (req, res) => {

	try{

		const recid = req.params.recid;

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.GuestTracker.editFields();

		let record = await DB.GuestTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		return res.ok(record);

	}

	catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to update  GuestTracker record

 * @POST /guesttracker/edit/{recid}

 */

router.post('/edit/:recid', 

	[

		body('phone').optional({nullable: true, checkFalsy: true}),

		body('fingerprint').optional({nullable: true, checkFalsy: true}),

		body('resumetime').optional({nullable: true, checkFalsy: true}),

		body('timeviewtime').optional({nullable: true, checkFalsy: true}),

		body('lesson_id').optional({nullable: true}).not().isEmpty(),

		body('status').optional({nullable: true, checkFalsy: true}),

		body('transaction_id').optional({nullable: true, checkFalsy: true}),

	], validateFormData

, async (req, res) => {

	try{

		const recid = req.params.recid;

		let modeldata = req.getValidFormData({ includeOptionals: true });

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.GuestTracker.editFields();

		let record = await DB.GuestTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		await DB.GuestTracker.update(modeldata, {where: where});

		return res.ok(modeldata);

	}

	catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to delete GuestTracker record by table primary key

 * Multi delete supported by recid separated by comma(,)

 * @GET /guesttracker/delete/{recid}

 */

router.get('/delete/:recid', async (req, res) => {

	try{

		const recid = (req.params.recid || '').split(',');

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		let records = await DB.GuestTracker.findAll(query);

		records.forEach(async (record) => { 

			//perform action on each record before delete

		});

		await DB.GuestTracker.destroy(query);

		return res.ok(recid);

	}

	catch(err){

		return res.serverError(err);

	}

});

export default router;

