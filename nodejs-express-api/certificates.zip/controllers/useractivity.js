import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list useractivity records
 * @GET /useractivity/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.UserActivity.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'activity_id', 'desc');
		query.attributes = DB.UserActivity.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.UserActivity.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view UserActivity record
 * @GET /useractivity/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['activity_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserActivity.viewFields();
		let record = await DB.UserActivity.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert UserActivity record
 * @POST /useractivity/add
 */
router.post('/add/', 
	[
		body('user_id').optional({nullable: true, checkFalsy: true}),
		body('fingerprint').optional({nullable: true, checkFalsy: true}),
		body('session_duration').not().isEmpty().isNumeric(),
		body('status').not().isEmpty(),
		body('activity_type').not().isEmpty(),
		body('platiform').not().isEmpty(),
		body('device').not().isEmpty(),
		body('ip_address').not().isEmpty(),
		body('phone').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save UserActivity record
		let record = await DB.UserActivity.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['activity_id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  UserActivity record for edit
 * @GET /useractivity/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['activity_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserActivity.editFields();
		let record = await DB.UserActivity.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  UserActivity record
 * @POST /useractivity/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('user_id').optional({nullable: true, checkFalsy: true}),
		body('fingerprint').optional({nullable: true, checkFalsy: true}),
		body('session_duration').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('status').optional({nullable: true}).not().isEmpty(),
		body('activity_type').optional({nullable: true}).not().isEmpty(),
		body('platiform').optional({nullable: true}).not().isEmpty(),
		body('device').optional({nullable: true}).not().isEmpty(),
		body('ip_address').optional({nullable: true}).not().isEmpty(),
		body('phone').optional({nullable: true}).not().isEmpty(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['activity_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.UserActivity.editFields();
		let record = await DB.UserActivity.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.UserActivity.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete UserActivity record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /useractivity/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['activity_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.UserActivity.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.UserActivity.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
