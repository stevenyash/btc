// routes/learningHierarchyRoutes.js
import { Router } from 'express';
import learningHierarchyService from '../services/learningHierarchyService.js';

const router = Router();

/**
 * Get complete learning hierarchy
 * @GET /learning-hierarchy
 */
router.get('/', async (req, res) => {
  try {
    const hierarchy = await learningHierarchyService.getCompleteHierarchy();
    res.json({ success: true, data: hierarchy });
  } catch (error) {
    console.error('Error getting learning hierarchy:', error);
    res.serverError(error);
  }
});

/**
 * Search lessons across all learning areas
 * @GET /learning-hierarchy/search
 */
router.get('/search', async (req, res) => {
  try {
    const { q: query } = req.query;
    if (!query) {
      return res.badRequest('Search query is required');
    }
    
    const results = await learningHierarchyService.searchLessons(query);
    res.json({ success: true, data: results, query });
  } catch (error) {
    console.error('Error searching lessons:', error);
    res.serverError(error);
  }
});

/**
 * Get learning path for a specific lesson
 * @GET /learning-hierarchy/lessons/:lessonId/path
 */
router.get('/lessons/:lessonId/path', async (req, res) => {
  try {
    const path = await learningHierarchyService.getLearningPath(req.params.lessonId);
    if (!path) {
      return res.notFound('Lesson not found');
    }
    res.json({ success: true, data: path });
  } catch (error) {
    console.error('Error getting learning path:', error);
    res.serverError(error);
  }
});

/**
 * Get popular learning areas for dashboard
 * @GET /learning-hierarchy/popular-areas
 */
router.get('/popular-areas', async (req, res) => {
  try {
    const { limit = 6 } = req.query;
    const areas = await learningHierarchyService.getPopularLearningAreas(parseInt(limit));
    res.json({ success: true, data: areas });
  } catch (error) {
    console.error('Error getting popular areas:', error);
    res.serverError(error);
  }
});

export default router;