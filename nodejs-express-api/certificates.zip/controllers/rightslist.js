import { Router } from 'express';


import DB from '../models/db.js';








const router = Router();














/**


 * Route to list rightslist records


 * @GET /rightslist/index/{fieldname}/{fieldvalue}


 */


router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  


	try{


		const query = {};


		let queryFilters = [];


		let where = {};


		let replacements = {};


		let fieldName = req.params.fieldname;


		let fieldValue = req.params.fieldvalue;


		


		if (fieldName){


			queryFilters.push(DB.filterBy(fieldName, fieldValue));


		}


		let search = req.query.search;


		if(search){


			let searchFields = DB.Rightslist.searchFields();


			where[DB.op.or] = searchFields;


			replacements.search = `%${search}%`;


		}


		


		if(req.query.permission){


			queryFilters.push(DB.filterBy("rightslist.permission", req.query.permission))


		}


		if(req.query.user_id){


			queryFilters.push(DB.filterBy("rightslist.user_id", req.query.user_id))


		}


		if(queryFilters.length){


			where[DB.op.and] = queryFilters;


		}


		query.raw = true;


		query.where = where;


		query.replacements = replacements;


		query.order = DB.getOrderBy(req, 'permission_id', 'desc');


		query.attributes = DB.Rightslist.listFields();


		let page = parseInt(req.query.page) || 1;


		let limit = parseInt(req.query.limit) || 10;


		let result = await DB.Rightslist.paginate(query, page, limit);


		return res.ok(result);


	}


	catch(err) {


		return res.serverError(err);


	}


});


export default router;


