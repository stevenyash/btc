import { Router } from 'express';
import DB from '../models/db.js';


const router = Router();





/**
 * Route to list records based on custom sql query
 * @GET /activeindividualpackage
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'],  async (req, res) => {
	try{
		let sqltext = `SELECT      p.id AS purchase_id,         pk.name AS package_name,     p.transaction_date,     p.expiry_date,     CASE          WHEN p.expiry_date <= NOW() THEN 'expired'         ELSE 'active'     END AS status FROM      purchases p JOIN      users u ON p.user_id = u.id JOIN      packages pk ON p.package_id = pk.id  WHERE      u.id=:user_id` ;
		let queryParams = {};
queryParams['user_id'] = req.user.id
		let records = await DB.rawQueryList(sqltext, queryParams,);
		let recordCount = records.length;
		let totalRecords = record_count;
		let totalPages = 1;
		let data = {
			totalRecords,
			recordCount,
			totalPages,
			records
		}
		return res.ok(data);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
