import { Router } from 'express';
import { body } from 'express-validator';
import utils from '../helpers/utils.js';
import uploader from '../helpers/uploader.js';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list users records
 * @GET /users/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		const joinTables = []; // hold list of join tables
		joinTables.push({
			model: DB.Roles,
			required: true,
			as: 'roles',
			attributes: [], //already set via model class
		})
		query.include = joinTables;
		let search = req.query.search;
		if(search){
			let searchFields = DB.Users.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		where['role_name'] != "subcriber";
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Users.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Users.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Users record
 * @GET /users/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		const joinTables = []; // hold list of join tables
		joinTables.push({
			model: DB.Roles,
			required: true,
			as: 'roles',
			attributes: [], //already set via model class
		})
		query.include = joinTables;
		where[DB.op.and] = DB.raw('users.id = :recid');
		query.replacements = {
			recid
		}
		query.raw = true;
		query.where = where;
		query.attributes = DB.Users.viewFields();
		let record = await DB.Users.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Users record
 * @POST /users/add
 */
router.post('/add/', 
	[
		body('image').optional({nullable: true, checkFalsy: true}),
		body('email').not().isEmpty().isEmail(),
		body('username').not().isEmpty(),
		body('phone').optional({nullable: true, checkFalsy: true}),
		body('password').not().isEmpty(),
		body('user_role_id').not().isEmpty(),
		body('account_status').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		modeldata.password = utils.passwordHash(modeldata.password);
		
		// set default role for user
		const roleId =  await DB.Roles.findValue('role_id', {role_name: 'subscriber'});
		modeldata['user_role_id'] = roleId;
		
		// check if email already exist.
		let emailCount = await DB.Users.count({ where:{ 'email': modeldata.email } });
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		
		// check if username already exist.
		let usernameCount = await DB.Users.count({ where:{ 'username': modeldata.username } });
		if(usernameCount > 0){
			return res.badRequest(`${modeldata.username} already exist.`);
		}
		
        // move uploaded file from temp directory to destination directory
		if(modeldata.image !== undefined) {
			const fileInfo = uploader.moveUploadedFiles(modeldata.image, 'image');
			modeldata.image = fileInfo.filepath;
		}
		await beforeAdd(modeldata, req);
		
		//save Users record
		let record = await DB.Users.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});
/**
* Before create new record
* @param {object} postdata // validated form data used to create new record
*/
async function beforeAdd(postdata, req){
    //enter statement here
    console.log(req.body.user_role_id);
        postdata['user_role_id'] =req.body.user_role_id 
}


/**
 * Route to get  Users record for edit
 * @GET /users/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Users.editFields();
		let record = await DB.Users.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Users record
 * @POST /users/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('image').optional({nullable: true, checkFalsy: true}),
		body('username').optional({nullable: true}).not().isEmpty(),
		body('phone').optional({nullable: true, checkFalsy: true}),
		body('user_role_id').optional({nullable: true}).not().isEmpty(),
		body('nhif').optional({nullable: true, checkFalsy: true}),
		body('nssf').optional({nullable: true, checkFalsy: true}),
		body('national_id').optional({nullable: true, checkFalsy: true}),
		body('account_status').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		
		// check if username already exist.
		let usernameCount = await DB.Users.count({where:{'username': modeldata.username, 'id': {[DB.op.ne]: recid} }});
		if(usernameCount > 0){
			return res.badRequest(`${modeldata.username} already exist.`);
		}
		
        // move uploaded file from temp directory to destination directory
		if(modeldata.image !== undefined) {
			const fileInfo = uploader.moveUploadedFiles(modeldata.image, 'image');
			modeldata.image = fileInfo.filepath;
		}
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Users.editFields();
		let record = await DB.Users.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Users.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Users record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /users/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Users.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Users.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Users record
 * @POST /users/add
 */
router.post('/subscribeuser/', 
	[
		body('phone').not().isEmpty(),
		body('email').not().isEmpty().isEmail(),
		body('password').not().isEmpty(),
		body('confirm_password', 'Passwords do not match').custom((value, {req}) => (value === req.body.password)),
		body('image').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		modeldata.password = utils.passwordHash(modeldata.password);
		
		// set default role for user
		const roleId =  await DB.Roles.findValue('role_id', {role_name: 'subscriber'});
		modeldata['user_role_id'] = roleId;
		
		// check if phone already exist.
		let phoneCount = await DB.Users.count({ where:{ 'phone': modeldata.phone } });
		if(phoneCount > 0){
			return res.badRequest(`${modeldata.phone} already exist.`);
		}
		
		// check if email already exist.
		let emailCount = await DB.Users.count({ where:{ 'email': modeldata.email } });
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		
        // move uploaded file from temp directory to destination directory
		if(modeldata.image !== undefined) {
			const fileInfo = uploader.moveUploadedFiles(modeldata.image, 'image');
			modeldata.image = fileInfo.filepath;
		}
		await beforeSubscribeuser(modeldata, req);
		
		//save Users record
		let record = await DB.Users.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		await afterSubscribeuser(record, req);
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});
import crypto from "crypto";
async function beforeSubscribeuser(postdata, req) {
    try {
        let subscription_code;
        let isUnique = false;
        // Generate unique subscription code
        while (!isUnique) {
            subscription_code = crypto.randomBytes(4).toString("hex").toUpperCase(); // Generate an 8-character code
            // Check if the code is unique in the database
            const record = await DB.Users.findOne({ where: { subscription_code } });
            isUnique = !record; // Exit loop if the code is unique
        }
        // Assign the unique code to postdata
        postdata.password = utils.passwordHash(subscription_code);
        postdata.subscription_code = subscription_code;
        console.log(postdata)
    } catch (error) {
        console.error("Error in beforeSubscribeUser:", error);
        throw new Error("An error occurred while creating a subscription.");
    }
}
/**
* After new record is created
* @param {object} record // newly created record
*/
async function afterSubscribeuser(record, req) {
    try {
        // Activate the user's account
        await DB.Users.update(
            { account_status: 'active' },
            { where: { id: record.id } }
        );
        // Check if user was referred
        if (record.referred_by) {
            let marketer = await DB.Marketers.findOne({ where: { referral_code: record.referred_by } });
            if (marketer) {
                // Increase referral points
                await DB.Marketers.update(


                    { points: marketer.points + 1 },


                    { where: { referral_code: record.referred_by } }


                );


        let inviteData = {


            status: 'accepted',


            }

        let newUser = await DB.Invites.update(inviteData, { where: { referral_code: record.referred_by } });
            }
        }
    } catch (error) {
        console.error("Error in afterSubscribeuser:", error);
    }
}


/**
 * Route to list users records
 * @GET /users/index/{fieldname}/{fieldvalue}
 */
router.get('/referrals/:fieldname?/:fieldvalue?', async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Users.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Users.referralsFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Users.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});
export default router;
