import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list lessontrack records
 * @GET /lessontrack/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.LessonTrack.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.LessonTrack.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.LessonTrack.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view LessonTrack record
 * @GET /lessontrack/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LessonTrack.viewFields();
		let record = await DB.LessonTrack.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert LessonTrack record
 * @POST /lessontrack/add
 */
router.post('/add/', 
	[
		body('subscription_id').not().isEmpty().isNumeric(),
		body('user_id').not().isEmpty().isNumeric(),
		body('lessons_viewed').not().isEmpty().isNumeric(),
		body('lesson_balance').not().isEmpty().isNumeric(),
		body('total_lessons').not().isEmpty().isNumeric(),
		body('package_id').not().isEmpty().isNumeric(),
		body('status').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save LessonTrack record
		let record = await DB.LessonTrack.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  LessonTrack record for edit
 * @GET /lessontrack/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LessonTrack.editFields();
		let record = await DB.LessonTrack.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  LessonTrack record
 * @POST /lessontrack/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('subscription_id').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('user_id').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('lessons_viewed').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('lesson_balance').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('total_lessons').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('package_id').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('status').optional({nullable: true}).not().isEmpty(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LessonTrack.editFields();
		let record = await DB.LessonTrack.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.LessonTrack.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete LessonTrack record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /lessontrack/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.LessonTrack.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.LessonTrack.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
