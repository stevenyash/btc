import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';



const router = Router();



/**
 * Route to list assignrights records
 * @GET /assignrights/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		
		let search = req.query.search;
		if(search){
			let searchFields = DB.AssignRights.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.AssignRights.listFields();
		
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.AssignRights.paginate(query, page, limit);
		
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});



/**
 * Route to view AssignRights record
 * @GET /assignrights/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.AssignRights.viewFields();
		
		let record = await DB.AssignRights.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert AssignRights record
 * @POST /assignrights/add
 */
router.post('/add/', 
	[
		body('description').not().isEmpty().trim(),
		body('permission').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		// Normalize permission (trim)
		modeldata.permission = modeldata.permission.trim();
		if (modeldata.description) {
			modeldata.description = modeldata.description.trim();
		}
		
		// Check for duplicate permission
		const existingRight = await DB.AssignRights.findOne({
			where: {
				permission: modeldata.permission
			}
		});
		
		if (existingRight) {
			return res.badRequest('This permission already exists');
		}
		
		// Save AssignRights record
		let record = await DB.AssignRights.create(modeldata);
		const recid = record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get AssignRights record for edit
 * @GET /assignrights/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.AssignRights.editFields();
		
		let record = await DB.AssignRights.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to update AssignRights record
 * @POST /assignrights/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('description').optional({nullable: true}).not().isEmpty().trim(),
		body('permission').optional({nullable: true}).not().isEmpty().trim(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.AssignRights.editFields();
		
		let record = await DB.AssignRights.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		// Check for duplicate if permission is being updated
		if (modeldata.permission) {
			const normalizedPermission = modeldata.permission.trim();
			const existingRight = await DB.AssignRights.findOne({
				where: {
					permission: normalizedPermission,
					id: { [DB.op.ne]: recid }
				}
			});
			
			if (existingRight) {
				return res.badRequest('This permission already exists');
			}
		}
		
		await DB.AssignRights.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to delete AssignRights record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /assignrights/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.AssignRights.findAll(query);
		records.forEach(async (record) => { 
			// Perform action on each record before delete
		});
		await DB.AssignRights.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to check if an assign right already exists
 * @GET /assignrights/check-duplicate
 */
router.get('/check-duplicate', async (req, res) => {
	try{
		const permission = req.query.permission;
		const excludeId = req.query.exclude_id;
		
		if (!permission) {
			return res.badRequest('Permission is required');
		}
		
		const where = {
			permission: permission.trim()
		};
		
		if (excludeId) {
			where.id = { [DB.op.ne]: excludeId };
		}
		
		const existing = await DB.AssignRights.findOne({ where });
		
		return res.ok({ exists: !!existing });
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to bulk add assign rights
 * @POST /assignrights/bulk-add
 */
router.post('/bulk-add', 
	[
		body('rights').isArray({ min: 1 }),
		body('rights.*.description').optional().trim(),
		body('rights.*.permission').not().isEmpty().trim(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		const rights = modeldata.rights;
		
		const results = [];
		const errors = [];
		
		for (const right of rights) {
			try {
				// Normalize permission
				right.permission = right.permission.trim();
				if (right.description) {
					right.description = right.description.trim();
				}
				
				// Check for duplicate
				const existingRight = await DB.AssignRights.findOne({
					where: { permission: right.permission }
				});
				
				if (existingRight) {
					results.push({ 
						permission: right.permission, 
						status: 'already_exists',
						existing_id: existingRight.id 
					});
				} else {
					const newRight = await DB.AssignRights.create(right);
					results.push({ 
						permission: right.permission, 
						status: 'created',
						id: newRight.id 
					});
				}
			} catch (err) {
				errors.push({ permission: right.permission, error: err.message });
			}
		}
		
		return res.ok({
			message: 'Bulk add completed',
			results,
			errors: errors.length > 0 ? errors : undefined
		});
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get all unique permissions
 * @GET /assignrights/all-permissions
 */
router.get('/all-permissions', async (req, res) => {
	try{
		const permissions = await DB.AssignRights.findAll({
			attributes: ['id', 'description', 'permission'],
			order: [['permission', 'ASC']],
			raw: true
		});
		
		return res.ok(permissions);
	}
	catch(err){
		return res.serverError(err);
	}
});



export default router;
