// controllers/migrationroutes.js

import express from 'express';

import completeMigrationService from '../services/completeMigrationService.js';

import cloudFrontService from '../services/cloudFrontService.js';

import databasePopulationService from '../services/databasePopulationService.js';

import videoSyncService from '../services/videoSyncService.js';

import DB from '../models/db.js'; // Add this import for the reset route



const router = express.Router();



// GET /migration - Get migration status and stats

router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {

    try {

        const stats = await completeMigrationService.getMigrationStats();

        const existingHierarchy = await databasePopulationService.checkExistingHierarchy();



        res.json({

            success: true,

            message: 'Migration service status',

            data: {

                s3: {

                    source: stats.sourceBucket,

                    destination: stats.destinationBucket,

                    filesToMigrate: stats.totalFiles,

                    estimatedSize: stats.estimatedTotalSize,

                    folders: stats.folders

                },

                database: {

                    levels: existingHierarchy.levels.length,

                    grades: existingHierarchy.grades.length,

                    areas: existingHierarchy.areas.length,

                    topics: existingHierarchy.topics.length,

                    subtopics: existingHierarchy.subtopics.length,

                    lessons: existingHierarchy.lessons

                },

                cloudFront: completeMigrationService.destCloudFrontDomain || 'Not configured'

            }

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Error getting migration status',

            error: error.message

        });

    }

});



// POST /migration/complete - Run complete migration

router.post('/complete', async (req, res) => {

    try {

        console.log('Starting complete migration via API...');



        const results = await completeMigrationService.completeMigration();



        res.json({

            success: true,

            message: 'Complete migration finished successfully',

            data: results

        });

    } catch (error) {

        console.error('Migration API error:', error);

        res.status(500).json({

            success: false,

            message: 'Complete migration failed',

            error: error.message

        });

    }

});



// POST /migration/files - Migrate only files

router.post('/files', async (req, res) => {

    try {

        console.log('Starting file migration via API...');



        const results = await completeMigrationService.migrateOnlyFiles();



        res.json({

            success: true,

            message: 'File migration completed',

            data: results

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'File migration failed',

            error: error.message

        });

    }

});



// POST /migration/database - Populate only database

router.post('/database', async (req, res) => {

    try {

        console.log('Starting database population via API...');



        const results = await completeMigrationService.populateOnlyDatabase();



        res.json({

            success: true,

            message: 'Database population completed',

            data: results

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Database population failed',

            error: error.message

        });

    }

});



// GET /migration/cloudfront - Setup CloudFront

router.get('/cloudfront', async (req, res) => {

    try {

        console.log('Setting up CloudFront via API...');



        const result = await cloudFrontService.setupAfricaCloudFront();



        res.json({

            success: true,

            message: 'CloudFront setup completed',

            data: result

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'CloudFront setup failed',

            error: error.message

        });

    }

});



// GET /migration/verify - Verify migration

router.get('/verify', async (req, res) => {

    try {

        const dbVerification = await databasePopulationService.verifyPopulation();

        const fileVerification = await completeMigrationService.quickVerification(10);



        res.json({

            success: true,

            message: 'Migration verification completed',

            data: {

                database: dbVerification,

                files: fileVerification

            }

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Verification failed',

            error: error.message

        });

    }

});



// GET /migration/status - Detailed migration status

router.get('/status', async (req, res) => {

    try {

        // Get S3 file list

        const s3Files = await completeMigrationService.listAllS3Objects();

        const filesByFolder = databasePopulationService.groupFilesByFolder(s3Files);



        // Get database counts

        const dbCounts = await databasePopulationService.verifyPopulation();



        res.json({

            success: true,

            message: 'Detailed migration status',

            data: {

                s3Files: {

                    total: s3Files.filter(f => !f.Key.endsWith('/')).length,

                    byFolder: Object.keys(filesByFolder).reduce((acc, folder) => {

                        acc[folder] = filesByFolder[folder].length;

                        return acc;

                    }, {})

                },

                database: dbCounts,

                cloudFront: completeMigrationService.destCloudFrontDomain,

                readyForMigration: s3Files.length > 0

            }

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Error getting migration status',

            error: error.message

        });

    }

});



// POST /migration/reset - Reset database (DANGEROUS - for development only)

router.post('/reset', async (req, res) => {

    try {

        const { confirm } = req.body;



        if (!confirm || confirm !== 'RESET_ALL_DATA') {

            return res.status(400).json({

                success: false,

                message: 'Confirmation required. Send { confirm: "RESET_ALL_DATA" } in body'

            });

        }



        console.log('WARNING: Resetting database - deleting all lessons...');



        // Delete all lessons (you might want to add other models too)

        const deletedLessons = await DB.Lessons.destroy({ where: {} });

        const deletedSubtopics = await DB.Subtopics.destroy({ where: {} });

        const deletedTopics = await DB.Topics.destroy({ where: {} });

        const deletedAreas = await DB.LearningAreas.destroy({ where: {} });

        const deletedGrades = await DB.Grades.destroy({ where: {} });

        const deletedLevels = await DB.LearningLevels.destroy({ where: {} });



        res.json({

            success: true,

            message: 'Database reset completed',

            data: {

                deleted: {

                    lessons: deletedLessons,

                    subtopics: deletedSubtopics,

                    topics: deletedTopics,

                    areas: deletedAreas,

                    grades: deletedGrades,

                    levels: deletedLevels

                }

            },

            warning: 'This operation deleted all data. Use with caution!'

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Database reset failed',

            error: error.message

        });

    }

});



// GET /migration/progress - Simulate progress (for UI)

router.get('/progress', async (req, res) => {

    try {

        // This would typically come from a job queue or WebSocket

        // For now, we'll return static progress

        res.json({

            success: true,

            message: 'Migration progress',

            data: {

                status: 'idle', // 'running', 'completed', 'error'

                currentStep: 'ready',

                progress: 0,

                steps: [

                    { name: 'Check S3 connection', status: 'completed' },

                    { name: 'Setup CloudFront', status: 'pending' },

                    { name: 'Migrate S3 files', status: 'pending' },

                    { name: 'Populate database', status: 'pending' },

                    { name: 'Verify migration', status: 'pending' }

                ],

                estimatedTime: '15-30 minutes'

            }

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Error getting progress',

            error: error.message

        });

    }

});



// VIDEO SYNC ROUTES - Match the frontend API calls



// GET /migration/sync/status - Get video sync status

router.get('/syncstatus', async (req, res) => {

    try {

        const syncStatus = await videoSyncService.getSyncStatus();



        res.json({

            success: true,

            message: 'Video sync status',

            data: syncStatus

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: 'Error getting sync status',

            error: error.message

        });

    }

});



// POST /migration/sync/videos - Scan and sync new videos

router.post('/syncvideos', async (req, res) => {

    try {

        const { folder } = req.body;



        console.log('Starting video sync via API...');



        let results;

        if (folder) {

            results = await videoSyncService.syncSpecificFolder(folder);

        } else {

            results = await videoSyncService.scanAndSyncNewVideos();

        }



        res.json({

            success: true,

            message: 'Video sync completed',

            data: results

        });

    } catch (error) {

        console.error('Video sync API error:', error);

        res.status(500).json({

            success: false,

            message: 'Video sync failed',

            error: error.message

        });

    }

});



// GET /migration/sync/folders - List available folders for syncing
router.get('/syncfolders', async (req, res) => {
    try {
        const allVideos = await videoSyncService.listAllAfricaVideos();
        const folders = [...new Set(allVideos.map(video => video.Key.split('/')[0]))];

        res.json({
            success: true,
            message: 'Available folders for syncing',
            data: {
                folders: folders,
                totalVideos: allVideos.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error listing folders',
            error: error.message
        });
    }
});

// POST /migration/sync/full - Full sync (add new + remove orphaned)
router.post('/fullsync', async (req, res) => {
    try {
        console.log('Starting full sync via API...');

        const results = await videoSyncService.fullSync();

        res.json({
            success: true,
            message: 'Full sync completed successfully',
            data: results
        });
    } catch (error) {
        console.error('Full sync API error:', error);
        res.status(500).json({
            success: false,
            message: 'Full sync failed',
            error: error.message
        });
    }
});

// POST /migration/sync/cleanup - Clean up orphaned lessons only
router.post('/cleanup', async (req, res) => {
    try {
        console.log('Starting cleanup of orphaned lessons via API...');

        const results = await videoSyncService.cleanupOrphanedLessons();

        res.json({
            success: true,
            message: results.message,
            data: results
        });
    } catch (error) {
        console.error('Cleanup API error:', error);
        res.status(500).json({
            success: false,
            message: 'Cleanup failed',
            error: error.message
        });
    }
});

export default router;