import { Router } from 'express';

import { body } from 'express-validator';

import validateFormData from '../helpers/validate_form.js';

import DB from '../models/db.js';





const router = Router();









/**

 * Route to list subscribertracker records

 * @GET /subscribertracker/index/{fieldname}/{fieldvalue}

 */

router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  

	try{

		const query = {};

		let queryFilters = [];

		let where = {};

		let replacements = {};

		let fieldName = req.params.fieldname;

		let fieldValue = req.params.fieldvalue;

		

		if (fieldName){

			queryFilters.push(DB.filterBy(fieldName, fieldValue));

		}

		let search = req.query.search;

		if(search){

			let searchFields = DB.SubscriberTracker.searchFields();

			where[DB.op.or] = searchFields;

			replacements.search = `%${search}%`;

		}

		

		if(queryFilters.length){

			where[DB.op.and] = queryFilters;

		}

		query.raw = true;

		query.where = where;

		query.replacements = replacements;

		query.order = DB.getOrderBy(req, 'id', 'desc');

		query.attributes = DB.SubscriberTracker.listFields();

		let page = parseInt(req.query.page) || 1;

		let limit = parseInt(req.query.limit) || 10;

		let result = await DB.SubscriberTracker.paginate(query, page, limit);

		return res.ok(result);

	}

	catch(err) {

		return res.serverError(err);

	}

});





/**

 * Route to view SubscriberTracker record

 * @GET /subscribertracker/view/{recid}

 */

router.get('/view/:recid', async (req, res) => {

	try{

		const recid = req.params.recid || null;

		const query = {}

		const where = {}

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.SubscriberTracker.viewFields();

		let record = await DB.SubscriberTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		return res.ok(record);

	}

	catch(err){

		return res.serverError(err);
lesson_id
	}

});





/**

 * Route to insert SubscriberTracker record

 * @POST /subscribertracker/add

 */

router.post('/add/', 

	[

		body('id').not().isEmpty().isNumeric(),

		body('phone').optional({nullable: true, checkFalsy: true}),

		body('fingerprint').optional({nullable: true, checkFalsy: true}),

		body('resumetime').not().isEmpty(),

		body('timeviewtime').optional({nullable: true, checkFalsy: true}),

		body('status').optional({nullable: true, checkFalsy: true}),

		body('lesson_id').not().isEmpty(),

		body('transaction_id').optional({nullable: true, checkFalsy: true}),

		body('user_id').not().isEmpty().isNumeric(),

	], validateFormData

, async function (req, res) {

	try{

		let modeldata = req.getValidFormData();

		

		//save SubscriberTracker record

		let record = await DB.SubscriberTracker.create(modeldata);

		//await record.reload(); //reload the record from database

		const recid =  record['id'];

		

		return res.ok(record);

	} catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to get  SubscriberTracker record for edit

 * @GET /subscribertracker/edit/{recid}

 */

router.get('/edit/:recid', async (req, res) => {

	try{

		const recid = req.params.recid;

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.SubscriberTracker.editFields();

		let record = await DB.SubscriberTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		return res.ok(record);

	}

	catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to update  SubscriberTracker record

 * @POST /subscribertracker/edit/{recid}

 */

router.post('/edit/:recid', 

	[

		body('id').optional({nullable: true}).not().isEmpty().isNumeric(),

		body('phone').optional({nullable: true, checkFalsy: true}),

		body('fingerprint').optional({nullable: true, checkFalsy: true}),

		body('resumetime').optional({nullable: true}).not().isEmpty(),

		body('timeviewtime').optional({nullable: true, checkFalsy: true}),

		body('status').optional({nullable: true, checkFalsy: true}),

		body('lesson_id').optional({nullable: true}).not().isEmpty(),

		body('transaction_id').optional({nullable: true, checkFalsy: true}),

		body('user_id').optional({nullable: true}).not().isEmpty().isNumeric(),

	], validateFormData

, async (req, res) => {

	try{

		const recid = req.params.recid;

		let modeldata = req.getValidFormData({ includeOptionals: true });

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		query.attributes = DB.SubscriberTracker.editFields();

		let record = await DB.SubscriberTracker.findOne(query);

		if(!record){

			return res.notFound();

		}

		await DB.SubscriberTracker.update(modeldata, {where: where});

		return res.ok(modeldata);

	}

	catch(err){

		return res.serverError(err);

	}

});





/**

 * Route to delete SubscriberTracker record by table primary key

 * Multi delete supported by recid separated by comma(,)

 * @GET /subscribertracker/delete/{recid}

 */

router.get('/delete/:recid', async (req, res) => {

	try{

		const recid = (req.params.recid || '').split(',');

		const query = {};

		const where = {};

		where['id'] = recid;

		query.raw = true;

		query.where = where;

		let records = await DB.SubscriberTracker.findAll(query);

		records.forEach(async (record) => { 

			//perform action on each record before delete

		});

		await DB.SubscriberTracker.destroy(query);

		return res.ok(recid);

	}

	catch(err){

		return res.serverError(err);

	}

});

export default router;

