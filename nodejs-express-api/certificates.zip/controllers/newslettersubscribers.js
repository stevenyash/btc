import { Router } from 'express';
import ejs from 'ejs';
import { body } from 'express-validator';
import config from '../config.js';
import mailer from '../helpers/mailer.js';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list newslettersubscribers records
 * @GET /newslettersubscribers/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.NewsletterSubscribers.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.NewsletterSubscribers.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.NewsletterSubscribers.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view NewsletterSubscribers record
 * @GET /newslettersubscribers/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.NewsletterSubscribers.viewFields();
		let record = await DB.NewsletterSubscribers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert NewsletterSubscribers record
 * @POST /newslettersubscribers/add
 */
router.post('/add/', 
	[
		body('email').not().isEmpty().isEmail(),
		body('name').optional({nullable: true, checkFalsy: true}),
		body('phone').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		// check if email already exist.
		let emailCount = await DB.NewsletterSubscribers.count({ where:{ 'email': modeldata.email } });
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		
		//save NewsletterSubscribers record
		let record = await DB.NewsletterSubscribers.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		await sendMailOnRecordAdd(record);
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  NewsletterSubscribers record for edit
 * @GET /newslettersubscribers/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.NewsletterSubscribers.editFields();
		let record = await DB.NewsletterSubscribers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  NewsletterSubscribers record
 * @POST /newslettersubscribers/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('email').optional({nullable: true}).not().isEmpty().isEmail(),
		body('name').optional({nullable: true, checkFalsy: true}),
		body('phone').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		
		// check if email already exist.
		let emailCount = await DB.NewsletterSubscribers.count({where:{'email': modeldata.email, 'id': {[DB.op.ne]: recid} }});
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.NewsletterSubscribers.editFields();
		let record = await DB.NewsletterSubscribers.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.NewsletterSubscribers.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete NewsletterSubscribers record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /newslettersubscribers/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.NewsletterSubscribers.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.NewsletterSubscribers.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
async function sendMailOnRecordAdd(record){
	
	const mailtitle = `Welcome to BitsTutorConnect – You're Subscribed! `;
	const message = `Dear ${record.name},
Thank you for subscribing to the BitsTutorConnect Newsletter! We're excited to have you on board.
As a subscriber, you'll receive:
✅ Exclusive updates on our latest courses and learning resources
✅ Special offers and discounts on our tutoring programs
✅ Insights, tips, and guides to enhance your learning experience
We’re committed to providing valuable content to support your education and career growth. If you ever have questions, feel free to contact us at info@bitstutorconnect.co.ke.
Stay tuned for our next update!
Best Regards,
The BitsTutorConnect Team
📍 P.O Box 955-90200, Kitui
📞 +254 (0) 722310358
📧 info@bitstutorconnect.co.ke
🌍 www.bitstutorconnect.co.ke`;
	const recid = record['id'];
	const baseUrl = config.app.frontendUrl;
	const recordLink = `${baseUrl}/#/newslettersubscribers/view/${recid}`;
	const viewData = { message, recordLink };
	const mailbody = await ejs.renderFile("views/notifications/record_action_mail.ejs", viewData);
	const recipient = `${record.email}`;
	const mailResult = await mailer.sendMail(recipient, mailtitle , mailbody);
	
	return mailResult;
	/*
	if(mailResult.messageId){
		console.log("Email Sent");
	}
	else{
		console.error(mailResult.error);
	}
	*/
}
export default router;
