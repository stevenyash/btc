import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list questions records
 * @GET /questions/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Questions.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'question_id', 'desc');
		query.attributes = DB.Questions.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Questions.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Questions record
 * @GET /questions/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['question_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Questions.viewFields();
		let record = await DB.Questions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Questions record
 * @POST /questions/add
 */
router.post('/add/', 
	[
		body('question_text').not().isEmpty(),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('scheduler_id').optional({nullable: true, checkFalsy: true}),
		body('created_at').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save Questions record
		let record = await DB.Questions.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['question_id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  Questions record for edit
 * @GET /questions/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['question_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Questions.editFields();
		let record = await DB.Questions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Questions record
 * @POST /questions/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('question_text').optional({nullable: true}).not().isEmpty(),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('scheduler_id').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['question_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Questions.editFields();
		let record = await DB.Questions.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Questions.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Questions record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /questions/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['question_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Questions.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Questions.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
