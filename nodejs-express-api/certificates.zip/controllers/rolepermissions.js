import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';



const router = Router();



/**
 * Route to list rolepermissions records
 * @GET /rolepermissions/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		
		const joinTables = [];
		joinTables.push({
			model: DB.Roles,
			required: false,
			as: 'roles',
			attributes: [],
		});
		
		query.include = joinTables;
		
		let search = req.query.search;
		if(search){
			let searchFields = DB.RolePermissions.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(req.query.role_id){
			queryFilters.push(DB.filterBy("roles.role_id", req.query.role_id));
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.RolePermissions.listFields();
		
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.RolePermissions.paginate(query, page, limit);
		
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});



/**
 * Route to view RolePermissions record
 * @GET /rolepermissions/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {};
		const where = {};
		
		const joinTables = [];
		joinTables.push({
			model: DB.Roles,
			required: false,
			as: 'roles',
			attributes: [],
		});
		
		query.include = joinTables;
		where[DB.op.and] = DB.raw('role_permissions.id = :recid');
		query.replacements = { recid };
		
		query.raw = true;
		query.where = where;
		query.attributes = DB.RolePermissions.viewFields();
		
		let record = await DB.RolePermissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to insert RolePermissions record
 * @POST /rolepermissions/add
 */
router.post('/add/', 
	[
		body('list').not().isEmpty().isNumeric(),
		body('edit').not().isEmpty(),
		body('remove').not().isEmpty().isNumeric(),
		body('view').not().isEmpty().isNumeric(),
		body('page').not().isEmpty(),
		body('role_id').not().isEmpty(),
		body('store').optional({nullable: true, checkFalsy: true}).isNumeric(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		// Check for duplicate role permission (same role_id and page combination)
		const existingPermission = await DB.RolePermissions.findOne({
			where: {
				role_id: modeldata.role_id,
				page: modeldata.page
			}
		});
		
		if (existingPermission) {
			return res.badRequest('Permission for this page already exists for the specified role');
		}
		
		// Save RolePermissions record
		let record = await DB.RolePermissions.create(modeldata);
		const recid = record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get RolePermissions record for edit
 * @GET /rolepermissions/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.RolePermissions.editFields();
		
		let record = await DB.RolePermissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to update RolePermissions record
 * @POST /rolepermissions/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('list').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('edit').optional({nullable: true}).not().isEmpty(),
		body('remove').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('view').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('page').optional({nullable: true}).not().isEmpty(),
		body('role_id').optional({nullable: true}).not().isEmpty(),
		body('store').optional({nullable: true, checkFalsy: true}).isNumeric(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.RolePermissions.editFields();
		
		let record = await DB.RolePermissions.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		// Check for duplicate if role_id or page is being updated
		if (modeldata.role_id || modeldata.page) {
			const duplicateWhere = {
				role_id: modeldata.role_id || record.role_id,
				page: modeldata.page || record.page,
				id: { [DB.op.ne]: recid } // Exclude current record
			};
			
			const existingPermission = await DB.RolePermissions.findOne({
				where: duplicateWhere
			});
			
			if (existingPermission) {
				return res.badRequest('Permission for this page already exists for the specified role');
			}
		}
		
		await DB.RolePermissions.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to delete RolePermissions record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /rolepermissions/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.RolePermissions.findAll(query);
		records.forEach(async (record) => { 
			// Perform action on each record before delete
		});
		await DB.RolePermissions.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to check if a role permission already exists
 * @GET /rolepermissions/check-duplicate
 */
router.get('/check-duplicate', async (req, res) => {
	try{
		const roleId = req.query.role_id;
		const page = req.query.page;
		const excludeId = req.query.exclude_id;
		
		if (!roleId || !page) {
			return res.badRequest('Role ID and page are required');
		}
		
		const where = {
			role_id: roleId,
			page: page
		};
		
		if (excludeId) {
			where.id = { [DB.op.ne]: excludeId };
		}
		
		const existing = await DB.RolePermissions.findOne({ where });
		
		return res.ok({ exists: !!existing });
	}
	catch(err){
		return res.serverError(err);
	}
});



/**
 * Route to get all permissions for a specific role
 * @GET /rolepermissions/by-role/:roleId
 */
router.get('/by-role/:roleId', async (req, res) => {
	try{
		const roleId = req.params.roleId;
		
		const permissions = await DB.RolePermissions.findAll({
			where: { role_id: roleId },
			order: [['page', 'ASC']],
			raw: true
		});
		
		return res.ok(permissions);
	}
	catch(err){
		return res.serverError(err);
	}
});



export default router;
