import { Router } from 'express';


import { body } from 'express-validator';



import utils from '../helpers/uploader.js';



import Rbac from '../helpers/rbac.js';



import validateFormData from '../helpers/validate_form.js';



import DB from '../models/db.js';



const router = Router();



/**



 * Route to view user account record



 * @GET /account



 */



router.get(['/','/index'], async (req, res) => {



	try{



		let recid = req.user.id;



		let query = {};



		let where = {};



		where['id'] = recid;



		query.raw = true;







		query.where = where;







		query.attributes = DB.Users.accountviewFields();







		let record = await DB.Users.findOne(query);







		if(!record){



			return res.notFound();



		}







		return res.ok(record);







	}







	catch(err){







		return res.serverError(err);







	}







});







/**



 * Route to get  Users record for edit



 * @GET /users/edit/{recid}



 */



router.get(['/edit'], async (req, res) => {



	try{



		const recid = req.user.id;







		const query = {};







		const where = {};







		where['id'] = recid;







		query.raw = true;







		query.where = where;







		query.attributes = DB.Users.accounteditFields();







		let record = await DB.Users.findOne(query);







		if(!record){







			return res.notFound();







		}







		return res.ok(record);







	}







	catch(err){







		return res.serverError(err);







	}







});







/**



 * Route to update  Users record



 * @POST /users/edit/{recid}



 */



router.post(['/edit'], 







	[







		body('image').optional({nullable: true, checkFalsy: true}),







		body('phone').optional({nullable: true, checkFalsy: true}),







		body('username').optional({nullable: true, checkFalsy: true}),







		body('status').optional({nullable: true}).not().isEmpty().isNumeric(),







		body('subscription_code').optional({nullable: true}).not().isEmpty(),







		body('user_role_id').optional({nullable: true, checkFalsy: true}),







		body('nhif').optional({nullable: true, checkFalsy: true}),







		body('nssf').optional({nullable: true, checkFalsy: true}),







		body('national_id').optional({nullable: true, checkFalsy: true}),







		body('password').optional({nullable: true, checkFalsy: true}),







		body('confirm_password', 'Passwords do not match').custom((value, {req}) => (value === req.body.password)),







		body('email').optional({nullable: true, checkFalsy: true}).isEmail(),







		body('referred_by').optional({nullable: true, checkFalsy: true}),







	], validateFormData







 , async (req, res) => {







	try{







		const recid = req.user.id;







		let modeldata = req.getValidFormData({ includeOptionals: true });







		// move uploaded file from temp directory to destination directory







		if(modeldata.image !== undefined) {







			const fileInfo = uploader.moveUploadedFiles(modeldata.image, 'image');







			modeldata.image = fileInfo.filepath;







		}







		const query = {};







		const where = {};







		where['id'] = recid;







		query.raw = true;







		query.where = where;







		query.attributes = DB.Users.accounteditFields();







		let record = await DB.Users.findOne(query);







		if(!record){







			return res.notFound();







		}







		await DB.Users.update(modeldata, {where: where});







		return res.ok(modeldata);







	}







	catch(err){







		return res.serverError(err);







	}







});







router.get('/currentuserdata', async function (req, res) {







	try {







		const user = req.user;







		const userRole = user.user_role_id;







		const userId = user.id;











		const rbac = new Rbac(userRole, userId);







		const pages = await rbac.getUserPages();







		const roles = await rbac.getRoleName();







		const rolePermissions = rbac.rolePermissions;







		return res.ok({ user, pages, roles, rolePermissions });







	} catch (error) {







		console.error('Error retrieving user data:', error);







		return res.status(500).send({ error: 'Internal Server Error' });







	}







});







/**



 * Route to change user password



 * @POST /account



 */



router.post('/changepassword' , 







	[







		body('oldpassword').not().isEmpty(),







		body('newpassword').not().isEmpty(),







		body('confirmpassword').not().isEmpty().custom((value, {req}) => (value === req.body.newpassword))







	], validateFormData, async function (req, res) {







	try{







		let oldPassword = req.body.oldpassword;







		let newPassword = req.body.newpassword;











		let userId = req.user.id;







		let query = {};







		let where = {







			id: userId,







		};







		query.raw = true;







		query.where = where;







		query.attributes = ['password'];







		let user = await DB.Users.findOne(query);







		let currentPasswordHash = user.password;







		if(!utils.passwordVerify(oldPassword, currentPasswordHash)){







			return res.badRequest("Current password is incorrect");







		}







		let modeldata = {







			password: utils.passwordHash(newPassword)







		}







		await DB.Users.update(modeldata, {where: where});







		return res.ok("Password change completed");







	}







	catch(err){







		return res.serverError(err);







	}







});







export default router;
