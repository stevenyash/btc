import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list tutorialregister records
 * @GET /tutorialregister/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.TutorialRegister.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.TutorialRegister.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.TutorialRegister.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view TutorialRegister record
 * @GET /tutorialregister/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.TutorialRegister.viewFields();
		let record = await DB.TutorialRegister.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert TutorialRegister record
 * @POST /tutorialregister/add
 */
router.post('/add/', 
	[
		body('user_id').not().isEmpty().isNumeric(),
		body('transaction_status').not().isEmpty(),
		body('payment_reference').not().isEmpty(),
		body('amount_paid').not().isEmpty().isNumeric(),
		body('expiry_date').not().isEmpty(),
		body('tutorial_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('phone').optional({nullable: true, checkFalsy: true}),
		body('email').optional({nullable: true, checkFalsy: true}).isEmail(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save TutorialRegister record
		let record = await DB.TutorialRegister.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  TutorialRegister record for edit
 * @GET /tutorialregister/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.TutorialRegister.editFields();
		let record = await DB.TutorialRegister.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  TutorialRegister record
 * @POST /tutorialregister/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('user_id').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('transaction_status').optional({nullable: true}).not().isEmpty(),
		body('payment_reference').optional({nullable: true}).not().isEmpty(),
		body('amount_paid').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('expiry_date').optional({nullable: true}).not().isEmpty(),
		body('tutorial_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('phone').optional({nullable: true, checkFalsy: true}),
		body('email').optional({nullable: true, checkFalsy: true}).isEmail(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.TutorialRegister.editFields();
		let record = await DB.TutorialRegister.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.TutorialRegister.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete TutorialRegister record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /tutorialregister/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.TutorialRegister.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.TutorialRegister.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
