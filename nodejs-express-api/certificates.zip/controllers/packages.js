import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list packages records
 * @GET /packages/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Packages.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(req.query.subscription_type_id){
			queryFilters.push(DB.filterBy("packages.subscription_type_id", req.query.subscription_type_id))
		}
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Packages.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Packages.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Packages record
 * @GET /packages/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Packages.viewFields();
		let record = await DB.Packages.findOne(query);
		if(!record){
			return res.notFound();
		}
			record.nextRecordId = await getNextRecordId(recid);
			record.previousRecordId = await getPreviousRecordId(recid);
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Packages record
 * @POST /packages/add
 */
router.post('/add/', 
	[
		body('subscription_type_id').not().isEmpty(),
		body('name').not().isEmpty(),
		body('description').not().isEmpty(),
		body('fee').not().isEmpty().isNumeric(),
		body('concurrent_access').not().isEmpty().isNumeric(),
		body('created_at').not().isEmpty(),
		body('no_of_lessons').not().isEmpty().isNumeric(),
		body('duration_amount').not().isEmpty().isNumeric(),
		body('duration_unit').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save Packages record
		let record = await DB.Packages.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  Packages record for edit
 * @GET /packages/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Packages.editFields();
		let record = await DB.Packages.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Packages record
 * @POST /packages/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('subscription_type_id').optional({nullable: true}).not().isEmpty(),
		body('name').optional({nullable: true}).not().isEmpty(),
		body('description').optional({nullable: true}).not().isEmpty(),
		body('fee').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('concurrent_access').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('no_of_lessons').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('duration_amount').optional({nullable: true}).not().isEmpty().isNumeric(),
		body('duration_unit').optional({nullable: true}).not().isEmpty(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Packages.editFields();
		let record = await DB.Packages.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Packages.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Packages record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /packages/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Packages.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Packages.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
async function getNextRecordId(recid){
	let query = {};
	let where = {};
	let keyField = 'id';
	where[keyField] = { [DB.op.gt]: recid };
	query.where = where;
	query.order = [[ keyField, 'ASC' ]];
	query.attributes = [keyField];
	let record = await DB.Packages.findOne(query);
	return (record ? record.id : null);
}
async function getPreviousRecordId(recid){
	let query = {};
	let where = {};
	let keyField = 'id';
	where[keyField] = { [DB.op.lt]: recid };
	query.where = where;
	query.order = [[ keyField, 'DESC' ]];
	query.attributes = [keyField];
	let record = await DB.Packages.findOne(query);
	return (record ? record.id : null);
}
export default router;
