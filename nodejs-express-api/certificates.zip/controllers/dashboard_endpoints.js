import { Router } from 'express';
import DB from '../models/db.js';

const router = Router();

// ==================== MARKETER DASHBOARD ENDPOINTS ====================

/**
 * Route to get count of invites for logged-in marketer
 * @GET /components_data/getcount_invites
 */
router.get('/getcount_invites', async (req, res) => {
    try {
        let sqltext = `SELECT COUNT(*) AS num FROM invites WHERE user_id = :userId`;
        let queryParams = { userId: req.user.id };
        let value = await DB.rawQueryValue(sqltext, queryParams);
        return res.ok(value.toString());
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get count of active referrals for logged-in marketer
 * @GET /components_data/getcount_activereferrals
 */
router.get('/getcount_activereferrals', async (req, res) => {
    try {
        let sqltext = `SELECT COUNT(*) AS num FROM invites WHERE user_id = :userId AND status = 'active'`;
        let queryParams = { userId: req.user.id };
        let value = await DB.rawQueryValue(sqltext, queryParams);
        return res.ok(value.toString());
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get marketer dashboard data
 * @GET /components_data/marketer_dashboard_data
 */
router.get('/marketer_dashboard_data', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COALESCE(
                    ROUND(
                        (COUNT(CASE WHEN status = 'active' THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0)), 
                        0
                    ), 
                    0
                ) AS conversion_rate,
                COUNT(CASE WHEN status = 'active' THEN 1 END) AS active_referrals,
                COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) AS weekly_growth
            FROM invites 
            WHERE user_id = :userId
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result[0] || { conversion_rate: 0, active_referrals: 0, weekly_growth: 0 });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get marketer performance data
 * @GET /components_data/marketer_performance_data
 */
router.get('/marketer_performance_data', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) AS weekly_invites,
                COUNT(CASE WHEN status = 'active' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) AS monthly_conversions,
                COALESCE((SELECT points FROM marketers WHERE phone = :phone), 0) AS monthly_points,
                COALESCE(
                    ROUND(
                        (COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) * 100.0 / NULLIF(50, 0)), 
                        0
                    ), 
                    0
                ) AS target_progress
            FROM invites 
            WHERE user_id = :userId
        `;
        let queryParams = { 
            userId: req.user.id,
            phone: req.user.username 
        };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result[0] || { weekly_invites: 0, monthly_conversions: 0, monthly_points: 0, target_progress: 0 });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get marketer recent activity
 * @GET /components_data/marketer_recent_activity
 */
router.get('/marketer_recent_activity', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                CASE 
                    WHEN status = 'active' THEN 'person_add'
                    WHEN status = 'pending' THEN 'email'
                    ELSE 'info'
                END AS icon,
                CASE 
                    WHEN status = 'active' THEN 'positive'
                    WHEN status = 'pending' THEN 'primary'
                    ELSE 'grey'
                END AS color,
                CONCAT(
                    CASE 
                        WHEN TIMESTAMPDIFF(HOUR, created_at, NOW()) < 1 THEN CONCAT(TIMESTAMPDIFF(MINUTE, created_at, NOW()), ' minutes ago')
                        WHEN TIMESTAMPDIFF(HOUR, created_at, NOW()) < 24 THEN CONCAT(TIMESTAMPDIFF(HOUR, created_at, NOW()), ' hours ago')
                        ELSE CONCAT(TIMESTAMPDIFF(DAY, created_at, NOW()), ' days ago')
                    END
                ) AS time,
                CASE 
                    WHEN status = 'active' THEN 'New Referral'
                    WHEN status = 'pending' THEN 'Invite Sent'
                    ELSE 'Activity'
                END AS title,
                CONCAT(invitee_phone, ' - ', COALESCE(invitee_email, 'No email')) AS description
            FROM invites 
            WHERE user_id = :userId
            ORDER BY created_at DESC
            LIMIT 10
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result || []);
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get marketer earnings summary for dashboard
 * @GET /components_data/marketer_earnings_summary
 */
router.get('/marketer_earnings_summary', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COALESCE(points, 0) AS total_points,
                COALESCE(redeemed_points, 0) AS redeemed_points,
                COALESCE(points, 0) - COALESCE(redeemed_points, 0) AS available_points,
                COALESCE(commission_rate, 0.10) AS commission_rate,
                COALESCE(total_earnings, 0) AS total_earnings,
                COALESCE(pending_earnings, 0) AS pending_earnings,
                COALESCE(withdrawn_earnings, 0) AS withdrawn_earnings
            FROM marketers 
            WHERE phone = :phone
        `;
        let queryParams = { phone: req.user.username };
        let result = await DB.rawQueryOne(sqltext, queryParams);

        // Get point value from settings
        let pointValueSql = `SELECT setting_value FROM system_settings WHERE setting_key = 'point_value'`;
        let pointValueResult = await DB.rawQueryOne(pointValueSql, {});
        let pointValue = pointValueResult ? parseFloat(pointValueResult.setting_value) : 10.00;

        if (result) {
            result.point_value = pointValue;
            result.potential_cash = (result.available_points || 0) * pointValue;
        }

        return res.ok(result || {
            total_points: 0, redeemed_points: 0, available_points: 0,
            commission_rate: 0.10, total_earnings: 0, pending_earnings: 0,
            withdrawn_earnings: 0, point_value: pointValue, potential_cash: 0
        });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get marketer recent commissions
 * @GET /components_data/marketer_recent_commissions
 */
router.get('/marketer_recent_commissions', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                mc.id,
                mc.purchase_type,
                mc.purchase_amount,
                mc.commission_amount,
                mc.commission_rate,
                mc.status,
                mc.created_at
            FROM marketer_commissions mc
            INNER JOIN marketers m ON mc.marketer_id = m.id
            WHERE m.phone = :phone
            ORDER BY mc.created_at DESC
            LIMIT 10
        `;
        let queryParams = { phone: req.user.username };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result || []);
    }
    catch (err) {
        return res.serverError(err);
    }
});

// ==================== TEACHER DASHBOARD ENDPOINTS ====================

/**
 * Route to get count of teacher classes
 * @GET /components_data/getcount_teacherclasses
 */
router.get('/getcount_teacherclasses', async (req, res) => {
    try {
        let sqltext = `SELECT COUNT(*) AS num FROM scheduler WHERE user_id = :userId`;
        let queryParams = { userId: req.user.id };
        let value = await DB.rawQueryValue(sqltext, queryParams);
        return res.ok(value.toString());
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get count of active students for teacher
 * @GET /components_data/getcount_activestudents
 */
router.get('/getcount_activestudents', async (req, res) => {
    try {
        let sqltext = `
            SELECT COUNT(DISTINCT tr.phone) AS num 
            FROM tutorial_register tr
            JOIN scheduler s ON tr.tutorial_id = s.id
            WHERE s.user_id = :userId
        `;
        let queryParams = { userId: req.user.id };
        let value = await DB.rawQueryValue(sqltext, queryParams);
        return res.ok(value.toString());
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get teacher dashboard data
 * @GET /components_data/teacher_dashboard_data
 */
router.get('/teacher_dashboard_data', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COUNT(*) AS total_classes,
                (SELECT COUNT(DISTINCT tr.phone) 
                 FROM tutorial_register tr
                 JOIN scheduler s2 ON tr.tutorial_id = s2.id
                 WHERE s2.user_id = :userId) AS active_students,
                COUNT(CASE WHEN start_date > NOW() THEN 1 END) AS upcoming_sessions,
                COALESCE(
                    ROUND(
                        (COUNT(CASE WHEN status = 'completed' THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0)), 
                        0
                    ), 
                    0
                ) AS completion_rate,
                COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) AS weekly_growth
            FROM scheduler 
            WHERE user_id = :userId
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result[0] || { total_classes: 0, active_students: 0, upcoming_sessions: 0, completion_rate: 0, weekly_growth: 0 });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get teacher today's schedule
 * @GET /components_data/teacher_today_schedule
 */
router.get('/teacher_today_schedule', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                id,
                CONCAT(learning_area, ' - ', strand) AS title,
                grade,
                learning_area AS subject,
                DATE_FORMAT(start_date, '%h:%i %p') AS time,
                CASE 
                    WHEN start_date > NOW() THEN 'Upcoming'
                    WHEN start_date <= NOW() AND end_date >= NOW() THEN 'In Progress'
                    ELSE 'Completed'
                END AS status,
                CASE 
                    WHEN start_date > NOW() THEN 'primary'
                    WHEN start_date <= NOW() AND end_date >= NOW() THEN 'orange'
                    ELSE 'positive'
                END AS statusColor,
                'school' AS icon,
                'primary' AS color,
                link
            FROM scheduler 
            WHERE user_id = :userId
            AND DATE(start_date) = CURDATE()
            ORDER BY start_date ASC
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result || []);
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get teacher class statistics
 * @GET /components_data/teacher_class_stats
 */
router.get('/teacher_class_stats', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COUNT(CASE WHEN start_date >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) AS weekly_classes,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) AS completed_classes,
                COUNT(CASE WHEN status IN ('scheduled', 'pending') THEN 1 END) AS pending_classes,
                COALESCE(
                    ROUND(AVG(TIMESTAMPDIFF(MINUTE, start_date, end_date)), 0), 
                    0
                ) AS avg_duration
            FROM scheduler 
            WHERE user_id = :userId
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result[0] || { weekly_classes: 0, completed_classes: 0, pending_classes: 0, avg_duration: 0 });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get teacher performance data
 * @GET /components_data/teacher_performance_data
 */
router.get('/teacher_performance_data', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                COALESCE(ROUND(RAND() * 100, 0), 85) AS student_engagement,
                COALESCE(
                    ROUND(
                        (COUNT(CASE WHEN status = 'completed' THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0)), 
                        0
                    ), 
                    92
                ) AS attendance_rate,
                COALESCE(
                    ROUND(
                        (COUNT(CASE WHEN status = 'completed' THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0)), 
                        0
                    ), 
                    78
                ) AS content_completion,
                COALESCE(ROUND(RAND() * 100, 0), 88) AS student_satisfaction
            FROM scheduler 
            WHERE user_id = :userId
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result[0] || { student_engagement: 85, attendance_rate: 92, content_completion: 78, student_satisfaction: 88 });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get teacher recent activity
 * @GET /components_data/teacher_recent_activity
 */
router.get('/teacher_recent_activity', async (req, res) => {
    try {
        let sqltext = `
            SELECT 
                CASE 
                    WHEN status = 'completed' THEN 'videocam'
                    WHEN status = 'scheduled' THEN 'event'
                    ELSE 'info'
                END AS icon,
                CASE 
                    WHEN status = 'completed' THEN 'positive'
                    WHEN status = 'scheduled' THEN 'primary'
                    ELSE 'secondary'
                END AS color,
                CONCAT(
                    CASE 
                        WHEN TIMESTAMPDIFF(HOUR, created_at, NOW()) < 1 THEN CONCAT(TIMESTAMPDIFF(MINUTE, created_at, NOW()), ' minutes ago')
                        WHEN TIMESTAMPDIFF(HOUR, created_at, NOW()) < 24 THEN CONCAT(TIMESTAMPDIFF(HOUR, created_at, NOW()), ' hours ago')
                        ELSE CONCAT(TIMESTAMPDIFF(DAY, created_at, NOW()), ' days ago')
                    END
                ) AS time,
                CASE 
                    WHEN status = 'completed' THEN 'Class Completed'
                    WHEN status = 'scheduled' THEN 'Schedule Created'
                    ELSE 'Activity'
                END AS title,
                CONCAT(grade, ' - ', learning_area) AS description
            FROM scheduler 
            WHERE user_id = :userId
            ORDER BY created_at DESC
            LIMIT 10
        `;
        let queryParams = { userId: req.user.id };
        let result = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(result || []);
    }
    catch (err) {
        return res.serverError(err);
    }
});

export default router;
