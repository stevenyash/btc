import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list topics records
 * @GET /topics/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Topics.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'topic_id', 'desc');
		query.attributes = DB.Topics.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Topics.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Topics record
 * @GET /topics/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['topic_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Topics.viewFields();
		let record = await DB.Topics.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Topics record
 * @POST /topics/add
 */
router.post('/add/', 
	[
		body('area_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('name').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save Topics record
		let record = await DB.Topics.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['topic_id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  Topics record for edit
 * @GET /topics/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['topic_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Topics.editFields();
		let record = await DB.Topics.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Topics record
 * @POST /topics/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('area_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('name').optional({nullable: true}).not().isEmpty(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['topic_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Topics.editFields();
		let record = await DB.Topics.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Topics.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Topics record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /topics/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['topic_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Topics.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Topics.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
