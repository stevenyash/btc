import { Router } from 'express';
import { body } from 'express-validator';
import uploader from '../helpers/uploader.js';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';
import s3CloudFrontService from '../services/s3CloudFrontService.js'; // Import our new service

const router = Router();

/**
 * Route to list Videos records
 * @GET /Videos/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Videos.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Videos.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Videos.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});

/**
 * Route to view Videos record
 * @GET /video/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Videos.viewFields();
		let record = await DB.Videos.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		// Generate CloudFront URL for the video
		if (record.s3_key) {
			record.dataValues.video_url = await s3CloudFrontService.generateCloudFrontUrl(record.s3_key);
			
			// Generate signed URL for private videos
			if (record.visibility === 'private') {
				record.dataValues.signed_url = await s3CloudFrontService.generateSignedUrl(record.s3_key, 3600); // 1 hour
			}
		}
		
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to insert Videos record
 * @POST /video/add
 */
router.post('/add/', 
	[
		body('title').optional({nullable: true, checkFalsy: true}),
		body('file').optional({nullable: true, checkFalsy: true}),
		body('collection').optional({nullable: true, checkFalsy: true}),
		body('visibility').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('category').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
        // move uploaded file from temp directory to destination directory
		if(modeldata.file !== undefined) {
			const fileInfo = uploader.moveUploadedFiles(modeldata.file, 'file');
			modeldata.file = fileInfo.filepath;
			modeldata.filename = fileInfo.filename;
		}
		
		await beforeAdd(modeldata, req);
		
		//save Videos record
		let record = await DB.Videos.create(modeldata);
		const recid =  record['id'];
		
		// Upload to S3 in the background
		afterAdd(record, req).catch(error => {
			console.error('Background S3 upload error:', error);
		});
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});

/**
* Before create new record
* @param {object} postdata // validated form data used to create new record
*/
async function beforeAdd(postdata, req){
    console.log('Before add - preparing video data:', postdata);
}

/**
 * Upload video to S3 with retries
 */
export async function uploadVideoToS3WithRetries(filePath, fileName, options = {}, maxRetries = 3, retryDelay = 2000) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`Attempt ${attempt} to upload video to S3: ${fileName}`);
            return await s3CloudFrontService.uploadVideo(filePath, fileName, options);
        } catch (error) {
            const isRetryable = error.code === 'ECONNABORTED' || error.code === 'ENOTFOUND' || error.name === 'TimeoutError';
            if (attempt === maxRetries || !isRetryable) {
                console.error(`S3 upload failed after ${attempt} attempts:`, error.message);
                throw error;
            }
            console.warn(`Retrying S3 upload in ${retryDelay / 1000} seconds... (${attempt}/${maxRetries})`);
            await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
    }
}

/**
 * After a new record is created, upload the video to S3 and delete it from the server.
 */
async function afterAdd(record, req) {
    try {
        const options = {
            visibility: record.visibility || 'private',
            category: record.category || '',
            description: record.description || '',
            collection: record.collection || 'videos',
            title: record.title || record.filename || 'Untitled Videos'
        };

        console.log("Uploading to S3:", record.file, record.filename);

        // Upload to S3 with retry logic
        const uploadResponse = await uploadVideoToS3WithRetries(record.file, record.filename, options);
        
        console.log('S3 Upload successful:', uploadResponse);

        if(uploadResponse.key){
            // Update record with S3 information
            let where = {'id': record.id};
            let modeldata = {
                status: 'active',
                s3_key: uploadResponse.key,
                s3_url: uploadResponse.url,
                file_size: uploadResponse.size,
                uploaded_at: new Date()
            };
            
            await DB.Videos.update(modeldata, { where });
            
            // Delete local file after successful S3 upload
            await uploader.deleteRecordFiles(record.file, 'file');
            
            console.log(`Videos ${record.id} successfully uploaded to S3 and local file cleaned up`);
        }

    } catch (error) {
        console.error('Error in afterAdd S3 upload:', error.message);
        
        // Update record with error status
        try {
            let where = {'id': record.id};
            let modeldata = {
                status: 'upload_failed',
                upload_error: error.message
            };
            await DB.Videos.update(modeldata, { where });
        } catch (updateError) {
            console.error('Failed to update record status:', updateError);
        }
    }
}

/**
 * Route to get Videos record for edit
 * @GET /video/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Videos.editFields();
		let record = await DB.Videos.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to update Videos record
 * @POST /video/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('title').optional({nullable: true, checkFalsy: true}),
		body('file').optional({nullable: true, checkFalsy: true}),
		body('collection').optional({nullable: true, checkFalsy: true}),
		body('visibility').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('category').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		
        // If new file is uploaded, handle S3 upload
		if(modeldata.file !== undefined) {
			const fileInfo = uploader.moveUploadedFiles(modeldata.file, 'file');
			modeldata.file = fileInfo.filepath;
			modeldata.filename = fileInfo.filename;
			
			// Upload new file to S3
			const options = {
				visibility: modeldata.visibility || 'private',
				category: modeldata.category || '',
				description: modeldata.description || '',
				collection: modeldata.collection || 'videos',
				title: modeldata.title || modeldata.filename || 'Untitled Videos'
			};
			
			const uploadResponse = await s3CloudFrontService.uploadVideo(
				modeldata.file, 
				modeldata.filename, 
				options
			);
			
			modeldata.s3_key = uploadResponse.key;
			modeldata.s3_url = uploadResponse.url;
			modeldata.file_size = uploadResponse.size;
			
			// Delete old S3 file if exists
			const oldRecord = await DB.Videos.findOne({ where: { id: recid } });
			if (oldRecord && oldRecord.s3_key) {
				try {
					await s3CloudFrontService.deleteVideo(oldRecord.s3_key);
				} catch (deleteError) {
					console.warn('Could not delete old S3 file:', deleteError.message);
				}
			}
			
			// Delete local file after S3 upload
			await uploader.deleteRecordFiles(modeldata.file, 'file');
		}
		
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Videos.editFields();
		let record = await DB.Videos.findOne(query);
		if(!record){
			return res.notFound();
		}
		
		await DB.Videos.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to delete Videos record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /video/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Videos.findAll(query);
		
		// Delete from S3 and local files
		for (let record of records) {
			// Delete from S3 if exists
			if (record.s3_key) {
				try {
					await s3CloudFrontService.deleteVideo(record.s3_key);
					console.log(`Deleted from S3: ${record.s3_key}`);
				} catch (s3Error) {
					console.error(`Error deleting from S3: ${s3Error.message}`);
				}
			}
			
			// Delete local file
			uploader.deleteRecordFiles(record.file, 'file');
		}
		
		await DB.Videos.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * New route: Get video streaming URL
 * @GET /video/stream-url/:recid
 */
router.get('/stream-url/:recid', async (req, res) => {
	try {
		const recid = req.params.recid;
		const { signed = 'false', expiresIn = 3600 } = req.query;
		
		const record = await DB.Videos.findOne({ where: { id: recid } });
		if (!record) {
			return res.notFound('Videos not found');
		}
		
		if (!record.s3_key) {
			return res.badRequest('Videos not uploaded to S3');
		}
		
		let videoUrl;
		if (signed === 'true' || record.visibility === 'private') {
			// Generate signed URL for private videos or when explicitly requested
			videoUrl = await s3CloudFrontService.generateSignedUrl(
				record.s3_key, 
				parseInt(expiresIn)
			);
		} else {
			// Use public CloudFront URL
			videoUrl = await s3CloudFrontService.generateCloudFrontUrl(record.s3_key);
		}
		
		res.json({
			success: true,
			video_url: videoUrl,
			title: record.title,
			expires_in: parseInt(expiresIn),
			is_signed: signed === 'true' || record.visibility === 'private'
		});
		
	} catch (error) {
		console.error('Error generating stream URL:', error);
		return res.serverError(error);
	}
});

/**
 * New route: Get video details with streaming info
 * @GET /video/stream/:recid
 */
router.get('/stream/:recid', async (req, res) => {
	try {
		const recid = req.params.recid;
		const record = await DB.Videos.findOne({ where: { id: recid } });
		
		if (!record) {
			return res.notFound('Videos not found');
		}
		
		let videoUrl;
		if (record.visibility === 'private') {
			videoUrl = await s3CloudFrontService.generateSignedUrl(record.s3_key, 3600);
		} else {
			videoUrl = await s3CloudFrontService.generateCloudFrontUrl(record.s3_key);
		}
		
		// Return HTML with video player
		const html = `
			<!DOCTYPE html>
			<html>
			<head>
				<title>${record.title}</title>
				<style>
					body { margin: 0; padding: 20px; background: #f5f5f5; }
					.video-container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
					video { width: 100%; border-radius: 4px; }
					.video-info { margin-top: 15px; }
					.video-title { font-size: 24px; margin-bottom: 10px; }
					.video-description { color: #666; }
				</style>
			</head>
			<body>
				<div class="video-container">
					<video controls controlsList="nodownload" oncontextmenu="return false;">
						<source src="${videoUrl}" type="video/mp4">
						Your browser does not support the video tag.
					</video>
					<div class="video-info">
						<h1 class="video-title">${record.title}</h1>
						<div class="video-description">${record.description || 'No description available'}</div>
					</div>
				</div>
				<script>
					// Prevent right-click download
					document.addEventListener('contextmenu', function(e) {
						e.preventDefault();
					});
				</script>
			</body>
			</html>
		`;
		
		res.send(html);
		
	} catch (error) {
		console.error('Error streaming video:', error);
		return res.serverError(error);
	}
});

export default router;