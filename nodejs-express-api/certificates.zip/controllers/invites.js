import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list invites records
 * @GET /invites/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Invites.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		let allowedRoles = ["admin", "superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Invites.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Invites.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Invites record
 * @GET /invites/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		let allowedRoles = ["admin", "superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Invites.viewFields();
		let record = await DB.Invites.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Invites record
 * @POST /invites/add
 */
router.post('/add/', 
	[
		body('invitee_email').optional({nullable: true, checkFalsy: true}).isEmail(),
		body('invitee_phone').optional({nullable: true, checkFalsy: true}),
		body('referral_code').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		modeldata['user_id'] = req.user.id;
		
		// check if invitee_email already exist.
		let invitee_emailCount = await DB.Invites.count({ where:{ 'invitee_email': modeldata.invitee_email } });
		if(invitee_emailCount > 0){
			return res.badRequest(`${modeldata.invitee_email} already exist.`);
		}
		
		// check if invitee_phone already exist.
		let invitee_phoneCount = await DB.Invites.count({ where:{ 'invitee_phone': modeldata.invitee_phone } });
		if(invitee_phoneCount > 0){
			return res.badRequest(`${modeldata.invitee_phone} already exist.`);
		}
		await beforeAdd(modeldata, req);
		
		//save Invites record
		let record = await DB.Invites.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});
/**
* Before create new record
* @param {object} postdata // validated form data used to create new record
*/
async function beforeAdd(postdata, req){
    //enter statement here
    console.log(postdata)
    console.log(req.user)
    let where = {phone:req.user.phone|| req.user.username   };
       let record = await DB.Marketers.findOne({ where });
       postdata.referral_code=record.id
}


/**
 * Route to get  Invites record for edit
 * @GET /invites/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		let allowedRoles = ["admin", "superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Invites.editFields();
		let record = await DB.Invites.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Invites record
 * @POST /invites/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('invitee_email').optional({nullable: true, checkFalsy: true}).isEmail(),
		body('invitee_phone').optional({nullable: true, checkFalsy: true}),
		body('referral_code').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		
		// check if invitee_email already exist.
		let invitee_emailCount = await DB.Invites.count({where:{'invitee_email': modeldata.invitee_email, 'id': {[DB.op.ne]: recid} }});
		if(invitee_emailCount > 0){
			return res.badRequest(`${modeldata.invitee_email} already exist.`);
		}
		
		// check if invitee_phone already exist.
		let invitee_phoneCount = await DB.Invites.count({where:{'invitee_phone': modeldata.invitee_phone, 'id': {[DB.op.ne]: recid} }});
		if(invitee_phoneCount > 0){
			return res.badRequest(`${modeldata.invitee_phone} already exist.`);
		}
		const query = {};
		const where = {};
		let allowedRoles = ["admin", "superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Invites.editFields();
		let record = await DB.Invites.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Invites.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Invites record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /invites/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		let allowedRoles = ["admin", "superadmin"];
		let userRole = req.userRoleName;
		if(!allowedRoles.includes(userRole)){
			where['user_id'] = req.user.id; //filter only current records
		}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Invites.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Invites.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
