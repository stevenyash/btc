import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();





/**
 * Route to list callbacks records
 * @GET /callbacks/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Callbacks.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'callback_id', 'desc');
		query.attributes = DB.Callbacks.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Callbacks.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Callbacks record
 * @GET /callbacks/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['callback_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Callbacks.viewFields();
		let record = await DB.Callbacks.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Callbacks record
 * @POST /callbacks/add
 */
router.post('/add/', 
	[
		body('transaction_id').not().isEmpty(),
		body('merchant_request_id').optional({nullable: true, checkFalsy: true}),
		body('checkout_request_id').optional({nullable: true, checkFalsy: true}),
		body('result_code').optional({nullable: true, checkFalsy: true}),
		body('result_description').optional({nullable: true, checkFalsy: true}),
		body('mpesa_receipt_number').optional({nullable: true, checkFalsy: true}),
		body('amount').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('transaction_date').optional({nullable: true, checkFalsy: true}),
		body('phone_number').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save Callbacks record
		let record = await DB.Callbacks.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['callback_id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  Callbacks record for edit
 * @GET /callbacks/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['callback_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Callbacks.editFields();
		let record = await DB.Callbacks.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Callbacks record
 * @POST /callbacks/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('transaction_id').optional({nullable: true}).not().isEmpty(),
		body('merchant_request_id').optional({nullable: true, checkFalsy: true}),
		body('checkout_request_id').optional({nullable: true, checkFalsy: true}),
		body('result_code').optional({nullable: true, checkFalsy: true}),
		body('result_description').optional({nullable: true, checkFalsy: true}),
		body('mpesa_receipt_number').optional({nullable: true, checkFalsy: true}),
		body('amount').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('transaction_date').optional({nullable: true, checkFalsy: true}),
		body('phone_number').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['callback_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Callbacks.editFields();
		let record = await DB.Callbacks.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Callbacks.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Callbacks record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /callbacks/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['callback_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Callbacks.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Callbacks.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
