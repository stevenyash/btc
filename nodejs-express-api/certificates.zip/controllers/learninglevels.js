// controllers/learninglevels.js
import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';

const router = Router();

/**
 * Route to list learninglevels records
 * @GET /learninglevels/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.LearningLevels.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'sort_order', 'asc');
		query.attributes = DB.LearningLevels.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.LearningLevels.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});

/**
 * Route to view LearningLevels record
 * @GET /learninglevels/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['level_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningLevels.viewFields();
		let record = await DB.LearningLevels.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to insert LearningLevels record
 * @POST /learninglevels/add
 */
router.post('/add/', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('sort_order').optional({nullable: true, checkFalsy: true}).isNumeric(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save LearningLevels record
		let record = await DB.LearningLevels.create(modeldata);
		const recid =  record['level_id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get LearningLevels record for edit
 * @GET /learninglevels/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['level_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningLevels.editFields();
		let record = await DB.LearningLevels.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to update LearningLevels record
 * @POST /learninglevels/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('sort_order').optional({nullable: true, checkFalsy: true}).isNumeric(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['level_id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningLevels.editFields();
		let record = await DB.LearningLevels.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.LearningLevels.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to delete LearningLevels record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /learninglevels/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['level_id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.LearningLevels.findAll(query);
		
		// Check if levels have associated grades before deletion
		for (let record of records) {
			const gradeCount = await DB.Grades.count({
				where: { level_id: record.level_id }
			});
			
			if (gradeCount > 0) {
				return res.badRequest(`Cannot delete level "${record.name}" because it has ${gradeCount} associated grade(s).`);
			}
		}
		
		await DB.LearningLevels.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get grades by learning level
 * @GET /learninglevels/:levelId/grades
 */
router.get('/:levelId/grades', async (req, res) => {
	try {
		const levelId = req.params.levelId;
		const { page = 1, limit = 10 } = req.query;
		
		const query = {};
		const where = {};
		where['level_id'] = levelId;
		where['is_active'] = true;
		
		query.raw = true;
		query.where = where;
		query.order = DB.getOrderBy(req, 'sort_order', 'asc');
		query.attributes = DB.Grades.listFields();
		
		let result = await DB.Grades.paginate(query, parseInt(page), parseInt(limit));
		return res.ok(result);
		
	} catch (error) {
		console.error('Error getting grades by level:', error);
		return res.serverError(error);
	}
});

export default router;