import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list guestusers records
 * @GET /guestusers/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.GuestUsers.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.GuestUsers.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.GuestUsers.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view GuestUsers record
 * @GET /guestusers/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.GuestUsers.viewFields();
		let record = await DB.GuestUsers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert GuestUsers record
 * @POST /guestusers/add
 */
router.post('/add/', 
	[
		body('guest_id').not().isEmpty(),
		body('ip_address').optional({nullable: true, checkFalsy: true}),
		body('user_agent').optional({nullable: true, checkFalsy: true}),
		body('fingerprint').optional({nullable: true, checkFalsy: true}),
		body('is_active').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('platiform').not().isEmpty(),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save GuestUsers record
		let record = await DB.GuestUsers.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to get  GuestUsers record for edit
 * @GET /guestusers/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.GuestUsers.editFields();
		let record = await DB.GuestUsers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  GuestUsers record
 * @POST /guestusers/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('guest_id').optional({nullable: true}).not().isEmpty(),
		body('ip_address').optional({nullable: true, checkFalsy: true}),
		body('user_agent').optional({nullable: true, checkFalsy: true}),
		body('fingerprint').optional({nullable: true, checkFalsy: true}),
		body('is_active').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('platiform').optional({nullable: true}).not().isEmpty(),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.GuestUsers.editFields();
		let record = await DB.GuestUsers.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.GuestUsers.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete GuestUsers record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /guestusers/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.GuestUsers.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.GuestUsers.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
