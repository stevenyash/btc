import { Router } from 'express';
import config from '../config.js';
import uploader from '../helpers/uploader.js';
import { fileUploadMiddleware } from '../helpers/upload_middleware.js';
import s3CloudFrontService from '../services/s3CloudFrontService.js'; ;

const router = Router();

/**
 * Upload to server (existing functionality)
 */
router.post('/upload/:fieldname', fileUploadMiddleware(), async (req, res, next) => {
  if (req?.files.length) {
    const uploadedFiles = req.files;
    const publicDir = config.app.publicDir;
    let uploadedPaths = uploadedFiles.map(file => {
      let filePath = file.path.replaceAll("\\", "/");
      filePath = filePath.replaceAll(`${publicDir}/`, "");
      return filePath;
    });
    const allPaths = uploadedPaths.toString();
    return res.ok(allPaths);
  } else {
    return res.badRequest('No file uploaded.');
  }
});

/**
 * Upload directly to Muse using MuseService
 */
router.post('/upload/video/:fieldname', fileUploadMiddleware(), async (req, res) => {
  try {
    if (!req?.files.length) {
      return res.badRequest('No file uploaded.');
    }

    const file = req.files[0]; // Assuming a single file upload
    const fieldName = req.params.fieldname || 'file';

    // Use MuseService to upload the video
    const response = await museService.uploadVideo(file.path, file.originalname);

    // Send the MuseService response back to the client
    return res.status(200).json({
      success: true,
      message: 'File uploaded to Muse successfully.',
      data: response,
    });
  } catch (err) {
    console.error('Error uploading to Muse:', err);

    return res.status(500).json({
      success: false,
      message: 'Failed to upload to Muse.',
      error: err.message || 'Unknown error occurred.',
    });
  }
});

/**
 * Remove temporary uploaded file when deleted by client (existing functionality)
 */
router.post('/remove_temp_file', function (req, res, next) {
  let file = req.body.temp_file;
  if (file) {
    uploader.removeTempFile(file);
    return res.ok('File deleted');
  }
  return res.badRequest('Invalid temp file');
});

export default router;
