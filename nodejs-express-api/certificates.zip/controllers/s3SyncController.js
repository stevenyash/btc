// controllers/s3SyncController.js
import { Router } from 'express';
import s3SyncService from '../services/s3SyncService.js';

const router = Router();

/**
 * Sync complete learning hierarchy with S3
 * @POST /s3sync/hierarchy
 */
router.post('/hierarchy', async (req, res) => {
  try {
    const result = await s3SyncService.syncLearningHierarchy();
    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Sync error:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

/**
 * Get hierarchy from S3 cache
 * @GET /s3sync/hierarchy
 */
router.get('/hierarchy', async (req, res) => {
  try {
    const hierarchy = await s3SyncService.getHierarchyFromS3();
    res.json({ success: true, data: hierarchy });
  } catch (error) {
    console.error('Error getting hierarchy from S3:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

/**
 * Clean up orphaned S3 folders
 * @POST /s3sync/cleanup
 */
router.post('/cleanup', async (req, res) => {
  try {
    const result = await s3SyncService.cleanupOrphanedS3Folders();
    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Cleanup error:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

/**
 * Setup real-time sync
 * @POST /s3sync/setup-realtime
 */
router.post('/setup-realtime', async (req, res) => {
  try {
    const result = await s3SyncService.setupRealtimeSync();
    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Realtime setup error:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

/**
 * Sync specific level and its children
 * @POST /s3sync/levels/:levelId
 */
router.post('/levels/:levelId', async (req, res) => {
  try {
    const levelId = req.params.levelId;
    const level = await learningHierarchyService.getLevelWithChildren(levelId);
    
    if (!level) {
      return res.status(404).json({ 
        success: false, 
        message: 'Level not found' 
      });
    }
    
    const result = await s3SyncService.syncLearningLevel(level);
    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Level sync error:', error);
    res.status(500).json({ 
      success: false, 
      message: error.message 
    });
  }
});

export default router;