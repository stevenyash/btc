// controllers/LearningAreas.js
import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';

const router = Router();

/**
 * Route to list LearningAreas records
 * @GET /Learningareas/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.LearningAreas.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'name', 'asc');
		query.attributes = DB.LearningAreas.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.LearningAreas.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});

/**
 * Route to view LearningAreas record
 * @GET /LearningAreas/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningAreas.viewFields();
		let record = await DB.LearningAreas.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to insert LearningAreas record
 * @POST /LearningAreas/add
 */
router.post('/add/', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('grade_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('color').optional({nullable: true, checkFalsy: true}),
		body('icon').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		//save LearningAreas record
		let record = await DB.LearningAreas.create(modeldata);
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get LearningAreas record for edit
 * @GET /LearningAreas/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningAreas.editFields();
		let record = await DB.LearningAreas.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to update LearningAreas record
 * @POST /LearningAreas/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('description').optional({nullable: true, checkFalsy: true}),
		body('grade_id').optional({nullable: true, checkFalsy: true}).isNumeric(),
		body('color').optional({nullable: true, checkFalsy: true}),
		body('icon').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.LearningAreas.editFields();
		let record = await DB.LearningAreas.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.LearningAreas.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to delete LearningAreas record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /LearningAreas/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.LearningAreas.findAll(query);
		
		// Check if learning areas have associated lessons before deletion
		for (let record of records) {
			const lessonCount = await DB.Lessons.count({
				where: { area_id: record.id }
			});
			
			if (lessonCount > 0) {
				return res.badRequest(`Cannot delete learning area "${record.name}" because it has ${lessonCount} associated lesson(s).`);
			}
		}
		
		await DB.LearningAreas.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});

/**
 * Route to get lessons by learning area
 * @GET /LearningAreas/:areaId/lessons
 */
router.get('/:areaId/lessons', async (req, res) => {
	try {
		const areaId = req.params.areaId;
		const { page = 1, limit = 10 } = req.query;
		
		const query = {};
		const where = {};
		where['area_id'] = areaId;
		where['is_active'] = true;
		
		query.raw = true;
		query.where = where;
		query.order = DB.getOrderBy(req, 'sort_order', 'asc');
		query.attributes = DB.Lessons.listFields();
		
		let result = await DB.Lessons.paginate(query, parseInt(page), parseInt(limit));
		return res.ok(result);
		
	} catch (error) {
		console.error('Error getting lessons by area:', error);
		return res.serverError(error);
	}
});

export default router;