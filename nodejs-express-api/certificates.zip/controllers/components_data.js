import { Router } from 'express';
import ejs from 'ejs';
import utils from '../helpers/utils.js';
import mailer from '../helpers/mailer.js';
import DB from '../models/db.js';
import { v4 as uuidv4 } from 'uuid';
import MpesaService from '../helpers/MpesaService.js';
import moment from 'moment'
import { sendSms ,getBalance } from "../helpers/sms.js";
import s3CloudFrontService from '../services/s3CloudFrontService.js'; ;
import dashboardEndpoints from './dashboard_endpoints.js';
import { awardCommission } from '../helpers/marketerCommission.js';
const mpesaService = new MpesaService();

const router = Router();

// Mount dashboard endpoints
router.use('/', dashboardEndpoints);


 /**
 * Route to check if field value already exist in a Invites table
 * @GET /components_data/invites_invitee_email_exist/{fieldvalue}
 */
router.get('/invites_invitee_email_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
        let count = await DB.Invites.count({ where: { 'invitee_email': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Invites table
 * @GET /components_data/invites_invitee_phone_exist/{fieldvalue}
 */
router.get('/invites_invitee_phone_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Invites.count({ where:{ 'invitee_phone': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Marketers table
 * @GET /components_data/marketers_email_exist/{fieldvalue}
 */
router.get('/marketers_email_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Marketers.count({ where:{ 'email': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Marketers table
 * @GET /components_data/marketers_phone_exist/{fieldvalue}
 */
router.get('/marketers_phone_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Marketers.count({ where:{ 'phone': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a NewsletterSubscribers table
 * @GET /components_data/newslettersubscribers_email_exist/{fieldvalue}
 */
router.get('/newslettersubscribers_email_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.NewsletterSubscribers.count({ where:{ 'email': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscription_type_id_option_list records
 * @GET /components_data/subscription_type_id_option_list
 */
router.get('/subscription_type_id_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT id as value, name as label FROM subscription_types` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get role_id_option_list records
 * @GET /components_data/role_id_option_list
 */
router.get('/role_id_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT role_id as value, role_name as label FROM roles` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});

router.get('/subtopics_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT subtopic_id as value, name as label FROM subtopics where topic_id=:topic_id` ;
		let queryParams={
      topic_id: req.query.topic_id
    }
		let records = await DB.rawQueryList(sqltext, queryParams);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});
router.get('/grades_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT id as value, name as label FROM grades` ;
		let queryParams={
      topic_id: req.query.topic_id
    }
		let records = await DB.rawQueryList(sqltext, queryParams);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});
router.get('/levels_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT level_id as value, name as label FROM learning_levels` ;
		let queryParams={
      topic_id: req.query.topic_id
    }
		let records = await DB.rawQueryList(sqltext, queryParams);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});

router.get('/topics_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT topic_id as value, name as label FROM topics where area_id=:area_id` ;
		let queryParams={
      area_id: req.query.area_id
    }
		let records = await DB.rawQueryList(sqltext, queryParams);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get user_id_option_list records
 * @GET /components_data/user_id_option_list
 */
router.get('/user_id_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT id as value, username as label FROM users` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});

router.get('/areas_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT id as value, name as label FROM learning_areas` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});

 /**
 * Route to get package_id_option_list records
 * @GET /components_data/package_id_option_list
 */
router.get('/package_id_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT id as value, name as label FROM packages` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get user_id_option_list_2 records
 * @GET /components_data/user_id_option_list_2
 */
router.get('/user_id_option_list_2', async (req, res) => {
	try{
		let sqltext = `SELECT  users.id AS value, users.username AS label, users.email AS caption FROM roles JOIN users ON roles.role_id=users.user_role_id WHERE  (roles.role_name  ='Teacher' )` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get grade_option_list records
 * @GET /components_data/grade_option_list
 */
router.get('/grade_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT  DISTINCT name AS value,name AS label,description AS caption FROM grades` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get level_option_list records
 * @GET /components_data/level_option_list
 */
router.get('/level_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT  DISTINCT name AS value,name AS label FROM learning_levels` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Users table
 * @GET /components_data/users_email_exist/{fieldvalue}
 */
router.get('/users_email_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Users.count({ where:{ 'email': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Users table
 * @GET /components_data/users_username_exist/{fieldvalue}
 */
router.get('/users_username_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Users.count({ where:{ 'username': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to check if field value already exist in a Users table
 * @GET /components_data/users_phone_exist/{fieldvalue}
 */
router.get('/users_phone_exist/:fieldvalue', async (req, res) => {
	try{
		let val = req.params.fieldvalue
		let count = await DB.Users.count({ where:{ 'phone': val } });
		if(count > 0){
			return res.ok("true");
		}
		return res.ok("false");
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscription_type_id_option_list_2 records
 * @GET /components_data/subscription_type_id_option_list_2
 */
router.get('/subscription_type_id_option_list_2', async (req, res) => {
	try{
		let sqltext = `SELECT  DISTINCT id AS value,name AS label FROM subscription_types` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get permission_option_list records
 * @GET /components_data/permission_option_list
 */
router.get('/permission_option_list', async (req, res) => {
	try{
		let sqltext = `SELECT  DISTINCT permission AS value,permission AS label,description AS caption FROM assign_rights` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get user_id_option_list_3 records
 * @GET /components_data/user_id_option_list_3
 */
router.get('/user_id_option_list_3', async (req, res) => {
	try{
		let sqltext = `SELECT  DISTINCT id AS value,email AS label,username AS caption FROM users` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get services_data_repeater records
 * @GET /components_data/services_data_repeater
 */
router.get('/services_data_repeater', async (req, res) => {
	try{
		let sqltext = `SELECT  services_settings.id, services_settings.level, services_settings.title, services_settings.description FROM services_settings` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get products_data_repeater records
 * @GET /components_data/products_data_repeater
 */
router.get('/products_data_repeater', async (req, res) => {
	try{
		let sqltext = `SELECT  packages.id, packages.name, packages.description, packages.created_at, packages.subscription_type_id, packages.lessons_per_month, packages.cost_per_month, packages.concurrent_access FROM packages` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscribe_data_repeater records
 * @GET /components_data/subscribe_data_repeater
 */
router.get('/subscribe_data_repeater', async (req, res) => {
	try{
		let sqltext = `SELECT 
   *, 
    CASE 
        WHEN packages.duration_amount = 1 THEN concat(packages.duration_amount, ' ', packages.duration_unit)
        ELSE concat(packages.duration_amount, ' ', packages.duration_unit, 's')
    END AS duration
FROM 
    packages
WHERE  
    packages.subscription_type = 1 and   packages.subscription_unit = 'single';
` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscribe_data_repeater_2 records
 * @GET /components_data/subscribe_data_repeater_2
 */
router.get('/subscribe_data_repeater_2', async (req, res) => {
	try{
		let sqltext = `SELECT 
    *, 
    CASE 
        WHEN packages.duration_amount = 1 THEN concat(packages.duration_amount, ' ', packages.duration_unit)
        ELSE concat(packages.duration_amount, ' ', packages.duration_unit, 's')
    END AS p
FROM 
    packages
WHERE  
     packages.subscription_type = 1 and   packages.subscription_unit = 'group';
` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscribe_data_repeater_3 records
 * @GET /components_data/subscribe_data_repeater_3
 */
router.get('/subscribe_data_repeater_3', async (req, res) => {
	try{
		let sqltext = `SELECT 
   *, 
    CASE 
        WHEN packages.duration_amount = 1 THEN concat(packages.duration_amount, ' ', packages.duration_unit)
        ELSE concat(packages.duration_amount, ' ', packages.duration_unit, 's')
    END AS p
FROM 
    packages
WHERE  
     packages.subscription_type = 2;
` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscriber_data_component records
 * @GET /components_data/subscriber_data_component
 */
router.get('/subscriber_data_component', async (req, res) => {
	try{
		let sqltext = `SELECT  subscriptions.id, subscriptions.user_id, subscriptions.subscription_code, subscriptions.status, subscriptions.start_date, subscriptions.expiry_date, subscriptions.transaction_id, subscriptions.phone_no, subscriptions.subscription_type_id, subscription_types.id, subscription_types.name, subscription_types.description, subscription_types.membership_fee, subscription_types.created_at, subscription_types.months FROM subscription_types JOIN subscriptions ON subscription_types.id=subscriptions.subscription_type_id WHERE  subscriptions.user_id=:user_id` ;
		let queryParams = {};
queryParams['user_id'] = req.user.id;
		let records = await DB.rawQueryList(sqltext, queryParams,);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscriber_data_component_2 records
 * @GET /components_data/subscriber_data_component_2
 */
router.get('/subscriber_data_component_2', async (req, res) => {
	try{
		let sqltext = `SELECT  lesson_track.id, lesson_track.subscription_id, lesson_track.user_id, lesson_track.lessons_viewed, lesson_track.lesson_balance, lesson_track.total_lessons, lesson_track.package_id, lesson_track.status FROM lesson_track WHERE  (lesson_track.user_id  =:user_id )` ;
		let queryParams = {};
queryParams['user_id'] = req.user.id;
		let records = await DB.rawQueryList(sqltext, queryParams,);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscriber_data_repeater records
 * @GET /components_data/subscriber_data_repeater
 */
router.get('/subscriber_data_repeater', async (req, res) => {
	try{
		let sqltext = `SELECT 
    p.id AS purchase_id,
    pk.name AS package_name,
    p.transaction_date,
    p.expiry_date,
    CASE 
        WHEN p.expiry_date <= NOW() THEN 'expired'
        ELSE 'active'
    END AS status
FROM 
    purchases p
JOIN 
    users u ON p.user_id = u.id
JOIN 
    packages pk ON p.package_id = pk.id
WHERE 
    u.id=:user_id` ;
		let queryParams = {};
queryParams['user_id'] = req.user.id;
		let records = await DB.rawQueryList(sqltext, queryParams,);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscriptionshow_data_repeater records
 * @GET /components_data/subscriptionshow_data_repeater
 */
router.get('/subscriptionshow_data_repeater', async (req, res) => {
	try{
		let sqltext = `SELECT  subscription_types.id, subscription_types.name, subscription_types.description, subscription_types.membership_fee, subscription_types.created_at FROM subscription_types` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscribe_data_repeater_4 records
 * @GET /components_data/subscribe_data_repeater_4
 */
router.get('/subscribe_data_repeater_4', async (req, res) => {
	try{
		let sqltext = `SELECT 
    packages.id, 
    packages.name, 
    packages.description, 
    packages.fee, 
    subscription_type_id ,
    packages.no_of_lessons, 
    packages.duration_amount, 
    packages.duration_unit, 
    CASE 
    WHEN packages.duration_amount = 1 THEN concat(packages.duration_amount, ' ', packages.duration_unit)
        ELSE concat(packages.duration_amount, ' ', packages.duration_unit, 's')
    END AS p
FROM 
    packages
WHERE  
     packages.subscription_type_id = 1;
` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to get subscribe_data_repeater_5 records
 * @GET /components_data/subscribe_data_repeater_5
 */
router.get('/subscribe_data_repeater_5', async (req, res) => {
	try{
		let sqltext = `SELECT 
    packages.id, 
    packages.name, 
    packages.description, 
    packages.fee, 
    packages.no_of_lessons, 
    packages.duration_amount, 
    packages.duration_unit, 
    subscription_type_id ,
    CASE 
    WHEN packages.duration_amount = 1 THEN concat(packages.duration_amount, ' ', packages.duration_unit)
        ELSE concat(packages.duration_amount, ' ', packages.duration_unit, 's')
    END AS p
FROM 
    packages
WHERE  
     packages.subscription_type_id = 2;
` ;
		
		let records = await DB.rawQueryList(sqltext);
		return res.ok(records);
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to getcount_totalpointsearned value
 * @GET /components_data/getcount_totalpointsearned
 */
router.get('/getcount_totalpointsearned', async (req, res) => {
 try{
 	let sqltext = `SELECT  marketers.points AS num FROM marketers WHERE  (marketers.phone  =:phone)` ;
 	let queryParams = {};
queryParams['phone'] = req.user.username;
 	let value = await DB.rawQueryValue(sqltext, queryParams,);
 	// Return 0 if no value found (user is not a marketer)
 	return res.ok((value || 0).toString());
 }
 catch(err){
 	return res.serverError(err);
 }
});


 /**
 * Route to getcount_users value
 * @GET /components_data/getcount_users
 */
router.get('/getcount_users', async (req, res) => {
	try{
		let sqltext = `SELECT COUNT(*) AS num FROM users where account_status='active'` ;
		
		let value = await DB.rawQueryValue(sqltext);
		return res.ok(value.toString());
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to getcount_marketers value
 * @GET /components_data/getcount_marketers
 */
router.get('/getcount_marketers', async (req, res) => {
	try{
		let sqltext = `SELECT COUNT(*) AS num FROM marketers` ;
		
		let value = await DB.rawQueryValue(sqltext);
		return res.ok(value.toString());
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to getcount_subscriptions value
 * @GET /components_data/getcount_subscriptions
 */
router.get('/getcount_subscriptions', async (req, res) => {
	try{
		let sqltext = `SELECT  SUM(transactions.amount) AS num FROM transactions JOIN subscriptions ON transactions.id=subscriptions.transaction_id` ;
		
		let value = await DB.rawQueryValue(sqltext);
		return res.ok(value.toString());
	}
	catch(err){
		return res.serverError(err);
	}
});


 /**
 * Route to getcount_purchases value
 * @GET /components_data/getcount_purchases
 */
router.get('/getcount_purchases', async (req, res) => {
	try{
		let sqltext = `SELECT COUNT(*) AS num FROM purchases` ;
		
		let value = await DB.rawQueryValue(sqltext);
		return res.ok(value.toString());
	}
	catch(err){
		return res.serverError(err);
	}
});

router.post('/guesttrack', async (req, res) => {
    try {
        // Extract request data (IP, User-Agent, etc.)
        const ipAddress = req.body.ip_address ||req.headers['x-forwarded-for'] || req.socket.remoteAddress; // Handle proxied requests
        const userAgent = req.headers['user-agent'] || '';
        const fingerprint = req.body.fingerprint || ''; // Pass fingerprint from the client if available
        const platiform=req.body.platiform
        // Prepare model data
        const modeldata = {
            guest_id: uuidv4(), // Generate a unique guest ID
            ip_address: ipAddress,
            user_agent: userAgent,
            fingerprint: fingerprint,
            is_active: true,
            platiform
        };
        //console.log(modeldata)
        // Check if the guest already exists by `guest_id` or other identifier
        const where = { fingerprint: fingerprint || ipAddress }; // Use fingerprint or fallback to IP
        // Create or update the guest user
        const [guestUser, created] = await DB.GuestUsers.findOrCreate({
            where, // Lookup condition
            defaults: modeldata // Data to insert if not found
        });
        // If the guest already exists, update relevant fields
        if (!created) {
            await guestUser.update(modeldata);
        }
        // Respond to the client
        return res.json({
            success: true,
            message: created ? 'Guest user created' : 'Guest user updated',
            data: guestUser
        });
    } catch (err) {
        //console.error('Error creating or updating guest user:', err);
        return res.status(500).json({
            success: false,
            message: 'Server error',
            error: err.message
        });
    }
});
router.post('/propmtstk', async (req, res) => {  
  try {
      const {phone,amount,callback_Url,transactionData}=req.body;
       const PhoneNumber=phone ||req.user.phone;
       //  //console.log(req.body)
      const response = await mpesaService.lipaNaMpesaOnline(amount,PhoneNumber,callback_Url);
    if (response.error) {
      //console.error('Mpesa Error:', response);
      return res.status(500).json({ error: 'Payment processing failed.' });
    } else if (response.ResponseCode === '0') {
      // Extract relevant information from the response
      const {
        MerchantRequestID,
        CheckoutRequestID,
        ResponseDescription,
        CustomerMessage,
      } = response;
    transactionData.checkout_request_id=CheckoutRequestID;
    let transaction = await DB.Transactions.create(transactionData);
      //console.log('Payment initiated successfully:', response);
      // Respond to client with payment initiation details
      return res.status(200).json({
        success: true,
        message: CustomerMessage,
        paymentDetails: {
          MerchantRequestID,
          CheckoutRequestID,
          ResponseDescription,
        },
      transaction
      });
    } else {
      //console.error('Unexpected Mpesa Response:', response.data);
      return res.status(500).json({ error: 'Unexpected payment response.' });
    }
  } catch (error) {
    //console.error('Error processing payment:', error);
    return res.status(500).json({ error: 'An error occurred while processing the payment.' });
  }
});const updateTransactionsStatus = async (CheckoutRequestID, status, metadata = {}) => {
    const where = { checkout_request_id: CheckoutRequestID };
    // Prepare the data based on the status
    const updateData = { status };
    if (status === 'success') {
        // Add metadata fields if it's a successful transaction
        const { amount = 0.0, reference = '', phoneNumber = '', transactionDate = '' } = metadata;
        updateData.amount = amount;
        updateData.transaction_reference = reference;
        updateData.phone_number = phoneNumber;
        updateData.transactionDate = transactionDate;
    }
    // Perform the update
    await DB.Transactions.update(updateData, { where });
};
router.post('/callback', async (req, res) => {  
   try {
        // Extract callback data from request body
        const callbackData = req.body.Body.stkCallback;
        const CheckoutRequestID = callbackData.CheckoutRequestID;
        //console.log("callbackData",callbackData)
        // Handle unsuccessful transactions
        if (callbackData.ResultCode !== 0) {
            await updateTransactionsStatus(CheckoutRequestID, 'failed', callbackData);
               //console.log("Transaction failed",callbackData)
            return res.status(400).json({ message: 'Transaction failed', data: callbackData });
        }
        // Extract relevant metadata
        const callbackMetadata = callbackData.CallbackMetadata.Item;
        const amount = callbackMetadata.find(item => item.Name === 'Amount')?.Value || 0.0;
        const mpesaReceiptNumber = callbackMetadata.find(item => item.Name === 'MpesaReceiptNumber')?.Value || '';
        const transactionDate = callbackMetadata.find(item => item.Name === 'TransactionDate')?.Value || '';
        const phoneNumber = callbackMetadata.find(item => item.Name === 'PhoneNumber')?.Value || '';
        // Prepare metadata for success status
        const successMetadata = {
            amount,
            reference: mpesaReceiptNumber,
            phoneNumber,
            transactionDate
        };
        // Update payment status
        await updateTransactionsStatus(CheckoutRequestID, 'success', successMetadata);
        // Construct response data
        const responseData = {
            amount,
            mpesaReceiptNumber,
            phoneNumber,
        };
        res.status(200).json({ message: 'Callback processed successfully', data: responseData });
    } catch (err) {
        //console.error(err);
        // Handle server error and update payment status
        try {
            await updateTransactionsStatus(req.body?.Body?.stkCallback?.CheckoutRequestID, 'error', { error: err.message });
        } catch (updateError) {
            //console.error('Failed to update error status:', updateError.message);
        }
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});
router.post('/checkstatus', async (req, res) => {  
    try {
    const { payment_id } = req.body;
    // Fetch payment transaction details
    let where = { id: payment_id };
    let paymentsTransaction = await DB.Transactions.findOne({ where });
    if (!paymentsTransaction) {
      return res.status(400).json({ error: "Payment transaction not found or not successful" });
    }
  return res.status(200).json({status:paymentsTransaction.status, message: "payment successfully created"});
  } catch (err) {
    //console.error("Error processing request:", err);
    return res.status(500).json({ error: "An internal server error occurred" });
  }
});


// 1. Transaction validation helper (used in both /subscription and /searchtransaction)
async function validateTransaction(transactionId) {
    const transaction = await DB.Transactions.findOne({
        where: { id: transactionId }
    });

    if (!transaction) {
        throw new Error("Transaction not found");
    }

    if (transaction.status !== "success") {
        throw new Error("Transaction is not successful");
    }

    if (transaction.payment_status === "used") {
        throw new Error("Transaction has already been used");
    }

    const existingSubscription = await DB.Subscriptions.findOne({
        where: { transaction_id: transactionId }
    });

    if (existingSubscription) {
        throw new Error("Transaction ID has already been used");
    }

    return transaction;
}

// 2. SMS sending helper (used in both /smsuser and /send_subscription_code)
async function sendSubscriptionSMS(phone, subscriptionCode, isNewUser = false) {
    console.log("in sms")
    let message;

    if (isNewUser) {
        message = `Your new temporary password is: ${subscriptionCode}. Please log in and change it immediately.`;
    } else {
        message = `Hello! Your subscription code is ${subscriptionCode}. You can log in using your phone number and this code. Welcome aboard!`;
    }

    return await sendSms(phone, message);
}

// 3. Package details fetcher (used in multiple places)
async function getPackageDetails(packageId) {
    const packageDetails = await DB.Packages.findOne({
        where: { id: packageId }
    });

    if (!packageDetails) {
        throw new Error("Package not found");
    }

    return packageDetails;
}

// 4. User subscription checker (used in /checksubscription and /send_subscription_code)
async function getUserActiveSubscription(phone, userId = null) {
    const where = {
        phone_no: phone,
        status: 'active'
    };

    if (userId) {
        where.user_id = userId;
    }

    return await DB.Subscriptions.findOne({ where });
}
async function manageSubscription({ transaction, user }) {
    console.log("[DEBUG] manageSubscription called with:", { transaction_id: transaction?.id, user_id: user?.user_id });

    const subscriptionDetails = await DB.SubscriptionTypes.findOne({
        where: { id: transaction.details_id },
    });

    console.log("[DEBUG] Found subscription details:", { id: subscriptionDetails?.id, months: subscriptionDetails?.months });

    if (!subscriptionDetails) {
        throw new Error("Invalid subscription details.");
    }

    const userDetails = await DB.Users.findOne({ where: { id: user.user_id } });
    console.log("[DEBUG] Found user details:", { id: userDetails?.id, subscription_code: userDetails?.subscription_code });

    if (!userDetails) {
        throw new Error("User not found.");
    }

    const subscription_code = userDetails.subscription_code;
    const phoneNo = user.phone || transaction.phone_number;

    const activeSubscription = await DB.Subscriptions.findOne({
        where: {
            phone_no: phoneNo,
            status: "active",
            subscription_type_id: transaction.details_id,
        },
    });

    console.log("[DEBUG] Active subscription check:", {
        found: !!activeSubscription,
        id: activeSubscription?.id,
        expiry_date: activeSubscription?.expiry_date
    });

    const start_date = moment();
    let expiry_date;
    let lessonTrackUpdate;

    if (activeSubscription) {
        // Extend expiration date for existing active subscription
        expiry_date = moment(activeSubscription.expiry_date).add(subscriptionDetails.months, "months");
        console.log("[DEBUG] Extending subscription:", {
            old_expiry: activeSubscription.expiry_date,
            new_expiry: expiry_date.toDate()
        });

        await DB.Subscriptions.update(
            { expiry_date: expiry_date.toDate() },
            { where: { id: activeSubscription.id } }
        );

        // Update lesson track for existing subscription
        lessonTrackUpdate = await DB.LessonTrack.update(
            {
                expires_at: expiry_date.toDate(),
                updated_at: new Date(),
                status: 'active'
            },
            {
                where: {
                    subscription_id: activeSubscription.subscription_type_id,
                    user_id: user.user_id
                }
            }
        );

        console.log("[DEBUG] Extended existing subscription:", {
            subscription_id: activeSubscription.id,
            lesson_track_updated: lessonTrackUpdate[0] > 0
        });
        
        return { status: "success", message: "Subscription extended successfully" };
    }

    // Calculate expiration date for new subscription
    expiry_date = moment(start_date).add(subscriptionDetails.months, "months");
    console.log("[DEBUG] Creating new subscription with expiry date:", expiry_date.toDate());

    // Create new subscription
    const modeldata = {
        user_id: user.user_id,
        subscription_type_id: transaction.details_id,
        subscription_code,
        status: "active",
        start_date: start_date.toDate(),
        expiry_date: expiry_date.toDate(),
        transaction_id: transaction.id,
        phone_no: phoneNo,
    };

    const newSubscription = await DB.Subscriptions.create(modeldata);
    console.log("[DEBUG] Created new subscription:", { id: newSubscription.id, status: newSubscription.status });

    // Update transaction status
    await DB.Transactions.update(
        { user_id: user.user_id, payment_status: "used" },
        { where: { id: transaction.id } }
    );

    // Get package details for the new subscription
    const newPackageDetails = await DB.Packages.findOne({
        where: { id: subscriptionDetails.id }
    });

    console.log("[DEBUG] Found package details:", {
        id: newPackageDetails?.id,
        name: newPackageDetails?.name,
        lessons: newPackageDetails?.no_of_lessons
    });

    if (!newPackageDetails) {
        throw new Error("Package not found for this subscription type.");
    }

    // Check if user has any active lesson track record (regardless of package)
    const existingLessonTrack = await DB.LessonTrack.findOne({
        where: {
            user_id: user.user_id,
        },
        order: [['created_at', 'DESC']] // Get the most recent active one
    });

    console.log("[DEBUG] Existing lesson track check:", {
        found: !!existingLessonTrack,
        id: existingLessonTrack?.id,
        package_id: existingLessonTrack?.package_id,
        lesson_balance: existingLessonTrack?.lesson_balance
    });

    let newLessonBalance;
    let newTotalLessons;
    let isPackageChange = false;

    if (existingLessonTrack) {
        // User is renewing, check if it's the same package or different
        isPackageChange = existingLessonTrack.package_id !== subscriptionDetails.package_id;
        console.log("[DEBUG] Package change check:", {
            isPackageChange,
            old_package_id: existingLessonTrack.package_id,
            new_package_id: subscriptionDetails.package_id
        });

        if (isPackageChange) {
            // User is switching to a different package
            // Close the old lesson track record
            await DB.LessonTrack.update(
                {
                    status: 'expired',
                    updated_at: new Date()
                },
                {
                    where: { id: existingLessonTrack.id }
                }
            );

            // For package change: Start fresh with new package lessons
            // Option 1: Reset completely (only new package lessons)
            newLessonBalance = newPackageDetails.no_of_lessons;
            newTotalLessons = newPackageDetails.no_of_lessons;

            console.log("[DEBUG] Package change - resetting lesson balance:", {
                newLessonBalance,
                newTotalLessons
            });

            // Option 2: Carry over remaining balance (if business allows)
            // newLessonBalance = existingLessonTrack.lesson_balance + newPackageDetails.no_of_lessons;
            // newTotalLessons = existingLessonTrack.total_lessons + newPackageDetails.no_of_lessons;

        } else {
            // Same package renewal - add new package lessons to existing balance
            newLessonBalance = existingLessonTrack.lesson_balance + newPackageDetails.no_of_lessons;
            newTotalLessons = existingLessonTrack.total_lessons + newPackageDetails.no_of_lessons;

            console.log("[DEBUG] Same package renewal - adding lessons:", {
                previous_balance: existingLessonTrack.lesson_balance,
                lessons_added: newPackageDetails.no_of_lessons,
                newLessonBalance,
                newTotalLessons
            });
        }

        if (isPackageChange) {
            // Create new lesson track record for new package
            const lessonTrackData = {
                subscription_id: newSubscription.id,
                user_id: user.user_id,
                package_id: subscriptionDetails.package_id,
                lessons_viewed: 0,
                lesson_balance: newLessonBalance,
                total_lessons: newTotalLessons,
                status: 'active',
                last_accessed: null,
                created_at: new Date(),
                expires_at: expiry_date.toDate(),
                updated_at: new Date()
            };

            lessonTrackUpdate = await DB.LessonTrack.create(lessonTrackData);
            console.log("[DEBUG] Created new lesson track for package change:", { id: lessonTrackUpdate.id });
        } else {
            // Update existing lesson track (same package)
            lessonTrackUpdate = await DB.LessonTrack.update(
                {
                    subscription_id: newSubscription.id,
                    lesson_balance: newLessonBalance,
                    total_lessons: newTotalLessons,
                    expires_at: expiry_date.toDate(),
                    updated_at: new Date(),
                    status: 'active'
                },
                {
                    where: { id: existingLessonTrack.id }
                }
            );

            console.log("[DEBUG] Updated existing lesson track:", {
                updated_rows: lessonTrackUpdate[0],
                lesson_track_id: existingLessonTrack.id
            });
        }
    } else {
        // First time purchase - set initial balance to package lessons
        newLessonBalance = newPackageDetails.no_of_lessons;
        newTotalLessons = newPackageDetails.no_of_lessons;

        console.log("[DEBUG] First time purchase - initial lesson balance:", {
            newLessonBalance,
            newTotalLessons
        });

        // Create new lesson track record
        const lessonTrackData = {
            subscription_id: newSubscription.id,
            user_id: user.user_id,
            package_id: transaction?.id,
            lessons_viewed: 0,
            lesson_balance: newLessonBalance,
            total_lessons: newTotalLessons,
            status: 'active',
            last_accessed: null,
            created_at: new Date(),
            expires_at: expiry_date.toDate(),
            updated_at: new Date()
        };
        console.log("creaing lesson track", lessonTrackData)
        lessonTrackUpdate = await DB.LessonTrack.create(lessonTrackData);
        console.log("[DEBUG] Created new lesson track for first time purchase:", { id: lessonTrackUpdate.id });
    }

    // Get old package name for comparison (if package changed)
    let oldPackageName = null;
    if (isPackageChange && existingLessonTrack) {
        const oldPackage = await DB.Packages.findOne({
            where: { id: existingLessonTrack.package_id }
        });
        oldPackageName = oldPackage ? oldPackage.name : null;
        console.log("[DEBUG] Found old package details:", { id: oldPackage?.id, name: oldPackageName });
    }

    const result = {
        status: "success",
        message: isPackageChange ?
            `Package changed from ${oldPackageName || 'previous package'} to ${newPackageDetails.name}` :
            existingLessonTrack ? "Subscription renewed successfully" : "Subscription created successfully",
        subscription: newSubscription,
        lessonTrack: lessonTrackUpdate,
        lessonsAdded: newPackageDetails.no_of_lessons,
        newLessonBalance: newLessonBalance,
        isPackageChange: isPackageChange,
        oldPackageId: isPackageChange && existingLessonTrack ? existingLessonTrack.package_id : null,
        newPackageId: subscriptionDetails.package_id,
        oldPackageName: oldPackageName,
        newPackageName: newPackageDetails.name
    };

    console.log("[DEBUG] Returning result:", {
        status: result.status,
        message: result.message,
        isPackageChange: result.isPackageChange,
        newLessonBalance: result.newLessonBalance
    });

    return result;
}
router.post("/subscription", async (req, res) => {
    console.log("insubscrpition")
    const { transaction_id, user_id } = req.body;

    try {
        // Use the reusable validator
        const transaction = await validateTransaction(transaction_id);

        const result = await manageSubscription({
            transaction,
            user: { phone: transaction.phone_number, user_id: user_id || req.user.id },
        });
        console.log("manageSubscription result", result.subscription)
        sendSubscriptionSMS(result.subscription.phone_no, result.subscription.subscription_code)
        
        // Award commission to marketer if user was referred
        const effectiveUserId = user_id || req.user.id;
        await awardCommission(transaction, effectiveUserId, 'subscription');
        
        return res.status(200).json(result);
    } catch (err) {
        // Return appropriate status based on error type
        const status = err.message.includes("not found") ? 404 :
            err.message.includes("already been used") ? 400 : 500;

        return res.status(status).json({
            error: err.message
        });
    }
});

router.post('/checksubscription', async (req, res) => { 
    const {phone_number,subscription_code}=req.body 
    try{
        let where = {'phone_no': req.user.phone,'status':'active'};
        let record = await DB.Subscriptions.findOne({ where });
        return res.ok(record);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.post('/searchtransaction', async (req, res) => {
    const { reference } = req.body;

    try {
        let transaction = await DB.Transactions.findOne({
            where: { transaction_reference: reference, status: 'success' }
        });

        if (!transaction) {
            return res.status(404).json({ error: "Transaction not found" });
        }

        // Reuse validation logic
        await validateTransaction(transaction.id);

        return res.status(200).json({ transaction_id: transaction.id });

    } catch (err) {
        return res.status(400).json({ error: err.message });
    }
});
router.post('/smsuser', async (req, res) => {
    const { phone, user_id } = req.body;

    try {
        if (!phone || !user_id) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: phone or user_id',
            });
        }

        // Use the helper function
        const subscription = await getUserActiveSubscription(phone, user_id);

        if (!subscription) {
            return res.status(404).json({
                success: false,
                error: 'Subscription not found or inactive',
            });
        }

        // Use the reusable SMS helper
        const smsResponse = await sendSubscriptionSMS(phone, subscription.subscription_code);

        return res.status(200).json({
            success: true,
            message: 'SMS sent successfully',
            data: smsResponse,
        });

    } catch (err) {
        return res.status(500).json({
            success: false,
            error: 'Failed to send SMS',
            details: err.message,
        });
    }
});
router.post('/send_subscription_code', async (req, res) => {
    const { phone_no } = req.body;

    if (!phone_no) {
        return res.status(400).json({
            success: false,
            message: 'Phone number is required'
        });
    }

    try {
        // Use the helper function
        const subscription = await getUserActiveSubscription(phone_no);

        let newPassword;
        let isNewUser = false;

        if (subscription) {
            newPassword = subscription.subscription_code;
        } else {
            newPassword = Math.random().toString(36).slice(-8);
            isNewUser = true;
        }

        // Hash and update password
        const hashedPassword = utils.passwordHash(newPassword);
        await DB.Users.update({ password: hashedPassword }, { where: { phone: phone_no } });

        // Use the reusable SMS helper
        await sendSubscriptionSMS(phone_no, newPassword, isNewUser);

        return res.status(200).json({
            success: true,
            message: subscription
                ? 'Subscription code sent and password updated'
                : 'New password sent successfully',
        });

    } catch (err) {
        return res.status(500).json({
            success: false,
            message: 'An error occurred while processing your request',
            error: err.message,
        });
    }
});


router.get('smsbalance',async (req,res)=>{
	try {
		const balanceInfo = await getBalance();
		res.status(200).json({balanceInfo})
	}catch(e){
	//console.error(e);
	}
});
router.post('/checktrans', async (req, res) => {
    const { payment_id, checkout_request_id } = req.body;
    // Validate inputs
    if (!payment_id || !checkout_request_id) {
        return res.status(400).json({ error: "Both payment_id and checkout_request_id are required" });
    }
    try {
        // Query STK status
        const response = await mpesaService.queryStkStatus(checkout_request_id);
        //console.log("STK Response:", response); // Debugging
        if (response?.ResultCode === '0') {
            const {
                ResponseCode,
                ResponseDescription,
                MerchantRequestID,
                CheckoutRequestID,
                ResultCode,
                ResultDesc,
            } = response;
            const where = { checkout_request_id };
            const modeldata = { status: 'success' };
            // Update database
            await DB.Transactions.update(modeldata, { where });
            return res.status(200).json({
                success: true,
                message: ResponseDescription,
                responseCode: ResponseCode,
                merchantRequestID: MerchantRequestID,
                checkoutRequestID: CheckoutRequestID,
                resultCode: ResultCode,
                resultDescription: ResultDesc,
            });
        } else {
            return res.status(200).json({ // Changed 400 -> 200
                success: false,
                message: response?.ResponseDescription || "Unknown error",
                responseCode: response?.ResponseCode || "N/A",
                merchantRequestID: response?.MerchantRequestID || "N/A",
                checkoutRequestID: response?.CheckoutRequestID || "N/A",
                resultCode: response?.ResultCode || "N/A",
                resultDescription: response?.ResultDesc || "N/A"
            });
        }
    } catch (err) {
        //console.error('Error querying STK status:', {
        //     message: err.message,
        //     stack: err.stack,
        //     additionalInfo: { payment_id, checkout_request_id },
        // });
        return res.status(500).json({ error: "An error occurred while querying the STK status" });
    }
});
async function calculateExpiryDate(packageId) {
    let packageDetails = await DB.Packages.findOne({ where: { id: packageId } });
    if (!packageDetails) {
        throw new Error("Package not found.");
    }
    let { duration_amount, duration_unit } = packageDetails;
    if (!['minute', 'day', 'week', 'month', 'year'].includes(duration_unit)) {
        throw new Error("Invalid duration unit.");
    }
    if (isNaN(duration_amount) || duration_amount <= 0) {
        throw new Error("Invalid duration amount.");
    }
    let expiryDate = new Date();
    switch (duration_unit) {
        case "minute":
            expiryDate.setMinutes(expiryDate.getMinutes() + duration_amount);
            break;
        case "day":
            expiryDate.setDate(expiryDate.getDate() + duration_amount);
            break;
        case "week":
            expiryDate.setDate(expiryDate.getDate() + duration_amount * 7);
            break;
        case "month":
            expiryDate.setMonth(expiryDate.getMonth() + duration_amount);
            break;
        case "year":
            expiryDate.setFullYear(expiryDate.getFullYear() + duration_amount);
            break;
    }
    return expiryDate;
}
async function createLessonTrack(userId, packageId) {
    // Fetch package details to know the number of lessons
    let packageDetails = await DB.Packages.findOne({ where: { id: packageId } });
    if (!packageDetails) {
        throw new Error("Package not found.");
    }
    const { no_of_lessons,subscription_type_id } = packageDetails;
    // Create a new lesson track for the user
    await DB.LessonTrack.create({
        user_id: userId,
        package_id: packageId,
        total_lessons: no_of_lessons,
        lesson_balance: no_of_lessons,
        subscription_id:subscription_type_id, // Initially, the balance equals the total lessons
        status: 'active', // Assuming the package is still active
    });
}
async function updateLessonTrackForActivePurchase(userId, packageId) {
    let subscriptions = await DB.Subscriptions.findOne({ where: { user_id: userId } });
    let [lessonTrack, created] = await DB.LessonTrack.findOrCreate({
        where: { user_id: userId, package_id: packageId, status: 'active' },
        defaults: {
            total_lessons: 0, // Placeholder; will be updated below
            lesson_balance: 0,
            status: 'active',
            subscription_id: subscriptions?.subscription_type_id,
        },
    });
    if (created) {
        // If this was a new record, update it instead of creating a second row
        let packageDetails = await DB.Packages.findOne({ where: { id: packageId } });
        if (packageDetails) {
            lessonTrack.total_lessons = packageDetails.no_of_lessons;
            lessonTrack.lesson_balance = packageDetails.no_of_lessons;
            lessonTrack.subscription_id = packageDetails.subscription_type_id;
            await lessonTrack.save();
        }
    } else {
        // If the record already existed, just update the lesson balance
        lessonTrack.lesson_balance += lessonTrack.total_lessons;
        await lessonTrack.save();
    }
}
router.post('/buypackage', async (req, res) => {
    const { transaction_id } = req.body;
    try {
        // Validate input
        if (!transaction_id) {
            return res.status(400).json({
                success: false,
                message: "Transaction ID is required.",
            });
        }
        // Fetch the transaction details
        let transaction = await DB.Transactions.findOne({ where: { id: transaction_id ,status:"success",payment_status:"awaiting"} });
        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: "Transaction not found ot it has been used already",
            });
        }
        // Update transaction status to "used"
        await DB.Transactions.update(
            { payment_status: 'used' },
            { where: { id: transaction_id } }
        );
        // Prepare data for Purchases table
        let expiry_date = await calculateExpiryDate(transaction.details_id);
        let purchaseData = {
            user_id: transaction.user_id,
            package_id: transaction.details_id, // Assuming this maps to a package
            transaction_date: transaction.transactionDate,
            transaction_status: transaction.status,
            payment_reference: transaction.transaction_reference,
            amount_paid: transaction.amount,
            expiry_date: expiry_date,
        };
        // Create a new purchase
        let newPurchase = await DB.Purchases.create(purchaseData);
        // Update lesson track for the user
        await updateLessonTrackForActivePurchase(transaction.user_id, transaction.details_id);
        
        // Award commission to marketer if user was referred
        await awardCommission(transaction, transaction.user_id, 'package');
        
        return res.status(200).json({
            success: true,
            message: "Purchase record created and lesson track updated successfully.",
            data: newPurchase,
        });
    } catch (err) {
        //console.error("Error in transaction handling:", err);
        return res.status(500).json({
            success: false,
            message: "Internal server error.",
            error: err.message,
        });
    }
});
router.post('/createlearningarea', async (req, res) => {
    try {
        // Call the Muse service to list collections
        const formData=req.body;
        const response = await s3CloudFrontService.createCollection(formData);
      return res.status(200).json({
                success: true,
                message: "Collections create successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.get('/learningareas', async (req, res) => {
    try {
        // Call the Muse service to list collections
        const response = await s3CloudFrontService.listLearningAreas();

      return res.status(200).json({
                success: true,
                message: "Collections retrieved successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.get('/deletelearningarea/:scid', async (req, res) => {
    try {
        // Call the Muse service to list collections
        const scid=req.params.scid;
        const response = await s3CloudFrontService.deleteCollection(scid);
      return res.status(200).json({
                success: true,
                message: "Collections deleted successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.post('/viewlearningarea', async (req, res) => {
    try {
        // Call the Muse service to list collections
        const {scid}=req.body
        const response = await s3CloudFrontService.getCollection(scid);
      return res.status(200).json({
                success: true,
                message: "Collections retrieved successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.post('/uploadvideo', async (req, res) => {  
      try {
    const { scid } = req.body;
    const file = req.file; // Assuming middleware like Multer is handling the file upload
    if (!file) {
      return res.status(400).json({
        success: false,
        message: "No file provided",
      });
    }
    const filePath = file.path; // Path where the file is temporarily stored
    const fileName = file.originalname; // Original file name
    // Call the Muse service to upload the video
    const response = await s3CloudFrontService.uploadVideo(filePath, fileName);
    return res.status(200).json({
      success: true,
      message: "Videos uploaded successfully",
      data: response,
    });
  } catch (err) {
    //console.error("Error uploading video:", err);
    return res.status(500).json({
      success: false,
      message: "An error occurred while uploading the video",
      error: err.message || "Unknown error",
    });
  }
});
router.get('/deletevid/:fid', async (req, res) => {  
   try {
        // Call the Muse service to list collections
        const fid=req.params.fid;
        const response = await s3CloudFrontService.deleteVideo(fid);
      return res.status(200).json({
                success: true,
                message: "Videos deleted successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.post('/editvideo', async (req, res) => {  
    const {fid,data}=req.body;
    try{
        const response = await s3CloudFrontService.updateVideo(fid,data)
    return res.status(200).json({
                success: true,
                message: "Videos deleted successfully",
                data: response, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
import  { Op }  from "sequelize"
router.post('/user_activity', async (req, res) => {
  try {
    //console.log(req.body);
    const { sessionDuration, fingerprint, status, ipAddress, device, platiform } = req.body;
    const user_id = req.user?.id || null; // Handle guest users if user_id is not available
    // Define the data to be inserted or updated
    const modeldata = {
      user_id,
      fingerprint,
      session_duration: sessionDuration,
      status,
      ip_address: ipAddress,
      device,
      platiform,
       activity_time:new Date(),
    };
    // Check if a record exists with the given fingerprint and user_id
    let existingRecord = await DB.UserActivity.findOne({
      where: {
        fingerprint: fingerprint,
        user_id: user_id, // `null` for guest users, otherwise the user_id
      },
    });
    if (existingRecord) {
      // Update the existing record
      await existingRecord.update(modeldata);
      //console.log("Record updated:", modeldata);
    } else {
      // Create a new record
      await DB.UserActivity.create(modeldata);
      //console.log("New record created:", modeldata);
    }
    return res.status(200).json({ success: true, message: "Activity recorded successfully." });
  } catch (err) {
    //console.error("Error handling activity:", err);
    return res.status(500).json({ success: false, error: "An error occurred while processing activity." });
  }
});
const INACTIVITY_TIMEOUT = 60001; // 1 minute
router.get('/check_user_activity', async (req, res) => {
  try {
    const now = new Date();
    const cutoffTime = new Date(now - INACTIVITY_TIMEOUT);
    //console.log('Running inactivity check...');
    // Update all users whose activity_time exceeds the timeout
    const [affectedRows] = await DB.UserActivity.update(
    { status: 'inactive',"session_duration": 0},
      {
        where: {
          activity_time: { [Op.lt]: cutoffTime },
          status: { [Op.ne]: 'inactive' },
        },
      }
    );
    //console.log(`${affectedRows} users marked as inactive.`);
    return res.status(200).json({ success: true, message: 'Inactivity check completed.', affectedRows });
  } catch (err) {
    //console.error('Error during inactivity check:', err);
    return res.status(500).json({ success: false, error: 'An error occurred during the inactivity check.' });
  }
});
router.get('/getusersactivity', async (req, res) => {  
    try{
        let sqltext = "SELECT  user_activity.fingerprint, user_activity.session_duration, user_activity.status, user_activity.activity_type, user_activity.activity_time, user_activity.platiform, user_activity.device, user_activity.ip_address, users.id, users.username, users.phone, users.email, users.subscription_code, roles.role_name FROM users JOIN user_activity ON users.id=user_activity.user_id  JOIN roles ON roles.role_id=users.user_role_id WHERE  (user_activity.status  =:status )";
        let queryParams = {
            status: 'active'
        }
        let records = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(records);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.post('/store_guest', async (req, res) => {  
    try {
        const { phone, fingerprint, lesson_id, transaction_id } = req.body;
        //console.log('Store guest request:', req.body);
        
        // Validate the required input
        if (!phone || !fingerprint || !lesson_id) {
            return res.status(400).json({
                success: false,
                message: "Phone, fingerprint, and lesson_id are required fields.",
            });
        }

        const now = new Date();
        
        // Get lesson settings for guest/non-subscribed users
        const lessonSetting = await DB.LessonSetting.findOne({
            where: {
                subscription_type: 'non_subscribed'
            }
        });

        if (!lessonSetting) {
            return res.status(500).json({
                success: false,
                message: "Lesson settings not found for guest access.",
            });
        }

        // Calculate session expiration based on lesson settings
        const expiresAt = new Date(now.getTime() + (lessonSetting.duration * 60 * 1000));
        const sessionId = `${phone}_${fingerprint}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // Prepare the data for insertion
        let modeldata = {
            phone: phone,
            lesson_id: lesson_id,
            access_type: 'guest',
            session_id: sessionId,
            expires_at: expiresAt,
            accessed_at: now,
            status: 'active',
            ip_address: req.ip,
            user_agent: req.get('User-Agent'),
            lesson_setting_id: lessonSetting.id
        };

        // Check if there's an existing active session for this phone and lesson
        const existingSession = await DB.LessonAccessLogs.findOne({
            where: {
                phone: phone,
                lesson_id: lesson_id,
                status: 'active',
                expires_at: { [DB.op.gt]: now }
            },
            order: [['created_at', 'DESC']]
        });

        let guestSession;

        if (existingSession) {
            // Update existing session
            await DB.LessonAccessLogs.update(
                {
                    accessed_at: now,
                    expires_at: expiresAt, // Reset expiry time
                    ip_address: req.ip,
                    user_agent: req.get('User-Agent')
                },
                {
                    where: { id: existingSession.id }
                }
            );
            
            guestSession = await DB.LessonAccessLogs.findByPk(existingSession.id);
        } else {
            // Create new session
            guestSession = await DB.LessonAccessLogs.create(modeldata);
        }

        // Return a success response
        return res.status(200).json({
            success: true,
            message: existingSession ? "Guest session resumed." : "Guest session created successfully.",
            data: {
                session_id: guestSession.session_id,
                expires_at: guestSession.expires_at,
                access_type: guestSession.access_type,
                lesson_id: guestSession.lesson_id,
                phone: guestSession.phone,
                duration_minutes: lessonSetting.duration
            },
        });
    } catch (err) {
        console.error("Error processing guest request:", err);
        return res.status(500).json({
            success: false,
            message: "Internal server error.",
            error: err.message,
        });
    }
});
router.get('/get_active_guest', async (req, res) => {  
    try {
        const now = new Date();
        const { phone } = req.query;

        if (!phone) {
            return res.status(400).json({
                success: false,
                message: "Phone number is required"
            });
        }

        // Get active access logs for this phone
        const activeAccessLogs = await DB.LessonAccessLogs.findAll({
            where: {
                phone: phone,
                status: 'active',
                expires_at: { [DB.op.gt]: now }
            },
            order: [['accessed_at', 'DESC']]
        });

        // Format the response to match frontend expectations
        const formattedRecords = activeAccessLogs.map(log => ({
            id: log.id, // Use access log ID
            phone: log.phone,
            fingerPrint: log.session_id, // Use session_id as fingerprint
            lesson_id: log.lesson_id,
            expires_at: log.expires_at,
            accessed_at: log.accessed_at,
            session_id: log.session_id
        }));

        return res.status(200).json({
            success: true,
            message: "Active guest access logs fetched successfully",
            data: formattedRecords // This will be response.data.data in frontend
        });

    } catch (err) {
        //console.error("Error fetching guest access logs:", err);
        return res.status(500).json({
            success: false,
            message: "Internal server error.",
            error: err.message
        });
    }
});
router.get('/lesson_setting', async (req, res) => {  
    try{
        let where = {'subscription_type': req.query.subscription_type};
        let record = await DB.LessonSetting.findOne({ where });
        return res.ok(record);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.get('/getvideodata', async (req, res) => {  
      try {
        // Call the Muse service to list collections
        const lesson_id=req.query.lesson_id;
        const phone=req.query.phone;
        let where = {'lesson_id': lesson_id,'phone':phone};
        //console.log("where",where)
          let record = await DB.GuestTracker.findOne({ where });
      return res.status(200).json({
                success: true,
                message: "Videos got successfully",
                data: record, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
import { QueryTypes } from 'sequelize';
import { validationResult } from 'express-validator';
router.post('/save_viewing_time', async (req, res) => {
    try {
        const { timeViewTime, resumeTime, phone, lesson_id, id } = req.body;
        // Input validation
        if (!id || !phone || !lesson_id) {
            return res.status(400).json({
                success: false,
                message: "ID, phone, and lesson_id are required.",
            });
        }
        // Fetch existing guest record
        const existingRecord = await DB.GuestTracker.findOne({ where: { id } });
        if (!existingRecord) {
            return res.status(404).json({
                success: false,
                message: `Record with ID ${id} not found.`,
            });
        }
        // Fetch lesson settings
        const lessonRecord = await DB.LessonSetting.findOne({ where: { id: 1 } });
        if (!lessonRecord) {
            return res.status(500).json({
                success: false,
                message: "Lesson settings not configured. Please contact support.",
            });
        }
        const limitTime = lessonRecord.duaration || 0;
        // Calculate updated values
        const status = timeViewTime >= limitTime ? 'expired' : 'active';
        const watchStart =
            timeViewTime < 1
                ? moment().format('YYYY-MM-DD HH:mm:ss')
                : moment(existingRecord.watchstart).isValid()
                    ? moment(existingRecord.watchstart).format('YYYY-MM-DD HH:mm:ss')
                    : moment().format('YYYY-MM-DD HH:mm:ss');
        const updatedResumeTime = resumeTime
            ? moment(resumeTime).format('YYYY-MM-DD HH:mm:ss')
            : moment(existingRecord.resumetime).isValid()
                ? moment(existingRecord.resumetime).format('YYYY-MM-DD HH:mm:ss')
                : moment().format('YYYY-MM-DD HH:mm:ss');
        // Update the guest record
        const [updatedRows] = await DB.GuestTracker.update(
            {
                timeViewTime: timeViewTime || 0,
                status,
                watchStart,
                resumeTime: updatedResumeTime,
            },
            { where: { id } }
        );
        if (updatedRows === 0) {
            return res.status(400).json({
                success: false,
                message: "No records updated. Please check the ID or other inputs.",
            });
        }
        // Fetch the updated record
        const updatedRecord = await DB.GuestTracker.findOne({ where: { id } });
        return res.status(200).json({
            success: true,
            message: "Guest data updated successfully.",
            data: updatedRecord,
        });
    } catch (err) {
        //console.error("Error updating guest data:", err);
        return res.status(500).json({
            success: false,
            message: "Internal server error.",
            error: err.message,
        });
    }
});
router.post('/updateusertimeview', async (req, res) => {
  try {
    const {
      phone,
      lesson_id,
      watchStart,
      resumeTime,
      timeViewTime,
      lastTimeViewTime,
    } = req.body;
    //console.log('Request body:', req.body);
    // Validate required fields
    if (!lesson_id || !phone) {
      return res.status(400).json({
        error: 'Missing required fields: `lesson_id` or `phone`.',
      });
    }
    // Fetch the lesson settings for time limit
    const lessonRecord = await DB.LessonSetting.findOne({ where: { id: 1 } });
    const limitTime = lessonRecord.duration || 0; // Limit in minutes
    // Calculate the total time viewed
    const existingRecord = await DB.GuestTracker.findOne({ where: { phone, lesson_id:lesson_id } });
    const totalViewTime = (existingRecord?.timeviewtime*1 || 0) + timeViewTime*1;
    // Determine status
    //console.log("existingRecord",existingRecord.timeviewtime*1)
    //console.log("total,",totalViewTime);
    //console.log("limitTime",lessonRecord.duration)
    const status = totalViewTime >= limitTime * 60 ? 'expired' : 'active';
    // Update the record
    const sqlText = `
      UPDATE guest_tracker 
      SET 
        watchStart = :watchStart,
        resumeTime = :resumeTime,
        timeViewTime = :timeViewTime,
        status = :status
      WHERE 
        phone = :phone AND lesson_id = :lesson_id
    `;
    const queryParams = {
      watchStart: watchStart || null,
      resumeTime: lastTimeViewTime || null,
      timeViewTime: totalViewTime,
      status,
      phone,
      lesson_id,
    };
    const [results, metadata] = await DB.sequelize.query(sqlText, {
      replacements: queryParams,
      type: DB.sequelize.QueryTypes.UPDATE,
    });
    //console.log('Update result:', metadata);
    if (metadata > 0) {
      return res.status(200).json({
        message: 'Record updated successfully.',
        status,
        totalViewTime,
      });
    } else {
      return res.status(404).json({
        error: 'No record found to update.',
      });
    }
  } catch (err) {
    //console.error(err);
    return res.status(500).json({
      error: 'Internal Server Error',
      details: err.message,
    });
  }
});
router.get('/check_subscribed_status', async (req, res) => {  
    try{
        let sqltext = "SELECT COUNT(*) FROM subscriptions WHERE  (subscriptions.status  ='active' ) AND (subscriptions.user_id  =:user_id )";
        let queryParams = {
            user_id: req,user,id
        }
        let records = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(records);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.get('/checksubscription', async (req, res) => {  
    try{
        let sqltext = "SELECT  subscriptions.id, subscriptions.user_id, subscriptions.subscription_code, subscriptions.status, subscriptions.start_date, subscriptions.expiry_date, subscriptions.transaction_id, subscriptions.phone_no, subscriptions.subscription_type_id, subscription_types.name, subscription_types.description, subscription_types.membership_fee, subscription_types.created_at, subscription_types.months FROM subscription_types JOIN subscriptions ON subscription_types.id=subscriptions.subscription_type_id WHERE  (subscriptions.user_id  =:user_id ) AND (subscriptions.status  ='active' )";
        let queryParams = {
            user_id:req.user.id||0
        }
        let records = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(records);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.get('/subcriberdetails', async (req, res) => {
  try {
    // Guard against missing user context
    if (!req.user || !req.user.id) {
      return res.badRequest({ error: "Missing user context" });
    }

    // Common where clause
    console.log("in subcriberdetails",req.user.id,"")
    const where = { user_id: req.user.id, status: 'active' };
console.log("where",where);
    // Fetch lesson track and subscription in parallel
    const less= await DB.LessonTrack.findOne({ where });
    console.log("lesson search 1",less)
    const [lessontrack, subscriptions] = await Promise.all([
      DB.LessonTrack.findOne({ where }),
      DB.Subscriptions.findOne({ where })
    ]);
console.log("lessontrack",lessontrack)
    // Handle missing subscription
    if (!subscriptions) {
      return res.notFound({ error: "No active subscription found" });
    }

    // Fetch package only if subscription exists
    const packages = await DB.Packages.findOne({
      where: { subscription_type_id: subscriptions.subscription_type_id }
    });

    // Return consolidated data
    return res.ok({
      lessontrack,
      subscriptions,
      packages
    });

  } catch (err) {
    return res.serverError(err);
  }
});
router.post('/active_sessions', async (req, res) => {
    const { fingerprint, platform, ip_address, device, phone } = req.body;
    try {
        let userPhone = req.user?.phone || phone; // Ensure userPhone is defined
        // Check if a record already exists
        let existingActivity = await DB.UserActivity.findOne({
            where: { phone: userPhone, fingerprint }
        });
        if (existingActivity) {
            // Update existing row
            await existingActivity.update({
                platform,
                ip_address,
                device,
                status: 'active'
            });
        } else {
            // Insert new row if no existing record
            await DB.UserActivity.create({
                phone: userPhone,
                fingerprint,
                platform,
                ip_address,
                device,
                status: 'active'
            });
        }
        // Count active sessions for this user
        let sqltext = `
            SELECT COUNT(activity_id) AS active_sessions 
            FROM user_activity 
            WHERE phone = :userPhone AND status = 'active'
        `;
      let queryParams = {
            userPhone: userPhone
        }
        let records = await DB.rawQueryList(sqltext, queryParams);
        return res.status(200).json({ active_sessions: records[0]?.active_sessions || 0 });
    } catch (err) {
    //console.log(err)
        return res.status(500).json({ error: err.message });
    }
});
router.get('/getsubscribedvideodata', async (req, res) => {  
      try {
        // Call the Muse service to list collections
        const lesson_id=req.query.lesson_id;
        const phone=req.query.phone;
        let where = {'lesson_id': lesson_id,'phone':phone};
        //console.log("where",where)
            let record = await DB.SubscriberTracker.findOne({ where });
      return res.status(200).json({
                success: true,
                message: "Videos got successfully",
                data: record, // Assuming response.data contains the collections
            });
    } catch (err) {
        // Log the error and return a 500 response
        //console.error("Error fetching collections:", err);
        return res.status(500).json({
            success: false,
            message: "An error occurred while fetching collections",
            error: err.message || "Unknown error",
        });
    }
});
router.post('/updatesubscribertimeview', async (req, res) => {
  try {
    const {
      phone,
      lesson_id,
      watchStart,
      resumeTime,
      timeViewTime,
      lastTimeViewTime,
    } = req.body;
    //console.log('Request body:', req.body);
    // Validate required fields
    if (!lesson_id || !phone) {
      return res.status(400).json({
        error: 'Missing required fields: `lesson_id` or `phone`.',
      });
    }
    // Fetch the lesson settings for time limit
    const lessonRecord = await DB.LessonSetting.findOne({ where: { id: 2 } });
    const limitTime = lessonRecord.duration || 0; // Limit in minutes
    // Calculate the total time viewed
    const existingRecord = await DB.SubscriberTracker.findOne({ where: { phone, lesson_id:lesson_id } });
    const totalViewTime = (existingRecord?.timeviewtime*1 || 0) + timeViewTime*1;
    // Determine status
    //console.log("existingRecord",existingRecord.timeviewtime*1)
    //console.log("total,",totalViewTime);
    //console.log("limitTime",lessonRecord.duration)
    const status = totalViewTime >= limitTime * 60 ? 'expired' : 'active';
    // Update the record
    const sqlText = `
    UPDATE subscriber_tracker 
      SET 
        watchStart = :watchStart,
        resumeTime = :resumeTime,
        timeViewTime = :timeViewTime,
        status = :status
      WHERE 
        phone = :phone AND lesson_id = :lesson_id
    `;
    const queryParams = {
      watchStart: watchStart || null,
      resumeTime: lastTimeViewTime || null,
      timeViewTime: totalViewTime,
      status,
      phone,
      lesson_id,
    };
    const [results, metadata] = await DB.sequelize.query(sqlText, {
      replacements: queryParams,
      type: DB.sequelize.QueryTypes.UPDATE,
    });
    //console.log('Update result:', metadata);
    if (metadata > 0) {
      return res.status(200).json({
        message: 'Record updated successfully.',
        status,
        totalViewTime,
      });
    } else {
      return res.status(404).json({
        error: 'No record found to update.',
      });
    }
  } catch (err) {
    //console.error(err);
    return res.status(500).json({
      error: 'Internal Server Error',
      details: err.message,
    });
  }
});
router.post('/initiate_video_tracker', async (req, res) => {  
    try {
        const { lesson_id } = req.body;
        const user_id = req.user.id;
        // Check if the user already has a record for this lesson_id
        let where = { user_id, lesson_id };
        let record = await DB.SubscriberTracker.findOne({ where });
        let modeldata = {
            phone: req.user.phone,
            watchStart: null,
            resumeTime: "",
            timeViewTime: 0,
            status: 'active',
            lesson_id,
            user_id
        };
        if (!record) {
            // Create new record if not found
            await DB.SubscriberTracker.create(modeldata);
            // ✅ Only update TableModelName when creating a new record
            let userWhere = { user_id };
            let userData = {
                user_id,
                lessons_viewed: DB.sequelize.literal('lessons_viewed + 1'),
                lesson_balance: DB.sequelize.literal('lesson_balance - 1'),
                total_lessons: req.body.total_lessons,
                package_id: req.body.package_id,
                status: req.body.status
            };
            await DB.LessonTrack.update(userData, { where: userWhere });
        } else {
            // Update existing record in SubscriberTracker only
            await DB.SubscriberTracker.update(modeldata, { where });
        }
        return res.ok({ message: "Operation successful" });
    } catch (err) {
        return res.serverError(err);
    }
});
router.post('/updatepermissions', async (req, res) => {  
    const { actionpath, newValue, row } = req.body;
    //console.log("row", row);
    try {
        let where = { id: row.id };
        // Update role permissions using raw query
        let updateQuery = `
            UPDATE role_permissions 
            SET list = :list, edit = :edit, remove = :remove, view = :view 
            WHERE id = :id
        `;
        const [affectedRows] = await DB.sequelize.query(updateQuery, {
            replacements: {
                list: row.list,
                edit: row.edit,
                remove: row.remove,
                view: row.view,
                id: row.id
            }
        });
        if (affectedRows === 0) {
            return res.status(400).json({ success: false, message: 'No record updated' });
        }
        // If newValue is 0, remove the permission
        if (newValue === 0) {
            let deleteQuery = `DELETE FROM permissions WHERE permission = :permission`;
            await DB.sequelize.query(deleteQuery, { replacements: { permission: actionpath } });
            return res.json({ success: true, message: 'Permission removed' });
        }
        // Check if permission already exists
        let checkQuery = `
            SELECT * FROM permissions WHERE permission = :permission AND role_id = :role_id
        `;
        let [existingPermission] = await DB.sequelize.query(checkQuery, {
            replacements: { permission: actionpath, role_id: row.role_id }
        });
        if (existingPermission.length > 0) {
            return res.json({ success: false, message: 'Permission already exists' });
        }
        // Insert new permission
        let insertQuery = `
            INSERT INTO permissions (permission, role_id) VALUES (:permission, :role_id)
        `;
        let [newPermission] = await DB.sequelize.query(insertQuery, {
            replacements: { permission: actionpath, role_id: row.role_id }
        });
        return res.json({ success: true, created: newPermission });
    } catch (err) {
        //console.error('Error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
});
router.post('/sendsms', async (req, res) => {  
    try {
        const { email, phone, message } = req.body;
        if (phone) {
            // Call sendSms to send the SMS
            const smsResponse = await sendSms(phone, message);
            // //console.log("res sms",smsResponse)
            // Check if the SMS was sent successfully
            if (smsResponse.status && smsResponse.responseCode==="0200") {
                return res.status(200).json({ message: "SMS sent successfully" });
            } else {
                return res.status(500).json({ error: "Failed to send SMS" });
            }
        }
        // If no phone is provided, handle the email case or just return success
        return res.status(200).json({ message: "No phone number provided. Process completed." });
    } catch (err) {
        //console.error("Error occurred:", err);
        return res.status(500).json({ error: "An error occurred while processing the request" });
    }
});
router.post('/sendemail', async (req, res) => { 
    const { mailtitle, message, recipient, template, link,config } = req.body;
    try {
        let viewData = { message, link, config }; // Add `link` separately
        let mailbody = await ejs.renderFile(`views/pages/index/${template}.ejs`, viewData);
        let mailResult = await mailer.sendMail(recipient, mailtitle, mailbody);
        if (mailResult.messageId) {
            return res.status(200).send({ message: 'Email sent successfully' });
        } else {
            throw new Error(mailResult.error);
        }
    } catch (error) {
        return res.status(500).send({ error: error.message });
    }
});
router.post('/update_invite_status', async (req, res) => {  
    try{
        let where = {'id': req.body.id};
        let modeldata = {
            status: 'sent',
          }
        let newUser = await DB.Invites.update(modeldata, { where });
        return res.ok();
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.get('/getguide', async (req, res) => {  
    try{
        let sqltext = "SELECT * FROM user_guide ORDER BY id ASC";
        let queryParams = {
            param1: "value"
        }
        let records = await DB.rawQueryList(sqltext, queryParams);
        return res.ok(records);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.post('/getrights', async (req, res) => {  
    try {
        const sqltext = `
            SELECT 
    permissions.permission, 
    permissions.role_id,
    COALESCE(assign_rights.id, 0) AS id,
    CASE 
    WHEN assign_rights.id IS NULL THEN 0 
    ELSE 1 
    END AS has_right
FROM permissions 
LEFT JOIN assign_rights 
    ON permissions.permission = assign_rights.permission 
    AND permissions.user_id =:user_id
        `;
        const queryParams = { user_id: req.body.user_id };
        const records = await DB.rawQueryList(sqltext, queryParams);
        return res.json({ success: true, data: records });
    } catch (err) {
        //console.error("Database error:", err);
        return res.status(500).json({ success: false, error: err.message });
    }
});
router.post('/changeright', async (req, res) => {  
    const { user_id, has_right, permission, role_id } = req.body;
    try {
        if (has_right === 0) {
            // Delete only the specific user's permission
            await DB.Permissions.destroy({
                where: { user_id, permission, role_id }
            });
            return res.ok({ message: "Permission removed" });
        }
        // Create or update permission
        let modelData = { permission, user_id, role_id };
        let newUser = await DB.Permissions.create(modelData);
        return res.ok(newUser);
    } catch (err) {
        return res.serverError(err);
    }
});
router.get('/getferal', async (req, res) => {  
    try{
        let where = {'id': req.query.id};
        let record = await DB.Marketers.findOne({ where });
        return res.ok(record);
    }
    catch(err) {
        return res.serverError(err);
    }
});
router.post('/rightupdates', async (req, res) => {  
    const { action, user_id, role_id } = req.body;
    if (!user_id || !role_id) {
        return res.badRequest("Missing user_id or role_id");
    }
    try {
        if (action === 'revoke') {
            // Ensure role_id is passed
            let deleteSql = "DELETE FROM permissions WHERE user_id = :user_id AND role_id = :role_id";
            await DB.rawQueryList(deleteSql, { user_id, role_id });
        } else {
            // Insert all rights from assign_rights if they don’t exist
            let insertSql = `
                INSERT INTO permissions (user_id, role_id, permission)
                SELECT :user_id, :role_id, ar.permission
                FROM assign_rights ar
                WHERE NOT EXISTS (
                    SELECT 1 FROM permissions p 
                    WHERE p.user_id = :user_id 
                    AND p.role_id = :role_id 
                    AND p.permission = ar.permission
                )
            `;
            await DB.rawQueryList(insertSql, { user_id, role_id });
        }
        // Fetch updated permissions
        let sqltext = "SELECT permission_id, permission, role_id, user_id FROM permissions WHERE user_id = :user_id";
        let records = await DB.rawQueryList(sqltext, { user_id });
        return res.ok(records);
    } catch (err) {
        //console.error("Database Error:", err);
        return res.serverError(err.message);
    }
});
router.get('/get_weekend_tutorials', async (req, res) => {  
  try {
    const gradeId = req.query.grade_id; // Get gradeId from request query
    if (!gradeId) {
      return res.status(400).json({
        success: false,
        message: 'Missing grade_id parameter'
      });
    }
    // Fetch the grade name from the grades table
    const gradeQuery = `SELECT name FROM grades WHERE id = ?`;
    const gradeResult = await DB.rawQueryList(gradeQuery, [gradeId]);
    if (!gradeResult.length) {
      return res.status(404).json({
        success: false,
        message: 'Grade not found'
      });
    }
    // Get pagination parameters from query string
    const page = parseInt(req.query.page) || 1;
    const per_page = parseInt(req.query.per_page) || 10;
    const offset = (page - 1) * per_page;
    // Get current date in YYYY-MM-DD format
    const currentDate = new Date().toISOString().split('T')[0];
    const { count, rows } = await DB.Scheduler.findAndCountAll({
      where: { 
        [Op.and]: [
          { 
            status: {
              [Op.in]: ['active', 'upcoming'] // Filter by active/upcoming status
            }
          },
          { 
            end_date: { 
              [Op.gte]: currentDate // Only tutorials where end_date is >= today
            }
          },
          { 
            grade: gradeResult[0].name // Filter by grade name
          }
        ]
      },
      attributes: [
        'id', 
        'user_id', 
        'grade',
        'learning_area', 
        'strand', 
        'start_date', 
        'end_date', 
        'status',
        'link'
      ],
      limit: per_page,
      offset: offset,
      order: [['start_date', 'ASC']] // Order by start date ascending
    });
    return res.status(200).json({
      success: true,
      data: rows,
      total: count,
      page: page,
      per_page: per_page,
      total_pages: Math.ceil(count / per_page)
    });
  } catch (err) {
    //console.error('Error fetching tutorials:', err);
    return res.status(500).json({ 
      success: false, 
      message: 'Error fetching tutorials', 
      error: err.message 
    });
  }
});
router.post("/subscribetutorial", async (req, res) => {
    const { transaction_id, email, details_id, phone_number } = req.body;
    try {
        // Validate input
        if (!transaction_id || !details_id || !email || !phone_number) {
            return res.status(400).json({
                success: false,
                message: "Missing required parameters.",
            });
        }

        // Fetch the transaction details
        let transaction = await DB.Transactions.findOne({
            where: {
                id: transaction_id,
                status: "success",
                payment_status: "awaiting",
            },
        });

        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: "Transaction not found or already used.",
            });
        }

        // Update transaction status to "used"
        await DB.Transactions.update(
            { payment_status: "used" },
            { where: { id: transaction_id } }
        );

        // Calculate expiry date (End of this week)
        let expiry_date = moment().endOf("week").format("YYYY-MM-DD HH:mm:ss");

        // Get tutorial details to include subject and meet link in SMS
        let tutorial = await DB.Scheduler.findOne({
            where: { id: details_id },
            attributes: ['learning_area', 'start_date', 'link'] // Include meet link
        });

        if (!tutorial) {
            return res.status(404).json({
                success: false,
                message: "Tutorial details not found.",
            });
        }

        let tutorialSubject = tutorial.learning_area;
        let classStartTime = moment(tutorial.start_date).subtract(15, 'minutes').format("h:mm A");
        let meetLink = tutorial.link || 'http://bitstutorconnect.co.ke/weekendtutorials'; // Fallback to website if no meet link

        // Prepare data for the purchases table
        let purchaseData = {
            user_id: transaction.user_id,
            transaction_date: transaction.transactionDate,
            transaction_status: transaction.status,
            payment_reference: transaction.transaction_reference,
            amount_paid: transaction.amount,
            expiry_date: expiry_date,
            tutorial_id: details_id,
            phone: phone_number,
            email,
        };

        // Create a new purchase record
        let newPurchase = await DB.TutorialRegister.create(purchaseData);

        // Updated SMS message with actual Meet link
        const message = `Thank you for registering for your ${tutorialSubject} tutorial! Join class at ${classStartTime} (15min before start) via: ${meetLink}`;

        // Send SMS asynchronously
        sendSms(phone_number, message).catch((err) =>
            console.error("SMS sending failed:", err)
        );

        // Award commission to marketer if user was referred
        await awardCommission(transaction, transaction.user_id, 'tutorial');

        return res.status(200).json({
            success: true,
            message: "Registration successful.",
            data: newPurchase,
        });
    } catch (err) {
        //console.error("Error in transaction handling:", err);
        return res.status(500).json({
            success: false,
            message: "Internal server error.",
            error: err.message,
        });
    }
});
import { saveCredentials, loadSavedCredentials, authorize, createMeetEvent, getOAuthClient, exchangeCodeForTokens } from '../helpers/googleMeet.js';

// OAuth callback endpoint - GET method (Google redirects here)
router.get('/oauth2callback', async (req, res) => {
    try {
        const code = req.query.code;
        
        if (!code) {
            console.error('OAuth callback: No authorization code provided');
            return res.status(400).send(`
                <html>
                    <head><title>Authorization Failed</title></head>
                    <body style="font-family: Arial, sans-serif; padding: 40px; text-align: center;">
                        <h1 style="color: #d32f2f;">❌ Authorization Failed</h1>
                        <p>No authorization code was provided.</p>
                        <p>Please try the authorization process again.</p>
                    </body>
                </html>
            `);
        }
        
        console.log('OAuth callback: Received authorization code, exchanging for tokens...');
        
        // Exchange code for tokens using the helper function
        await exchangeCodeForTokens(code);
        
        console.log('OAuth callback: Authorization successful! Tokens saved to token.json');
        
        return res.send(`
            <html>
                <head>
                    <title>Authorization Successful</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 40px; text-align: center; }
                        .success { color: #4caf50; }
                        .info { background: #e3f2fd; padding: 20px; border-radius: 8px; margin: 20px auto; max-width: 600px; }
                    </style>
                </head>
                <body>
                    <h1 class="success">✅ Authorization Successful!</h1>
                    <div class="info">
                        <p><strong>Google Calendar has been authorized successfully.</strong></p>
                        <p>You can now close this window and try scheduling a class again.</p>
                        <p>The application will automatically use these credentials for creating Google Meet links.</p>
                    </div>
                    <script>
                        // Auto-close after 5 seconds
                        setTimeout(() => {
                            window.close();
                        }, 5000);
                    </script>
                </body>
            </html>
        `);
    } catch (error) {
        console.error('OAuth callback error:', error);
        return res.status(500).send(`
            <html>
                <head><title>Authorization Failed</title></head>
                <body style="font-family: Arial, sans-serif; padding: 40px; text-align: center;">
                    <h1 style="color: #d32f2f;">❌ Authorization Failed</h1>
                    <p><strong>Error:</strong> ${error.message}</p>
                    <p>Please try again or contact support if the problem persists.</p>
                    <details style="margin-top: 20px; text-align: left; max-width: 600px; margin-left: auto; margin-right: auto;">
                        <summary>Technical Details</summary>
                        <pre style="background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto;">${error.stack}</pre>
                    </details>
                </body>
            </html>
        `);
    }
});

// Legacy POST endpoint for backward compatibility
router.post('/oauthcallback', async (req, res) => {  
   const { code } = req.body;
  console.log('OAuth POST callback (legacy): Starting with code:', code ? 'received' : 'missing');
  try {
    const oauth2Client = await getOAuthClient();
    console.log('OAuth client created');
    const { tokens } = await oauth2Client.getToken(code);
    console.log('Tokens received:', {
       access_token: !!tokens.access_token,
       refresh_token: !!tokens.refresh_token
     });
    
    // Set credentials on the client before saving
    oauth2Client.setCredentials(tokens);
    await saveCredentials(oauth2Client);
    console.log('Credentials saved successfully');
    
    res.json({ success: true, message: 'Authorization successful' });
  } catch (error) {
    console.error('OAuth POST callback error:', error.stack);
    res.status(500).json({ 
      error: 'Failed to complete OAuth flow',
      details: process.env.NODE_ENV === 'development' ? error.message : null
    });
  }
});
router.get('/authenticate', async (req, res) => {  
   try {
    const authClient = await authorize();
    res.json({ success: true, message: 'Authenticated successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Error initiating OAuth', details: error.message });
  }
});
/*
router.get('/refresh', async (req, res) => {  
 try {
    const newTokens = await refreshAccessToken();
    res.json({ message: 'Access token refreshed successfully.', tokens: newTokens });
  } catch (error) {
    res.status(500).send(error.message);
  }
});*/
router.get('/meet_create', async (req, res) => {  
    try {
    const meetData = await createMeetEvent();
    res.json(meetData);
  } catch (error) {
    res.status(500).send(error.message);
  }
});
router.post('/verify_and_join_class', async (req, res) => { 
   const {tutorial_id,mobile_number}=req.body; 
    try {
        // Validate required parameters
        if (!tutorial_id || !mobile_number) {
            return res.status(400).json({
                success: false,
                message: 'Both tutorial_id and mobile_number are required'
            });
        }
        // Secure SQL query with parameterized values
        const sqlText = `
            SELECT COUNT(*) AS registration_count 
            FROM tutorial_register 
            WHERE tutorial_id = :tutorial_id 
            AND phone = :mobile_number
        `;
        const queryParams = {
            tutorial_id: tutorial_id,
            mobile_number: mobile_number
        };
        const result = await DB.rawQueryList(sqlText, queryParams);
        return res.status(200).json({
            success: true,
            isRegistered: result[0].registration_count > 0,
            count: result[0].registration_count
        });
    } catch (err) {
        //console.error('Error checking tutorial registration:', err);
        return res.status(500).json({
            success: false,
            message: 'Error checking registration status',
            error: err.message
        });
    }
});router.get('/check_weekend_tutorials', async (req, res) => {
    try {
        // Update expired records where the end_date has passed
        let updateExpiredSql = "UPDATE scheduler SET status = 'expired' WHERE end_date < NOW() AND status != 'expired'";
        await DB.rawQuery(updateExpiredSql, {});
        // Set status to 'active' if:
        // 1. The start time is within the next 1 hour
        // 2. The start time has passed but the end time has not passed yet
        let updateActiveSql = `
            UPDATE scheduler
            SET status = 'active'
            WHERE (start_date > NOW() AND start_date <= DATE_ADD(NOW(), INTERVAL 1 HOUR)) 
               OR (start_date <= NOW() AND end_date > NOW()) 
               AND status != 'expired'`;
        await DB.rawQuery(updateActiveSql, {});
        // Fetch updated records
        let sqltext = "SELECT id, user_id, grade_id, learning_area, strand, start_date, end_date, status, link, meetingId FROM scheduler";
        let records = await DB.rawQueryList(sqltext, {});
        return res.ok(records);
    } catch (err) {
        return res.serverError(err);
    }
});
router.get('/levelid_option_list', async (req, res) => {  
    try{
        let sqltext = `SELECT  DISTINCT level_id AS value,name AS label FROM learning_levels` ;
        let records = await DB.rawQueryList(sqltext);
        return res.ok(records);
    }
    catch(err){
        return res.serverError(err);
    }
});
router.get('/grades_by_level/:level_id', async (req, res) => {  
    try {
        const { level_id } = req.params; // Extract level_id from URL params
        if (!level_id) {
            return res.badRequest({ message: "level_id is required" });
        }
        let sqltext = `SELECT DISTINCT id AS value, name AS label, description AS caption FROM grades WHERE level_id = ?`;
        let records = await DB.rawQueryList(sqltext, [level_id]); // Pass parameter correctly
        return res.ok(records);
    } catch (err) {
        return res.serverError(err);
    }
});
router.get('/lessons_by_grade/:gradeid', async (req, res) => {  
    try {
        const { gradeid } = req.params;
        if (!gradeid) {
            return res.badRequest({ message: "gradeid is required" });
        }
        // Fetch the grade name from the grades table
        const gradeQuery = `SELECT name FROM grades WHERE id = ?`;
        const gradeResult = await DB.rawQueryList(gradeQuery, [gradeid]);
        if (!gradeResult || gradeResult.length === 0) {
            return res.notFound({ message: "Grade not found" });
        }
        const gradeName = gradeResult[0].name; // Extract the grade name
        // Fetch scheduler data based on the grade name
        const sqltext = `SELECT DISTINCT 
                            id AS value,
                            CONCAT(learning_area, ' - ', strand) AS label, 
                            status AS caption 
                         FROM Scheduler 
                         WHERE grade = ? and status !='expired'`;
        const records = await DB.rawQueryList(sqltext, [gradeName]);
        return res.ok(records);
    } catch (err) {
        return res.serverError(err);
    }
});
router.get('/get_purchased_tutorials', async (req, res) => {  
  const { phone } = req.query;
  try {
    if (!phone) {
      return res.status(400).json({
        success: false,
        message: 'Phone number is required'
      });
    }
    // Kenya time (UTC+3) handling
    const now = new Date();
    const kenyaOffset = 3 * 60 * 60 * 1000; // UTC+3 in milliseconds
    const kenyaTime = new Date(now.getTime() + kenyaOffset);
    const currentDate = kenyaTime.toISOString().split('T')[0];
    // Query for tutorials with proper join condition
    const tutorials = await DB.rawQueryList(`
      SELECT 
        tr.id,
        tr.transaction_date,
        tr.transaction_status,
        tr.amount_paid,
        tr.expiry_date,
        s.id AS tutorial_id,
        s.user_id,
        s.grade,
        s.learning_area,
        s.strand,
        s.start_date,
        s.end_date,
        s.status,
        s.link,
        s.meetingId
      FROM tutorial_register tr
      JOIN scheduler s ON tr.tutorial_id = s.id
      WHERE tr.phone = :phone
      AND s.status != 'expired'
      AND s.end_date >= :currentDate
      ORDER BY 
        CASE 
          WHEN s.status = 'active' THEN 1
          WHEN s.status = 'upcoming' THEN 2
          ELSE 3
        END,
        s.start_date ASC
    `, { 
      phone: phone,
      currentDate: currentDate
    });
    // Get tutorial IDs for question query
    const tutorialIds = tutorials.map(t => t.tutorial_id);
    // Query for questions - using scheduler_id which matches tutorial_id
    let questions = [];
    if (tutorialIds.length > 0) {
      questions = await DB.rawQueryList(`
        SELECT 
          question_id as id,
          question_text as text,
          status,
          created_at,
          scheduler_id as tutorial_id
        FROM questions
        WHERE scheduler_id IN (:tutorialIds)
        ORDER BY created_at DESC
      `, { tutorialIds });
    }
    // Format dates for Kenya time
    const formatDate = (date) => {
      if (!date) return null;
      const dateObj = new Date(date);
      return dateObj.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        timeZone: 'Africa/Nairobi'
      });
    };
    const formattedTutorials = tutorials.map(tutorial => ({
      ...tutorial,
      transaction_date: formatDate(tutorial.transaction_date),
      start_date: formatDate(tutorial.start_date),
      end_date: formatDate(tutorial.end_date),
      expiry_date: formatDate(tutorial.expiry_date)
    }));
    const formattedQuestions = questions.map(question => ({
      ...question,
      created_at: formatDate(question.created_at)
    }));
    res.json({
      success: true,
      tutorials: formattedTutorials,
      questions: formattedQuestions
    });
  } catch (err) {
    //console.error('Error fetching data:', {
    //   error: err.message,
    //   stack: err.stack,
    //   queryParams: req.query
    // });
    res.status(500).json({
      success: false,
      message: 'Error fetching data',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

router.get('/membershipexpire', async (req, res) => {
    try {
        // 0. Clean up non-standard values in expires_at fields.
        // Calculate expires_at from created_at + lesson_setting.duration (duration is in minutes).
        // The lesson_setting table defines duration in minutes for each subscription_type.
        try {
            await DB.rawQuery(`
                UPDATE lesson_track lt
                INNER JOIN lesson_setting ls ON ls.subscription_type =
                    CASE
                        WHEN EXISTS (SELECT 1 FROM subscriptions s WHERE s.id = lt.subscription_id AND s.status = 'active')
                        THEN 'subscribed'
                        ELSE 'non_subscribed'
                    END
                SET lt.expires_at = DATE_ADD(lt.created_at, INTERVAL CAST(ls.duration AS UNSIGNED) MINUTE)
                WHERE lt.expires_at IS NOT NULL
                  AND TRIM(CAST(lt.expires_at AS CHAR)) = ''
            `, {});
        } catch (updateErr) {
            // If the calculation fails, log the error but continue
            console.warn('Skipping expires_at calculation for lesson_track:', updateErr.message);
        }
        // 1. Update expired subscriptions
        await DB.rawQuery(`
            UPDATE subscriptions 
            SET status = 'expired' 
            WHERE expiry_date <= CURDATE() 
            AND status != 'expired'
        `, {});

        // 2. Update lesson_track status for expired purchases
        await DB.rawQuery(`
            UPDATE lesson_track lt
            SET lt.status = 'expired'
            WHERE 
                -- Condition 1: Lesson balance is 0
                lt.lesson_balance = 0
                -- Condition 2: Lesson track has its own expiry date and it's passed
                OR (lt.expires_at IS NOT NULL AND lt.expires_at <= CURDATE())
            AND lt.status != 'expired'
        `, {});

        // 3. Update lesson_track status for expired subscriptions separately
        await DB.rawQuery(`
            UPDATE lesson_track lt
            SET lt.status = 'expired'
            WHERE lt.subscription_id IN (
                SELECT id FROM subscriptions 
                WHERE expiry_date <= CURDATE() 
                AND status = 'expired'
            )
            AND lt.status != 'expired'
        `, {});

        // 4. Fetch all data with correct expiration statuses
        const [subscriptions, purchasesWithLessonTrack] = await Promise.all([
            // Get subscriptions
            DB.rawQueryList(`
                SELECT 
                    id, 
                    user_id, 
                    subscription_type_id, 
                    subscription_code, 
                    status,
                    start_date, 
                    expiry_date, 
                    transaction_id, 
                    phone_no 
                FROM subscriptions 
                WHERE 1
            `, {}),

            // Get purchases with lesson track info
            DB.rawQueryList(`
                SELECT 
                    p.id as purchase_id,
                    p.user_id,
                    p.package_id,
                    p.transaction_date,
                    p.transaction_status,
                    p.payment_reference,
                    p.amount_paid,
                    p.expiry_date,
                    lt.id as track_id,
                    lt.subscription_id,
                    lt.lessons_viewed,
                    lt.lesson_balance,
                    lt.total_lessons,
                    CASE 
                        WHEN p.expiry_date <= CURDATE() THEN 'expired'
                        ELSE lt.status
                    END as status
                FROM 
                    purchases p
                JOIN 
                    lesson_track lt ON p.user_id = lt.user_id AND p.package_id = lt.package_id
                WHERE 1
            `, {})
        ]);

        return res.ok({
            subscriptions,
            purchasesWithLessonTrack
        });
    }
    catch (err) {
        return res.serverError(err);
    }
});

/**
 * Route to get SMS balance from MobileSasa API
 * @GET /components_data/smsbalance
 */
router.get('/smsbalance', async (req, res) => {
    try {
        const balanceInfo = await getBalance();
        return res.ok({ balanceInfo });
    }
    catch (err) {
        console.error('Error fetching SMS balance:', err);
        return res.serverError(err);
    }
});

export default router;
