import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { checkAdminOrSuperadmin } from '../helpers/roleCheck';

const userPrivilegesCollection = db.collection('user_privileges');
const usersCollection = db.collection('users');

// Available privileges that can be granted to users
const AVAILABLE_PRIVILEGES = [
    'manage_users',
    'manage_roles',
    'manage_permissions',
    'manage_content',
    'view_analytics',
    'manage_subscriptions',
    'manage_settings',
    'manage_tutorials',
    'send_notifications',
    'export_data',
    'view_all_reports',
    'manage_guests',
    'manage_marketing',
    'view_revenue',
    'super_access',
    'debug'
];

/**
 * Get all privileges for a specific user
 * GET /api/userprivileges/user/:userId
 */
export const getUserPrivileges = async (req: Request, res: Response): Promise<void> => {
    try {
        const { userId } = req.params;
        const userIdNum = parseInt(userId);

        // Check if user exists
        const userSnapshot = await usersCollection.where('id', '==', userIdNum).get();
        if (userSnapshot.empty) {
            res.status(404).json({ message: 'User not found' });
            return;
        }

        // Get privileges
        const privilegesSnapshot = await userPrivilegesCollection
            .where('user_id', '==', userIdNum)
            .get();

        const privileges = privilegesSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            granted_at: doc.data().granted_at?.toDate?.() || doc.data().granted_at
        }));

        res.json(privileges);
    } catch (error) {
        console.error('Error getting user privileges:', error);
        res.status(500).json({ message: 'Error fetching privileges' });
    }
};

/**
 * Get list of available privileges
 * GET /api/userprivileges/available-privileges
 */
export const getAvailablePrivileges = async (req: Request, res: Response): Promise<void> => {
    try {
        res.ok(AVAILABLE_PRIVILEGES);
    } catch (error) {
        console.error('Error getting available privileges:', error);
        res.status(500).json({ message: 'Error fetching available privileges' });
    }
};

/**
 * Grant multiple privileges to a user
 * POST /api/userprivileges/grant-multiple
 */
export const grantMultiplePrivileges = async (req: Request, res: Response): Promise<void> => {
    try {
        const { user_id, privileges } = req.body;
        const userIdNum = parseInt(user_id);

        if (!user_id || !privileges || !Array.isArray(privileges)) {
            res.status(400).json({ message: 'user_id and privileges array are required' });
            return;
        }

        // Check if user exists
        const userSnapshot = await usersCollection.where('id', '==', userIdNum).get();
        if (userSnapshot.empty) {
            res.status(404).json({ message: 'User not found' });
            return;
        }

        // Get existing privileges to avoid duplicates
        const existingSnapshot = await userPrivilegesCollection
            .where('user_id', '==', userIdNum)
            .get();

        const existingPrivileges = existingSnapshot.docs.map(doc => doc.data().privilege);

        // Grant new privileges
        const newPrivileges = privileges.filter(p => !existingPrivileges.includes(p));
        const grantedAt = new Date();

        const batch = db.batch();

        for (const privilege of newPrivileges) {
            if (AVAILABLE_PRIVILEGES.includes(privilege)) {
                const docRef = userPrivilegesCollection.doc();
                batch.set(docRef, {
                    user_id: userIdNum,
                    privilege,
                    granted_at: grantedAt,
                    granted_by: req.body.granted_by || 'system',
                    created_at: grantedAt
                });
            }
        }

        await batch.commit();

        res.json({
            message: `Granted ${newPrivileges.length} privilege(s) successfully`,
            granted: newPrivileges
        });
    } catch (error) {
        console.error('Error granting privileges:', error);
        res.status(500).json({ message: 'Error granting privileges' });
    }
};

/**
 * Revoke a single privilege from a user
 * POST /api/userprivileges/revoke
 */
export const revokePrivilege = async (req: Request, res: Response): Promise<void> => {
    try {
        const { user_id, privilege } = req.body;

        if (!user_id || !privilege) {
            res.status(400).json({ message: 'user_id and privilege are required' });
            return;
        }

        // Find and delete the privilege
        const snapshot = await userPrivilegesCollection
            .where('user_id', '==', user_id)
            .where('privilege', '==', privilege)
            .limit(1)
            .get();

        if (snapshot.empty) {
            res.status(404).json({ message: 'Privilege not found' });
            return;
        }

        await snapshot.docs[0].ref.delete();

        res.json({ message: 'Privilege revoked successfully', privilege });
    } catch (error) {
        console.error('Error revoking privilege:', error);
        res.status(500).json({ message: 'Error revoking privilege' });
    }
};

/**
 * Revoke all privileges from a user
 * POST /api/userprivileges/revoke-all/:userId
 */
export const revokeAllPrivileges = async (req: Request, res: Response): Promise<void> => {
    try {
        const { userId } = req.params;
        const userIdNum = parseInt(userId);

        // Find all privileges for this user
        const snapshot = await userPrivilegesCollection
            .where('user_id', '==', userIdNum)
            .get();

        if (snapshot.empty) {
            res.status(404).json({ message: 'No privileges found for this user' });
            return;
        }

        // Delete all privileges
        const batch = db.batch();
        snapshot.docs.forEach(doc => {
            batch.delete(doc.ref);
        });

        await batch.commit();

        res.json({
            message: `Revoked ${snapshot.size} privilege(s) successfully`,
            revoked_count: snapshot.size
        });
    } catch (error) {
        console.error('Error revoking all privileges:', error);
        res.status(500).json({ message: 'Error revoking privileges' });
    }
};

/**
 * Check if a user has a specific privilege
 * GET /api/userprivileges/check/:userId/:privilege
 */
export const checkUserPrivilege = async (req: Request, res: Response): Promise<void> => {
    try {
        const { userId, privilege } = req.params;
        const userIdNum = parseInt(userId);

        const snapshot = await userPrivilegesCollection
            .where('user_id', '==', userIdNum)
            .where('privilege', '==', privilege)
            .limit(1)
            .get();

        res.json({
            has_privilege: !snapshot.empty,
            user_id: userIdNum,
            privilege
        });
    } catch (error) {
        console.error('Error checking privilege:', error);
        res.status(500).json({ message: 'Error checking privilege' });
    }
};

/**
 * List all user privileges (admin dashboard)
 * GET /api/userprivileges
 */
export const listAllUserPrivileges = async (req: Request, res: Response): Promise<void> => {
    try {
        const snapshot = await userPrivilegesCollection.get();

        const privileges = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            granted_at: doc.data().granted_at?.toDate?.() || doc.data().granted_at
        }));

        res.json({
            total: privileges.length,
            privileges
        });
    } catch (error) {
        console.error('Error listing privileges:', error);
        res.status(500).json({ message: 'Error fetching privileges' });
    }
};
