import { Router } from 'express';
import { body } from 'express-validator';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list scheduler records
 * @GET /scheduler/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		const joinTables = []; // hold list of join tables
		joinTables.push({
			model: DB.Users,
			required: false,
			as: 'users',
			attributes: [], //already set via model class
		})
		query.include = joinTables;
		let search = req.query.search;
		if(search){
			let searchFields = DB.Scheduler.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Scheduler.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Scheduler.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Scheduler record
 * @GET /scheduler/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		const joinTables = []; // hold list of join tables
		joinTables.push({
			model: DB.Users,
			required: false,
			as: 'users',
			attributes: [], //already set via model class
		})
		query.include = joinTables;
		where[DB.op.and] = DB.raw('scheduler.id = :recid');
		query.replacements = {
			recid
		}
		query.raw = true;
		query.where = where;
		query.attributes = DB.Scheduler.viewFields();
		let record = await DB.Scheduler.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Scheduler record
 * @POST /scheduler/add
 */
router.post('/add/', 
	[
		body('user_id').optional({nullable: true, checkFalsy: true}),
		body('grade').optional({nullable: true, checkFalsy: true}),
		body('learning_area').optional({nullable: true, checkFalsy: true}),
		body('strand').optional({nullable: true, checkFalsy: true}),
		body('start_date').optional({nullable: true, checkFalsy: true}),
		body('end_date').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('link').optional({nullable: true, checkFalsy: true}),
		body('meetingid').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		await beforeAdd(modeldata, req);
		
		//save Scheduler record
		let record = await DB.Scheduler.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});
import { createMeetEvent } from '../helpers/googleMeet.js';
async function beforeAdd(postdata, req) {
    try {
        console.log("Postdata:", postdata); // Debugging log
        const hostemail = req.user.email || "nzukipk@gmail.com";
        const summary = `${postdata.grade} ${postdata.learning_area} ${postdata.strand || ""}`.trim();
        const description = `Lesson on ${postdata.learning_area} for grade ${postdata.grade}`;

        // Convert local time to UTC
        const localTimeZone = 'Africa/Nairobi';
        const startTime = new Date(`${postdata.start_date}:00`).toISOString();
        const endTime = new Date(`${postdata.end_date}:00`).toISOString();

        console.log(`Creating Meet event: ${summary}, Start: ${startTime}, End: ${endTime}`);

        const meetData = await createMeetEvent({
            summary,
            description,
            startTime,
            endTime,
            timeZone: localTimeZone,
            hostemail
        });

        // Use the correct property names from the API response
        console.log("meta",meetData)
        postdata.link = meetData.meetingUrl; 
        postdata.meetingid = meetData.eventId;     
       
        console.log(`Google Meet created: ${postdata.link} (ID: ${postdata.meetingid})`);
       
        return postdata;
    } catch (error) {
        console.error("Error creating Google Meet:", error);
        throw new Error(`Failed to create Google Meet: ${error.message}`);
    }
}

/**
 * Route to get  Scheduler record for edit
 * @GET /scheduler/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Scheduler.editFields();
		let record = await DB.Scheduler.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Scheduler record
 * @POST /scheduler/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('user_id').optional({nullable: true, checkFalsy: true}),
		body('grade').optional({nullable: true, checkFalsy: true}),
		body('learning_area').optional({nullable: true, checkFalsy: true}),
		body('strand').optional({nullable: true, checkFalsy: true}),
		body('start_date').optional({nullable: true, checkFalsy: true}),
		body('end_date').optional({nullable: true, checkFalsy: true}),
		body('status').optional({nullable: true, checkFalsy: true}),
		body('link').optional({nullable: true, checkFalsy: true}),
		body('meetingid').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Scheduler.editFields();
		let record = await DB.Scheduler.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Scheduler.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Scheduler record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /scheduler/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Scheduler.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Scheduler.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to list scheduler records
 * @GET /scheduler/index/{fieldname}/{fieldvalue}
 */
router.get('/teachersscheduler/:fieldname?/:fieldvalue?', async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Scheduler.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		where['user_id'] = req.user.id;
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Scheduler.teachersschedulerFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Scheduler.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});
export default router;
