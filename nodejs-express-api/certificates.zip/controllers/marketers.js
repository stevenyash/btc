import { Router } from 'express';
import { body } from 'express-validator';
import utils from '../helpers/utils.js';
import validateFormData from '../helpers/validate_form.js';
import DB from '../models/db.js';


const router = Router();




/**
 * Route to list marketers records
 * @GET /marketers/index/{fieldname}/{fieldvalue}
 */
router.get(['/', '/index/:fieldname?/:fieldvalue?'], async (req, res) => {  
	try{
		const query = {};
		let queryFilters = [];
		let where = {};
		let replacements = {};
		let fieldName = req.params.fieldname;
		let fieldValue = req.params.fieldvalue;
		
		if (fieldName){
			queryFilters.push(DB.filterBy(fieldName, fieldValue));
		}
		let search = req.query.search;
		if(search){
			let searchFields = DB.Marketers.searchFields();
			where[DB.op.or] = searchFields;
			replacements.search = `%${search}%`;
		}
		
		if(queryFilters.length){
			where[DB.op.and] = queryFilters;
		}
		query.raw = true;
		query.where = where;
		query.replacements = replacements;
		query.order = DB.getOrderBy(req, 'id', 'desc');
		query.attributes = DB.Marketers.listFields();
		let page = parseInt(req.query.page) || 1;
		let limit = parseInt(req.query.limit) || 10;
		let result = await DB.Marketers.paginate(query, page, limit);
		return res.ok(result);
	}
	catch(err) {
		return res.serverError(err);
	}
});


/**
 * Route to view Marketers record
 * @GET /marketers/view/{recid}
 */
router.get('/view/:recid', async (req, res) => {
	try{
		const recid = req.params.recid || null;
		const query = {}
		const where = {}
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Marketers.viewFields();
		let record = await DB.Marketers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to insert Marketers record
 * @POST /marketers/add
 */
router.post('/add/', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('email').not().isEmpty().isEmail(),
		body('phone').not().isEmpty(),
		body('referral_code').optional({nullable: true, checkFalsy: true}),
		body('points').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async function (req, res) {
	try{
		let modeldata = req.getValidFormData();
		
		// check if email already exist.
		let emailCount = await DB.Marketers.count({ where:{ 'email': modeldata.email } });
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		
		// check if phone already exist.
		let phoneCount = await DB.Marketers.count({ where:{ 'phone': modeldata.phone } });
		if(phoneCount > 0){
			return res.badRequest(`${modeldata.phone} already exist.`);
		}
		await beforeAdd(modeldata, req);
		
		//save Marketers record
		let record = await DB.Marketers.create(modeldata);
		//await record.reload(); //reload the record from database
		const recid =  record['id'];
		await afterAdd(record, req);
		
		return res.ok(record);
	} catch(err){
		return res.serverError(err);
	}
});
/**
* Before create new record
* @param {object} postdata // validated form data used to create new record
*/
import crypto from "crypto";
async function beforeAdd(postdata, req) {
    // Extract email and phone from postdata
    const { email, phone } = postdata;
    if (!email || !phone) {
        throw new Error("Email and phone number are required to generate referral code.");
    }
    // Generate referral_code
    const hash = crypto.createHash('md5').update(email + phone).digest('hex');
    const referral_code = `REF${Date.now()}_${hash.substring(0, 8)}`;
    // Add the referral_code to postdata before saving
    postdata.referral_code = referral_code;
}
/**
* After new record created
* @param {object} record // newly created record
*/
async function afterAdd(record, req){
    //enter statement here
    let where = {'role_name': "marketer"};
    let role= await DB.Roles.findOne({ where });
    let modeldata = {
        username: record.phone,
        email: record.email,
        password:utils.passwordHash(record.phone),
        status:'active',
        user_role_id:role.role_id,
        }
        let newUser = await DB.Users.create(modeldata);
}


/**
 * Route to get  Marketers record for edit
 * @GET /marketers/edit/{recid}
 */
router.get('/edit/:recid', async (req, res) => {
	try{
		const recid = req.params.recid;
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Marketers.editFields();
		let record = await DB.Marketers.findOne(query);
		if(!record){
			return res.notFound();
		}
		return res.ok(record);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to update  Marketers record
 * @POST /marketers/edit/{recid}
 */
router.post('/edit/:recid', 
	[
		body('name').optional({nullable: true, checkFalsy: true}),
		body('email').optional({nullable: true}).not().isEmpty().isEmail(),
		body('phone').optional({nullable: true}).not().isEmpty(),
		body('referral_code').optional({nullable: true, checkFalsy: true}),
		body('points').optional({nullable: true, checkFalsy: true}),
	], validateFormData
, async (req, res) => {
	try{
		const recid = req.params.recid;
		let modeldata = req.getValidFormData({ includeOptionals: true });
		
		// check if email already exist.
		let emailCount = await DB.Marketers.count({where:{'email': modeldata.email, 'id': {[DB.op.ne]: recid} }});
		if(emailCount > 0){
			return res.badRequest(`${modeldata.email} already exist.`);
		}
		
		// check if phone already exist.
		let phoneCount = await DB.Marketers.count({where:{'phone': modeldata.phone, 'id': {[DB.op.ne]: recid} }});
		if(phoneCount > 0){
			return res.badRequest(`${modeldata.phone} already exist.`);
		}
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		query.attributes = DB.Marketers.editFields();
		let record = await DB.Marketers.findOne(query);
		if(!record){
			return res.notFound();
		}
		await DB.Marketers.update(modeldata, {where: where});
		return res.ok(modeldata);
	}
	catch(err){
		return res.serverError(err);
	}
});


/**
 * Route to delete Marketers record by table primary key
 * Multi delete supported by recid separated by comma(,)
 * @GET /marketers/delete/{recid}
 */
router.get('/delete/:recid', async (req, res) => {
	try{
		const recid = (req.params.recid || '').split(',');
		const query = {};
		const where = {};
		where['id'] = recid;
		query.raw = true;
		query.where = where;
		let records = await DB.Marketers.findAll(query);
		records.forEach(async (record) => { 
			//perform action on each record before delete
		});
		await DB.Marketers.destroy(query);
		return res.ok(recid);
	}
	catch(err){
		return res.serverError(err);
	}
});
export default router;
