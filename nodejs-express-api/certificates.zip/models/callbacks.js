
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Callbacks extends BaseModel {
	static init() {
		return super.init(
			{
				
				callback_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				transaction_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				merchant_request_id: { type:Sequelize.STRING   },
				checkout_request_id: { type:Sequelize.STRING   },
				result_code: { type:Sequelize.STRING   },
				result_description: { type:Sequelize.STRING   },
				mpesa_receipt_number: { type:Sequelize.STRING   },
				amount: { type:Sequelize.NUMBER   },
				transaction_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				phone_number: { type:Sequelize.STRING   },
				created_at: { type:Sequelize.DATE , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "callbacks",
				modelName: "callbacks",
			}
		);
	}
	
	static listFields() {
		return [
			'callback_id', 
			'transaction_id', 
			'merchant_request_id', 
			'checkout_request_id', 
			'result_code', 
			'result_description', 
			'mpesa_receipt_number', 
			'amount', 
			'transaction_date', 
			'phone_number', 
			'created_at'
		];
	}

	static viewFields() {
		return [
			'callback_id', 
			'transaction_id', 
			'merchant_request_id', 
			'checkout_request_id', 
			'result_code', 
			'result_description', 
			'mpesa_receipt_number', 
			'amount', 
			'transaction_date', 
			'phone_number', 
			'created_at'
		];
	}

	static editFields() {
		return [
			'callback_id', 
			'transaction_id', 
			'merchant_request_id', 
			'checkout_request_id', 
			'result_code', 
			'result_description', 
			'mpesa_receipt_number', 
			'amount', 
			'transaction_date', 
			'phone_number'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("callback_id LIKE :search"), 
			Sequelize.literal("merchant_request_id LIKE :search"), 
			Sequelize.literal("checkout_request_id LIKE :search"), 
			Sequelize.literal("result_code LIKE :search"), 
			Sequelize.literal("result_description LIKE :search"), 
			Sequelize.literal("mpesa_receipt_number LIKE :search"), 
			Sequelize.literal("phone_number LIKE :search"),
		];
	}

	
	
}
Callbacks.init();
export default Callbacks;
