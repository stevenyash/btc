import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Invites extends BaseModel {
  static init() {
    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        user_id: { type: Sequelize.STRING },
        invitee_email: { type: Sequelize.STRING },
        invitee_phone: { type: Sequelize.STRING },
        status: { type: Sequelize.STRING },
        referral_code: { type: Sequelize.STRING },
        invitee_join_date: { type: Sequelize.DATE, allowNull: true },
      },
      {
        sequelize,
        tableName: "invites",
        modelName: "invites",
      }
    );
  }

  static listFields() {
    return [
      "id",
      "user_id",
      "invitee_email",
      "invitee_phone",
      "status",
      "referral_code",
      "invitee_join_date",
    ];
  }

  static viewFields() {
    return [
      "id",
      "user_id",
      "invitee_email",
      "invitee_phone",
      "status",
      "referral_code",
      "invitee_join_date",
    ];
  }

  static editFields() {
    return [
      "invitee_email",
      "invitee_phone",
      "referral_code",
      "invitee_join_date", // Include if this is editable
      "id",
    ];
  }

  static searchFields() {
    return [
      Sequelize.literal("id LIKE :search"),
      Sequelize.literal("user_id LIKE :search"),
      Sequelize.literal("invitee_email LIKE :search"),
      Sequelize.literal("invitee_phone LIKE :search"),
      Sequelize.literal("status LIKE :search"),
      Sequelize.literal("referral_code LIKE :search"),
    ];
  }
}

Invites.init();

export default Invites;
