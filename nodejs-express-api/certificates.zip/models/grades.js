// models/Grades.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Grades extends BaseModel {
    static init() {
        return super.init(
            {
                id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
                name: { type: Sequelize.STRING },
                description: { type: Sequelize.STRING },
                level_id: { type: Sequelize.INTEGER },
                sort_order: { type: Sequelize.INTEGER, defaultValue: 0 },
                is_active: { type: Sequelize.BOOLEAN, defaultValue: true }
            },
            {
                sequelize,
                tableName: "grades",
                modelName: "grades",
            }
        );
    }

    static listFields() {
        return [
            'id',
            'name',
            'description',
            'level_id',
            'sort_order',
            'is_active'
        ];
    }

    static viewFields() {
        return [
            'id',
            'name',
            'description',
            'level_id',
            'sort_order',
            'is_active'
        ];
    }

    static editFields() {
        return [
            'id',
            'name',
            'description',
            'level_id',
            'sort_order',
            'is_active'
        ];
    }

    static searchFields() {
        return [
            Sequelize.literal("id LIKE :search"),
            Sequelize.literal("name LIKE :search"),
            Sequelize.literal("description LIKE :search"),
        ];
    }

    // Define associations
    static associate(models) {
        this.belongsTo(models.LearningLevels, {
            foreignKey: 'level_id',
            as: 'level'
        });
        
        this.hasMany(models.LearningAreas, {
            foreignKey: 'grade',
            as: 'learning_areas'
        });
    }
}

Grades.init();
export default Grades;