
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class ReferralLogs extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				marketer_id: { type:Sequelize.INTEGER   },
				referred_user_email: { type:Sequelize.STRING   },
				status: { type:Sequelize.ENUM('CLICKED','SIGNED_UP')   },
				created_at: { type:Sequelize.DATE , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "referral_logs",
				modelName: "referral_logs",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'marketer_id', 
			'referred_user_email', 
			'status', 
			'created_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'marketer_id', 
			'referred_user_email', 
			'status', 
			'created_at'
		];
	}

	static editFields() {
		return [
			'id', 
			'marketer_id', 
			'referred_user_email', 
			'status'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("referred_user_email LIKE :search"),
		];
	}

	
	
}
ReferralLogs.init();
export default ReferralLogs;
