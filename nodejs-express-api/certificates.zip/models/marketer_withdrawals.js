import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class MarketerWithdrawals extends BaseModel {

  static init() {

    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        marketer_id: { type: Sequelize.INTEGER, allowNull: false },
        amount: { type: Sequelize.DECIMAL(12, 2), allowNull: false },
        phone_number: { type: Sequelize.STRING(20), allowNull: false },
        source: { type: Sequelize.ENUM('commission', 'points', 'both'), defaultValue: 'both' },
        status: { type: Sequelize.ENUM('pending', 'processing', 'completed', 'failed'), defaultValue: 'pending' },
        mpesa_receipt: { type: Sequelize.STRING(50), allowNull: true },
        mpesa_conversation_id: { type: Sequelize.STRING(100), allowNull: true },
        mpesa_originator_conversation_id: { type: Sequelize.STRING(100), allowNull: true },
        remarks: { type: Sequelize.TEXT, allowNull: true },
        created_at: { type: Sequelize.DATE, defaultValue: Sequelize.NOW },
        processed_at: { type: Sequelize.DATE, allowNull: true },
      },
      {
        sequelize,
        tableName: "marketer_withdrawals",
        modelName: "marketer_withdrawals",
        timestamps: false,
      }
    );
  }

  static listFields() {
    return [
      'id', 'marketer_id', 'amount', 'phone_number', 'source',
      'status', 'mpesa_receipt', 'remarks', 'created_at', 'processed_at'
    ];
  }

  static viewFields() {
    return [
      'id', 'marketer_id', 'amount', 'phone_number', 'source',
      'status', 'mpesa_receipt', 'mpesa_conversation_id',
      'mpesa_originator_conversation_id', 'remarks', 'created_at', 'processed_at'
    ];
  }

  static editFields() {
    return [
      'id', 'marketer_id', 'amount', 'phone_number', 'source',
      'status', 'mpesa_receipt', 'remarks'
    ];
  }

  static searchFields() {
    return [
      Sequelize.literal("id LIKE :search"),
      Sequelize.literal("phone_number LIKE :search"),
      Sequelize.literal("status LIKE :search"),
      Sequelize.literal("mpesa_receipt LIKE :search"),
    ];
  }
}

MarketerWithdrawals.init();

export default MarketerWithdrawals;
