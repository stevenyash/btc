
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionsRenewal extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true },
				username: { type:Sequelize.STRING   },
				phone: { type:Sequelize.STRING   },
				subscription_code: { type:Sequelize.STRING   },
				expiry_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "subscriptions_renewal",
				modelName: "subscriptions_renewal",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'username', 
			'phone', 
			'subscription_code', 
			'expiry_date'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("username LIKE :search"), 
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("subscription_code LIKE :search"),
		];
	}

	
	
}
SubscriptionsRenewal.init();
export default SubscriptionsRenewal;
