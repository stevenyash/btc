
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class UserGuide extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				title: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				icon: { type:Sequelize.STRING   },
				content: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				created_at: { type:Sequelize.DATE   }
			}, 
			{ 
				sequelize,
				
				tableName: "user_guide",
				modelName: "user_guide",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'title', 
			'icon', 
			'content', 
			'created_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'title', 
			'icon', 
			'content', 
			'created_at'
		];
	}

	static editFields() {
		return [
			'title', 
			'icon', 
			'content', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("title LIKE :search"), 
			Sequelize.literal("icon LIKE :search"), 
			Sequelize.literal("content LIKE :search"),
		];
	}

	
	
}
UserGuide.init();
export default UserGuide;
