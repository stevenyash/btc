
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class MonthlySubscriptionSummary extends BaseModel {
	static init() {
		return super.init(
			{
				
				month: { type: Sequelize.STRING, primaryKey: true },
				total_subscriptions: { type:Sequelize.STRING , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "monthly_subscription_summary",
				modelName: "monthly_subscription_summary",
			}
		);
	}
	
	static listFields() {
		return [
			'month', 
			'total_subscriptions'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("month LIKE :search"),
		];
	}

	
	
}
MonthlySubscriptionSummary.init();
export default MonthlySubscriptionSummary;
