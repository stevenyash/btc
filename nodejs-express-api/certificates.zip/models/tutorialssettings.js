
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class TutorialsSettings extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				fee: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "tutorials_settings",
				modelName: "tutorials_settings",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'fee'
		];
	}

	static viewFields() {
		return [
			'id', 
			'fee'
		];
	}

	static editFields() {
		return [
			'fee', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("fee LIKE :search"),
		];
	}

	
	
}
TutorialsSettings.init();
export default TutorialsSettings;
