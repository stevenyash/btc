
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LessonSetting extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				fee: { type:Sequelize.STRING   },
				duration: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				subscription_type: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "lesson_setting",
				modelName: "lesson_setting",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'fee', 
			'duration', 
			'subscription_type'
		];
	}

	static viewFields() {
		return [
			'id', 
			'fee', 
			'duration', 
			'subscription_type'
		];
	}

	static editFields() {
		return [
			'fee', 
			'duration', 
			'subscription_type', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("fee LIKE :search"), 
			Sequelize.literal("duration LIKE :search"), 
			Sequelize.literal("subscription_type LIKE :search"),
		];
	}

	
	
}
LessonSetting.init();
export default LessonSetting;
