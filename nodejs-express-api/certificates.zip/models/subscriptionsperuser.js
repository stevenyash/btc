
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionsPerUser extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true },
				username: { type:Sequelize.STRING   },
				phone: { type:Sequelize.STRING   },
				email: { type:Sequelize.STRING   },
				total_subscriptions: { type:Sequelize.STRING , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "subscriptions_per_user",
				modelName: "subscriptions_per_user",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'username', 
			'phone', 
			'email', 
			'total_subscriptions'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("username LIKE :search"), 
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("email LIKE :search"),
		];
	}

	
	
}
SubscriptionsPerUser.init();
export default SubscriptionsPerUser;
