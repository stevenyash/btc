
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Scheduler extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type:Sequelize.STRING   },
				grade: { type:Sequelize.STRING   },
				learning_area: { type:Sequelize.STRING   },
				strand: { type:Sequelize.STRING   },
				start_date: { type:Sequelize.STRING   },
				end_date: { type:Sequelize.STRING   },
				status: { type:Sequelize.STRING   },
				link: { type:Sequelize.STRING   },
				meetingid: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "scheduler",
				modelName: "scheduler",
			}
		);
	}
	
	static listFields() {
		return [
			Sequelize.literal('scheduler.id AS id'), 
			Sequelize.literal("users.username AS users_username"), 
			Sequelize.literal("users.phone AS users_phone"), 
			Sequelize.literal("users.email AS users_email"), 
			Sequelize.literal('scheduler.grade AS grade'), 
			Sequelize.literal('scheduler.learning_area AS learning_area'), 
			Sequelize.literal('scheduler.strand AS strand'), 
			Sequelize.literal('scheduler.start_date AS start_date'), 
			Sequelize.literal('scheduler.end_date AS end_date'), 
			Sequelize.literal('scheduler.status AS status'), 
			Sequelize.literal('scheduler.link AS link'), 
			Sequelize.literal("users.id AS users_id")
		];
	}

	static viewFields() {
		return [
			Sequelize.literal('scheduler.id AS id'), 
			Sequelize.literal('scheduler.user_id AS user_id'), 
			Sequelize.literal('scheduler.grade AS grade'), 
			Sequelize.literal('scheduler.learning_area AS learning_area'), 
			Sequelize.literal('scheduler.strand AS strand'), 
			Sequelize.literal('scheduler.start_date AS start_date'), 
			Sequelize.literal('scheduler.end_date AS end_date'), 
			Sequelize.literal('scheduler.status AS status'), 
			Sequelize.literal('scheduler.link AS link'), 
			Sequelize.literal('scheduler.meetingId AS meetingid'), 
			Sequelize.literal("users.id AS users_id"), 
			Sequelize.literal("users.username AS users_username"), 
			Sequelize.literal("users.image AS users_image"), 
			Sequelize.literal("users.phone AS users_phone"), 
			Sequelize.literal("users.email AS users_email"), 
			Sequelize.literal("users.account_status AS users_account_status"), 
			Sequelize.literal("users.user_role_id AS users_user_role_id"), 
			Sequelize.literal("users.nhif AS users_nhif"), 
			Sequelize.literal("users.nssf AS users_nssf"), 
			Sequelize.literal("users.national_id AS users_national_id"), 
			Sequelize.literal("users.subscription_code AS users_subscription_code"), 
			Sequelize.literal("users.status AS users_status"), 
			Sequelize.literal("users.referred_by AS users_referred_by")
		];
	}

	static editFields() {
		return [
			'user_id', 
			'grade', 
			'learning_area', 
			'strand', 
			'start_date', 
			'end_date', 
			'status', 
			'link', 
			Sequelize.literal('meetingId AS meetingid'), 
			'id'
		];
	}

	static teachersschedulerFields() {
		return [
			'id', 
			'grade', 
			'learning_area', 
			'strand', 
			'start_date', 
			'end_date', 
			'status', 
			'link'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("scheduler.id LIKE :search"), 
			Sequelize.literal("users.username LIKE :search"), 
			Sequelize.literal("users.phone LIKE :search"), 
			Sequelize.literal("users.email LIKE :search"), 
			Sequelize.literal("scheduler.grade LIKE :search"), 
			Sequelize.literal("scheduler.learning_area LIKE :search"), 
			Sequelize.literal("scheduler.strand LIKE :search"), 
			Sequelize.literal("scheduler.start_date LIKE :search"), 
			Sequelize.literal("scheduler.end_date LIKE :search"), 
			Sequelize.literal("scheduler.status LIKE :search"), 
			Sequelize.literal("scheduler.link LIKE :search"), 
			Sequelize.literal("scheduler.meetingId LIKE :search"), 
			Sequelize.literal("users.id LIKE :search"), 
			Sequelize.literal("users.account_status LIKE :search"), 
			Sequelize.literal("users.nhif LIKE :search"), 
			Sequelize.literal("users.nssf LIKE :search"), 
			Sequelize.literal("users.national_id LIKE :search"), 
			Sequelize.literal("users.subscription_code LIKE :search"), 
			Sequelize.literal("users.referred_by LIKE :search"), 
			Sequelize.literal("scheduler.user_id LIKE :search"), 
			Sequelize.literal("users.password LIKE :search"),
		];
	}

	
	
}
Scheduler.init();
export default Scheduler;
