// models/lesson_track.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LessonTrack extends BaseModel {
	static init() {
		return super.init(
			{
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				subscription_id: { type: Sequelize.INTEGER, allowNull: false },
				user_id: { type: Sequelize.INTEGER, allowNull: false },
				lessons_viewed: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				lesson_balance: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				total_lessons: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				package_id: { type: Sequelize.INTEGER, allowNull: false },
				status: { 
					type: Sequelize.ENUM('active', 'expired', 'exhausted', 'cancelled'), 
					allowNull: false, 
					defaultValue: 'active' 
				},
				last_accessed: { type: Sequelize.DATE, allowNull: true },
				
				expires_at: { type: Sequelize.DATE, allowNull: true }
			}, 
			{
				sequelize,
				tableName: "lesson_track",
				modelName: "lesson_track",
				timestamps: true,
				createdAt: 'created_at',
				updatedAt: 'updated_at',
				indexes: [
					{
						unique: true,
						fields: ['user_id', 'subscription_id']
					}
				]
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'subscription_id', 
			'user_id', 
			'lessons_viewed', 
			'lesson_balance', 
			'total_lessons', 
			'package_id', 
			'status', 
			'last_accessed',
			'expires_at',
			'created_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'subscription_id', 
			'user_id', 
			'lessons_viewed', 
			'lesson_balance', 
			'total_lessons', 
			'package_id', 
			'status', 
			'last_accessed', 
		
			'expires_at',
			'created_at',
			'updated_at'
		];
	}

	static editFields() {
		return [
			'subscription_id', 
			'user_id', 
			'lessons_viewed', 
			'lesson_balance', 
			'total_lessons', 
			'package_id', 
			'status', 
			'last_accessed', 
			
			'expires_at',
			'id'
		];
	}

	static searchFields(){
		return [
			Sequelize.literal("user_id LIKE :search"), 
			Sequelize.literal("status LIKE :search"), 
			Sequelize.literal("subscription_id LIKE :search")
		];
	}

	static associate(models) {
		this.belongsTo(models.Users, {
			foreignKey: 'user_id',
			as: 'user'
		});
		this.belongsTo(models.Subscriptions, {
			foreignKey: 'subscription_id',
			as: 'subscription'
		});
		this.belongsTo(models.Packages, {
			foreignKey: 'package_id',
			as: 'package'
		});
		this.hasMany(models.LessonAccessLogs, {
			foreignKey: 'lesson_track_id',
			as: 'access_logs'
		});
	}
}

LessonTrack.init();
export default LessonTrack;