import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SystemSettings extends BaseModel {

  static init() {

    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        setting_key: { type: Sequelize.STRING(100), allowNull: false, unique: true },
        setting_value: { type: Sequelize.STRING(500), allowNull: false },
        description: { type: Sequelize.TEXT, allowNull: true },
        updated_at: { type: Sequelize.DATE, defaultValue: Sequelize.NOW },
      },
      {
        sequelize,
        tableName: "system_settings",
        modelName: "system_settings",
        timestamps: false,
      }
    );
  }

  static listFields() {
    return ['id', 'setting_key', 'setting_value', 'description', 'updated_at'];
  }

  static viewFields() {
    return ['id', 'setting_key', 'setting_value', 'description', 'updated_at'];
  }

  static editFields() {
    return ['id', 'setting_key', 'setting_value', 'description'];
  }

  static searchFields() {
    return [
      Sequelize.literal("setting_key LIKE :search"),
      Sequelize.literal("setting_value LIKE :search"),
      Sequelize.literal("description LIKE :search"),
    ];
  }

  static async getSetting(key, defaultValue = null) {
    const record = await this.findOne({ where: { setting_key: key } });
    return record ? record.setting_value : defaultValue;
  }
}

SystemSettings.init();

export default SystemSettings;
