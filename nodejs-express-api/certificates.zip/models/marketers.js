import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Marketers extends BaseModel {
  static init() {
    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        name: { type: Sequelize.STRING },
        email: { type: Sequelize.STRING },
        phone: { type: Sequelize.STRING },
        referral_code: { type: Sequelize.STRING },
        points: { type: Sequelize.INTEGER },

        join_date: { type: Sequelize.DATE, allowNull: true },

        commission_rate: { type: Sequelize.DECIMAL(5, 4), defaultValue: 0.10 },

        total_earnings: { type: Sequelize.DECIMAL(12, 2), defaultValue: 0.00 },

        pending_earnings: { type: Sequelize.DECIMAL(12, 2), defaultValue: 0.00 },

        withdrawn_earnings: { type: Sequelize.DECIMAL(12, 2), defaultValue: 0.00 },

        redeemed_points: { type: Sequelize.INTEGER, defaultValue: 0 },

      },
      {
        sequelize,
        tableName: "marketers",
        modelName: "marketers",
      }
    );
  }

  static listFields() {

    return [

      "id",

      "name",

      "email",

      "phone",

      "referral_code",

      "points",

      "join_date",

      "commission_rate",

      "total_earnings",

      "pending_earnings",

      "withdrawn_earnings",

      "redeemed_points",

    ];

  }

  static viewFields() {

    return [

      "id",

      "name",

      "email",

      "phone",

      "referral_code",

      "points",

      "join_date",

      "commission_rate",

      "total_earnings",

      "pending_earnings",

      "withdrawn_earnings",

      "redeemed_points",

    ];

  }

  static editFields() {

    return [

      "name",

      "email",

      "phone",

      "referral_code",

      "points",

      "join_date",

      "commission_rate",

      "total_earnings",

      "pending_earnings",

      "withdrawn_earnings",

      "redeemed_points",

      "id",

    ];

  }

  static searchFields() {
    return [
      Sequelize.literal("id LIKE :search"),
      Sequelize.literal("name LIKE :search"),
      Sequelize.literal("email LIKE :search"),
      Sequelize.literal("phone LIKE :search"),
      Sequelize.literal("referral_code LIKE :search"),
    ];
  }
}

Marketers.init();

export default Marketers;
