
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Questions extends BaseModel {
	static init() {
		return super.init(
			{
				
				question_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				question_text: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				status: { type:Sequelize.ENUM('unanswered','answered')   },
				created_at: { type:Sequelize.DATE , allowNull: false  },
				scheduler_id: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "questions",
				modelName: "questions",
			}
		);
	}
	
	static listFields() {
		return [
			'question_text', 
			'status', 
			'question_id'
		];
	}

	static viewFields() {
		return [
			'question_id', 
			'question_text', 
			'status', 
			'created_at', 
			'scheduler_id'
		];
	}

	static editFields() {
		return [
			'question_text', 
			'status', 
			'scheduler_id', 
			'question_id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("question_text LIKE :search"), 
			Sequelize.literal("question_id LIKE :search"), 
			Sequelize.literal("scheduler_id LIKE :search"),
		];
	}

	
	
}
Questions.init();
export default Questions;
