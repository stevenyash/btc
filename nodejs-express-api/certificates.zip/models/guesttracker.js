// models/guest_tracker.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class GuestTracker extends BaseModel {
	static init() {
		return super.init(
			{
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				phone: { type: Sequelize.STRING, allowNull: false },
				fingerPrint: { type: Sequelize.STRING, allowNull: true },
				watchStart: { type: Sequelize.DATE, allowNull: true },
				resumeTime: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				timeViewTime: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				status: { 
					type: Sequelize.ENUM('active', 'inactive', 'expired', 'completed'), 
					allowNull: false, 
					defaultValue: 'active' 
				},
				lesson_id: { type: Sequelize.INTEGER, allowNull: false },
				transaction_id: { type: Sequelize.STRING, allowNull: true },
				views_count: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				last_accessed: { type: Sequelize.DATE, allowNull: true },
				expires_at: { type: Sequelize.DATE, allowNull: true }
			}, 
			{
				sequelize,
				tableName: "guest_tracker",
				modelName: "guest_tracker",
				timestamps: true,
				createdAt: 'created_at',
				updatedAt: 'updated_at',
				indexes: [
					{
						unique: true,
						fields: ['phone', 'lesson_id']
					}
				]
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'phone', 
			'lesson_id', 
			'status', 
			'views_count', 
			'last_accessed', 
			'expires_at',
			'created_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'phone', 
			'fingerPrint', 
			'watchStart', 
			'resumeTime', 
			'timeViewTime', 
			'status', 
			'lesson_id', 
			'transaction_id', 
			'views_count', 
			'last_accessed', 
			'expires_at',
			'created_at',
			'updated_at'
		];
	}

	static editFields() {
		return [
			'phone', 
			'fingerPrint', 
			'watchStart', 
			'resumeTime', 
			'timeViewTime', 
			'status', 
			'lesson_id', 
			'transaction_id', 
			'views_count', 
			'last_accessed', 
			'expires_at',
			'id'
		];
	}

	static searchFields(){
		return [
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("transaction_id LIKE :search"), 
			Sequelize.literal("status LIKE :search")
		];
	}

	static associate(models) {
		this.belongsTo(models.Lessons, {
			foreignKey: 'lesson_id',
			as: 'lesson'
		});
		this.hasMany(models.LessonAccessLogs, {
			foreignKey: 'guest_tracker_id',
			as: 'access_logs'
		});
	}
}

GuestTracker.init();
export default GuestTracker;