
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Packages extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				description: { type:Sequelize.STRING   },
				created_at: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				subscription_type_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				concurrent_access: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				no_of_lessons: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				duration_amount: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				duration_unit: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				fee: { type:Sequelize.NUMBER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "packages",
				modelName: "packages",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'subscription_type_id', 
			'name', 
			'description', 
			'concurrent_access', 
			'no_of_lessons', 
			'duration_amount', 
			'duration_unit', 
			'created_at', 
			'fee'
		];
	}

	static viewFields() {
		return [
			'id', 
			'subscription_type_id', 
			'name', 
			'description', 
			'concurrent_access', 
			'created_at', 
			'no_of_lessons', 
			'duration_amount', 
			'duration_unit', 
			'fee'
		];
	}

	static editFields() {
		return [
			'subscription_type_id', 
			'name', 
			'description', 
			'fee', 
			'concurrent_access', 
			'no_of_lessons', 
			'duration_amount', 
			'duration_unit', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("name LIKE :search"), 
			Sequelize.literal("description LIKE :search"), 
			Sequelize.literal("duration_unit LIKE :search"),
		];
	}

	
	
}
Packages.init();
export default Packages;
