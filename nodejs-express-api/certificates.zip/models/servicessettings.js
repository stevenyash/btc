
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class ServicesSettings extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				level: { type:Sequelize.STRING   },
				title: { type:Sequelize.STRING   },
				description: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "services_settings",
				modelName: "services_settings",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'level', 
			'title', 
			'description'
		];
	}

	static viewFields() {
		return [
			'id', 
			'level', 
			'title', 
			'description'
		];
	}

	static editFields() {
		return [
			'level', 
			'title', 
			'description', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("level LIKE :search"), 
			Sequelize.literal("title LIKE :search"), 
			Sequelize.literal("description LIKE :search"),
		];
	}

	
	
}
ServicesSettings.init();
export default ServicesSettings;
