// models/lesson_access_logs.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LessonAccessLogs extends BaseModel {
	static init() {
		return super.init(
			{
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type: Sequelize.INTEGER, allowNull: true },
				phone: { type: Sequelize.STRING, allowNull: true },
				lesson_id: { type: Sequelize.INTEGER, allowNull: false },
				access_type: { 
					type: Sequelize.ENUM('guest', 'subscriber', 'subscriber_resumed', 'preview'), 
					allowNull: false 
				},
				ip_address: { type: Sequelize.STRING, allowNull: true },
				user_agent: { type: Sequelize.TEXT, allowNull: true },
				session_id: { type: Sequelize.STRING, allowNull: false },
				expires_at: { type: Sequelize.DATE, allowNull: false },
				accessed_at: { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.NOW },
				completed_at: { type: Sequelize.DATE, allowNull: true },
				watch_time: { type: Sequelize.INTEGER, allowNull: true, defaultValue: 0 },
				completion_percentage: { type: Sequelize.DECIMAL(5,2), allowNull: true, defaultValue: 0.00 },
				guest_tracker_id: { type: Sequelize.INTEGER, allowNull: true },
				lesson_track_id: { type: Sequelize.INTEGER, allowNull: true },
				lesson_setting_id: { type: Sequelize.INTEGER, allowNull: true },
				status: { 
					type: Sequelize.ENUM('active', 'completed', 'expired', 'cancelled'), 
					allowNull: false, 
					defaultValue: 'active' 
				}
			}, 
			{
				sequelize,
				tableName: "lesson_access_logs",
				modelName: "lesson_access_logs",
				timestamps: true,
				createdAt: 'created_at',
				updatedAt: 'updated_at'
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'user_id', 
			'phone', 
			'lesson_id', 
			'access_type', 
			'ip_address', 
			'session_id', 
			'expires_at', 
			'accessed_at',
			'status',
			'created_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'user_id', 
			'phone', 
			'lesson_id', 
			'access_type', 
			'ip_address', 
			'user_agent', 
			'session_id', 
			'expires_at', 
			'accessed_at',
			'completed_at',
			'watch_time',
			'completion_percentage',
			'guest_tracker_id', 
			'lesson_track_id',
			'lesson_setting_id',
			'status',
			'created_at',
			'updated_at'
		];
	}

	static editFields() {
		return [
			'user_id', 
			'phone', 
			'lesson_id', 
			'access_type', 
			'ip_address', 
			'user_agent', 
			'session_id', 
			'expires_at', 
			'accessed_at',
			'completed_at',
			'watch_time',
			'completion_percentage',
			'guest_tracker_id', 
			'lesson_track_id',
			'lesson_setting_id',
			'status',
			'id'
		];
	}

	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("user_id LIKE :search"), 
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("lesson_id LIKE :search"), 
			Sequelize.literal("access_type LIKE :search"), 
			Sequelize.literal("ip_address LIKE :search"), 
			Sequelize.literal("session_id LIKE :search")
		];
	}

	static associate(models) {
		this.belongsTo(models.Users, {
			foreignKey: 'user_id',
			as: 'user'
		});
		this.belongsTo(models.Lessons, {
			foreignKey: 'lesson_id',
			as: 'lesson'
		});
		this.belongsTo(models.GuestTracker, {
			foreignKey: 'guest_tracker_id',
			as: 'guest_tracker'
		});
		this.belongsTo(models.LessonTrack, {
			foreignKey: 'lesson_track_id',
			as: 'lesson_track'
		});
		this.belongsTo(models.LessonSetting, {
			foreignKey: 'lesson_setting_id',
			as: 'lesson_setting'
		});
	}
}

LessonAccessLogs.init();
export default LessonAccessLogs;