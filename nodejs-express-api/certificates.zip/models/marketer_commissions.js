import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class MarketerCommissions extends BaseModel {

  static init() {

    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        marketer_id: { type: Sequelize.INTEGER, allowNull: false },
        user_id: { type: Sequelize.INTEGER, allowNull: false },
        transaction_id: { type: Sequelize.INTEGER },
        purchase_type: { type: Sequelize.ENUM('subscription', 'package', 'tutorial'), allowNull: false },
        purchase_amount: { type: Sequelize.DECIMAL(12, 2), allowNull: false },
        commission_rate: { type: Sequelize.DECIMAL(5, 4), allowNull: false },
        commission_amount: { type: Sequelize.DECIMAL(12, 2), allowNull: false },
        status: { type: Sequelize.ENUM('pending', 'approved', 'paid'), defaultValue: 'approved' },
        created_at: { type: Sequelize.DATE, defaultValue: Sequelize.NOW },
      },
      {
        sequelize,
        tableName: "marketer_commissions",
        modelName: "marketer_commissions",
        timestamps: false,
      }
    );
  }

  static listFields() {
    return [
      'id', 'marketer_id', 'user_id', 'transaction_id',
      'purchase_type', 'purchase_amount', 'commission_rate',
      'commission_amount', 'status', 'created_at'
    ];
  }

  static viewFields() {
    return [
      'id', 'marketer_id', 'user_id', 'transaction_id',
      'purchase_type', 'purchase_amount', 'commission_rate',
      'commission_amount', 'status', 'created_at'
    ];
  }

  static editFields() {
    return [
      'id', 'marketer_id', 'user_id', 'transaction_id',
      'purchase_type', 'purchase_amount', 'commission_rate',
      'commission_amount', 'status'
    ];
  }

  static searchFields() {
    return [
      Sequelize.literal("id LIKE :search"),
      Sequelize.literal("purchase_type LIKE :search"),
      Sequelize.literal("status LIKE :search"),
    ];
  }
}

MarketerCommissions.init();

export default MarketerCommissions;
