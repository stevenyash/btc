import { BaseModel, sequelize, Sequelize } from "./basemodel.js";



class RolePermissions extends BaseModel {

	static init() {
		return super.init(

			{

				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },

				list: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				edit: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				remove: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				view: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				role_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				page: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				store: { type:Sequelize.INTEGER   }

			}, 

			{ 

				sequelize,

				tableName: "role_permissions",

				modelName: "role_permissions",

				indexes: [
					{
						name: 'unique_role_page',
						unique: true,
						fields: ['role_id', 'page']
					}
				]

			}

		);
	}

	

	static listFields() {

		return [

			Sequelize.literal('role_permissions.id AS id'), 

			Sequelize.literal("roles.role_name AS roles_role_name"), 

			Sequelize.literal('role_permissions.page AS page'), 

			Sequelize.literal('role_permissions.list AS list'), 

			Sequelize.literal('role_permissions.store AS store'), 

			Sequelize.literal('role_permissions.edit AS edit'), 

			Sequelize.literal('role_permissions.remove AS remove'), 

			Sequelize.literal('role_permissions.view AS view'), 

			Sequelize.literal('role_permissions.role_id AS role_id'), 

			Sequelize.literal("roles.role_id AS roles_role_id")

		];

	}



	static viewFields() {

		return [

			Sequelize.literal('role_permissions.id AS id'), 

			Sequelize.literal('role_permissions.list AS list'), 

			Sequelize.literal('role_permissions.edit AS edit'), 

			Sequelize.literal('role_permissions.remove AS remove'), 

			Sequelize.literal('role_permissions.view AS view'), 

			Sequelize.literal('role_permissions.role_id AS role_id'), 

			Sequelize.literal('role_permissions.page AS page'), 

			Sequelize.literal("roles.role_id AS roles_role_id"), 

			Sequelize.literal("roles.role_name AS roles_role_name"), 

			Sequelize.literal('role_permissions.store AS store')

		];

	}



	static editFields() {

		return [

			'list', 

			'edit', 

			'remove', 

			'view', 

			'page', 

			'role_id', 

			'store', 

			'id'

		];

	}



	static searchFields(){

		return [

			Sequelize.literal("role_permissions.id LIKE :search"), 

			Sequelize.literal("roles.role_name LIKE :search"), 

			Sequelize.literal("role_permissions.page LIKE :search"), 

			Sequelize.literal("roles.role_id LIKE :search"),

		];

	}



}



RolePermissions.init();

export default RolePermissions;
