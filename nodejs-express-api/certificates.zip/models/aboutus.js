
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class AboutUs extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				section: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				content: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "about_us",
				modelName: "about_us",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'section', 
			'content'
		];
	}

	static viewFields() {
		return [
			'id', 
			'section', 
			'content'
		];
	}

	static editFields() {
		return [
			'id', 
			'section', 
			'content'
		];
	}

	static aboutussettingFields() {
		return [
			'id', 
			'section', 
			'content'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("section LIKE :search"), 
			Sequelize.literal("content LIKE :search"),
		];
	}

	
	
}
AboutUs.init();
export default AboutUs;
