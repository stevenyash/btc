// models/lessons.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Lessons extends BaseModel {
    static init() {
        return super.init(
            {
                id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
                area_id: { type: Sequelize.INTEGER },
                topic_id: { type: Sequelize.INTEGER },
                subtopic_id: { type: Sequelize.INTEGER }, 
                title: { type: Sequelize.STRING },
                description: { type: Sequelize.TEXT },
                s3_key: { type: Sequelize.STRING },
                s3_url: { type: Sequelize.STRING },
                file:{ type: Sequelize.STRING },
                filename:{type:Sequelize.STRING},
                file_size: { type: Sequelize.BIGINT },
                duration: { type: Sequelize.INTEGER, defaultValue: 0 },
                thumbnail_url: { type: Sequelize.STRING },
                primary_thumbnail: { type: Sequelize.STRING },
                price: { type: Sequelize.DECIMAL(10, 2), defaultValue: 0.00 },
                is_preview_available: { type: Sequelize.BOOLEAN, defaultValue: false },
                preview_duration: { type: Sequelize.INTEGER, defaultValue: 0 },
                sort_order: { type: Sequelize.INTEGER, defaultValue: 0 },
                is_active: { type: Sequelize.BOOLEAN, defaultValue: true }
            },
            {
                sequelize,
                tableName: "lessons",
                modelName: "lessons",
            }
        );
    }

    static listFields() {
        return [
            'id',
            'area_id',
            'topic_id',
            'subtopic_id',            
            'title',
            'description',
            's3_key',
            's3_url',
             'file',
             'filename',
            'file_size',
            'duration',
            'thumbnail_url',
            'primary_thumbnail',
            'price',
            'is_preview_available',
            'preview_duration',
            'sort_order',
            'is_active'
        ];
    }

    static viewFields() {
        return [
            'id',
            'area_id',
            'topic_id',
            'subtopic_id',
            'title',
            'description',
            's3_key',
            's3_url',
             'file',
             'filename',
            'file_size',            
            'duration',
            'thumbnail_url',
            'primary_thumbnail',
            'price',
            'is_preview_available',
            'preview_duration',
            'sort_order',
            'is_active'
        ];
    }
    

    static editFields() {
        return [
            'id',
            'area_id',
            'topic_id',
            'subtopic_id',
            'title',
            'description',
            's3_key',
            's3_url',
            'file_size',
             'file',
             'filename',
            'duration',
            'thumbnail_url',
            'primary_thumbnail',
            'price',
            'is_preview_available',
            'preview_duration',
            'sort_order',
            'is_active'
        ];
    }

    static searchFields() {
        return [
            Sequelize.literal("id LIKE :search"),
            Sequelize.literal("title LIKE :search"),
            Sequelize.literal("description LIKE :search"),
        ];
    }

   
}

Lessons.init();
export default Lessons;