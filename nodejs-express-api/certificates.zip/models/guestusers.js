
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class GuestUsers extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				guest_id: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				ip_address: { type:Sequelize.STRING   },
				user_agent: { type:Sequelize.STRING   },
				fingerprint: { type:Sequelize.STRING   },
				is_active: { type:Sequelize.STRING   },
				created_at: { type:Sequelize.DATE   },
				updated_at: { type:Sequelize.DATE   },
				platiform: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "guest_users",
				modelName: "guest_users",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'guest_id', 
			'ip_address', 
			'user_agent', 
			'fingerprint', 
			'is_active', 
			'created_at', 
			'updated_at', 
			'platiform'
		];
	}

	static viewFields() {
		return [
			'id', 
			'guest_id', 
			'ip_address', 
			'user_agent', 
			'fingerprint', 
			'is_active', 
			'created_at', 
			'updated_at', 
			'platiform'
		];
	}

	static editFields() {
		return [
			'guest_id', 
			'ip_address', 
			'user_agent', 
			'fingerprint', 
			'is_active', 
			'id', 
			'platiform'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("guest_id LIKE :search"), 
			Sequelize.literal("ip_address LIKE :search"), 
			Sequelize.literal("user_agent LIKE :search"), 
			Sequelize.literal("fingerprint LIKE :search"), 
			Sequelize.literal("platiform LIKE :search"),
		];
	}

	
	
}
GuestUsers.init();
export default GuestUsers;
