
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionType extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				type: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "subscription_type",
				modelName: "subscription_type",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'type'
		];
	}

	static viewFields() {
		return [
			'id', 
			'type'
		];
	}

	static editFields() {
		return [
			'id', 
			'type'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("type LIKE :search"),
		];
	}

	
	
}
SubscriptionType.init();
export default SubscriptionType;
