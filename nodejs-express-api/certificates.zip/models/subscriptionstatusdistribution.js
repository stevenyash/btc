
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionStatusDistribution extends BaseModel {
	static init() {
		return super.init(
			{
				
				status: { type: Sequelize.STRING, primaryKey: true },
				total: { type:Sequelize.STRING , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "subscription_status_distribution",
				modelName: "subscription_status_distribution",
			}
		);
	}
	
	static listFields() {
		return [
			'status', 
			'total'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("status LIKE :search"),
		];
	}

	
	
}
SubscriptionStatusDistribution.init();
export default SubscriptionStatusDistribution;
