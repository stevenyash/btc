
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionTypes extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				description: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				membership_fee: { type:Sequelize.NUMBER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				created_at: { type:Sequelize.DATE , allowNull: false  },
				months: { type:Sequelize.STRING , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "subscription_types",
				modelName: "subscription_types",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'name', 
			'description', 
			'membership_fee', 
			'created_at', 
			'months'
		];
	}

	static viewFields() {
		return [
			'id', 
			'name', 
			'description', 
			'membership_fee', 
			'created_at', 
			'months'
		];
	}

	static editFields() {
		return [
			'name', 
			'description', 
			'membership_fee', 
			'id', 
			'months'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("name LIKE :search"), 
			Sequelize.literal("description LIKE :search"), 
			Sequelize.literal("months LIKE :search"),
		];
	}

	
	
}
SubscriptionTypes.init();
export default SubscriptionTypes;
