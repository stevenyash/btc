// models/LearningLevels.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LearningLevels extends BaseModel {
    static init() {
        return super.init(
            {
                level_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
                name: { type: Sequelize.STRING },
                description: { type: Sequelize.TEXT },
                sort_order: { type: Sequelize.INTEGER, defaultValue: 0 },
                is_active: { type: Sequelize.BOOLEAN, defaultValue: true }
            },
            {
                sequelize,
                tableName: "learning_levels",
                modelName: "learning_levels",
            }
        );
    }

    static listFields() {
        return [
            'level_id',
            'name',
            'description',
            'sort_order',
            'is_active'
        ];
    }

    static viewFields() {
        return [
            'level_id',
            'name',
            'description',
            'sort_order',
            'is_active'
        ];
    }

    static editFields() {
        return [
            'level_id',
            'name',
            'description',
            'sort_order',
            'is_active'
        ];
    }

    static searchFields() {
        return [
            Sequelize.literal("name LIKE :search"),
            Sequelize.literal("description LIKE :search"),
        ];
    }
}

LearningLevels.init();
export default LearningLevels;