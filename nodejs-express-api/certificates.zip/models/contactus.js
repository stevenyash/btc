
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class ContactUs extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				type: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				detail: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "contact_us",
				modelName: "contact_us",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'type', 
			'detail'
		];
	}

	static viewFields() {
		return [
			'id', 
			'type', 
			'detail'
		];
	}

	static editFields() {
		return [
			'id', 
			'type', 
			'detail'
		];
	}

	static contactuseditFields() {
		return [
			'id', 
			'type', 
			'detail'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("type LIKE :search"), 
			Sequelize.literal("detail LIKE :search"),
		];
	}

	
	
}
ContactUs.init();
export default ContactUs;
