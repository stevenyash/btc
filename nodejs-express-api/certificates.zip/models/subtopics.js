

import { BaseModel, sequelize, Sequelize } from "./basemodel.js";



class Subtopics extends BaseModel {

	static init() {

		return super.init(

			{

				

				subtopic_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },

				topic_id: { type:Sequelize.INTEGER   },

				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }

			}, 

			{ 

				sequelize,

				

				tableName: "subtopics",

				modelName: "subtopics",

			}

		);

	}

	

	static listFields() {

		return [

			'subtopic_id', 

			'topic_id', 

			'name'

		];

	}



	static viewFields() {

		return [

			'subtopic_id', 

			'topic_id', 

			'name'

		];

	}



	static editFields() {

		return [

			'subtopic_id', 

			'topic_id', 

			'name'

		];

	}



	

	static searchFields(){

		return [

			Sequelize.literal("subtopic_id LIKE :search"), 

			Sequelize.literal("name LIKE :search"),

		];

	}



	

	

}

Subtopics.init();

export default Subtopics;

