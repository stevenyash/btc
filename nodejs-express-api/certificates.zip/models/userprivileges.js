import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

/**
 * UserPrivileges Model
 * 
 * This table stores user-specific privileges that override or extend the default role privileges.
 * When a Super Admin grants additional privileges to a user, those are stored here.
 * The user's role remains unchanged, but they gain additional capabilities.
 */

class UserPrivileges extends BaseModel {

	static init() {
		return super.init(
			{
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				
				user_id: { type: Sequelize.INTEGER, allowNull: false },
				
				privilege: { type: Sequelize.STRING, allowNull: false },
				
				granted_by: { type: Sequelize.INTEGER, allowNull: false },
				
				granted_at: { type: Sequelize.DATE, defaultValue: Sequelize.literal('CURRENT_TIMESTAMP') },
				
				is_active: { type: Sequelize.BOOLEAN, defaultValue: true },
				
				expires_at: { type: Sequelize.DATE, allowNull: true }
			}, 
			{ 
				sequelize,
				tableName: "user_privileges",
				modelName: "user_privileges",
				indexes: [
					{
						name: 'unique_user_privilege',
						unique: true,
						fields: ['user_id', 'privilege']
					}
				]
			}
		);
	}

	static listFields() {
		return [
			'id',
			'user_id',
			'privilege',
			'granted_by',
			'granted_at',
			'is_active',
			'expires_at'
		];
	}

	static viewFields() {
		return [
			'id',
			'user_id',
			'privilege',
			'granted_by',
			'granted_at',
			'is_active',
			'expires_at'
		];
	}

	static editFields() {
		return [
			'user_id',
			'privilege',
			'is_active',
			'expires_at',
			'id'
		];
	}

	static searchFields(){
		return [
			Sequelize.literal("user_privileges.id LIKE :search"), 
			Sequelize.literal("user_privileges.privilege LIKE :search"),
		];
	}
}

UserPrivileges.init();

export default UserPrivileges;
