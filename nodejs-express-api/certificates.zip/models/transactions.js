
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Transactions extends BaseModel {
	static init() {
		return super.init(
			{
				
				user_id: { type:Sequelize.INTEGER   },
				phone_number: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				amount: { type:Sequelize.NUMBER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_reference: { type:Sequelize.STRING   },
				checkout_request_id: { type:Sequelize.STRING   },
				status: { type:Sequelize.STRING   },
				description: { type:Sequelize.STRING   },
				response_code: { type:Sequelize.STRING   },
				response_description: { type:Sequelize.STRING   },
				created_at: { type:Sequelize.DATE   },
				updated_at: { type:Sequelize.DATE   },
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				transactiondate: { type:Sequelize.STRING   },
				payment_status: { type:Sequelize.STRING , allowNull: false  },
				details_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "transactions",
				modelName: "transactions",
			}
		);
	}
	
	static listFields() {
		return [
			'user_id', 
			'phone_number', 
			'amount', 
			'transaction_reference', 
			'checkout_request_id', 
			'status', 
			'description', 
			'response_code', 
			'response_description', 
			'created_at', 
			'updated_at', 
			'id', 
			Sequelize.literal('transactionDate AS transactiondate'), 
			'payment_status', 
			'details_id'
		];
	}

	static viewFields() {
		return [
			'user_id', 
			'phone_number', 
			'amount', 
			'transaction_reference', 
			'checkout_request_id', 
			'status', 
			'description', 
			'response_code', 
			'response_description', 
			'created_at', 
			'updated_at', 
			'id', 
			Sequelize.literal('transactionDate AS transactiondate'), 
			'payment_status', 
			'details_id'
		];
	}

	static editFields() {
		return [
			'user_id', 
			'phone_number', 
			'amount', 
			'transaction_reference', 
			'checkout_request_id', 
			'status', 
			'description', 
			'response_code', 
			'response_description', 
			Sequelize.literal('transactionDate AS transactiondate'), 
			'id', 
			'payment_status', 
			'details_id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("phone_number LIKE :search"), 
			Sequelize.literal("transaction_reference LIKE :search"), 
			Sequelize.literal("checkout_request_id LIKE :search"), 
			Sequelize.literal("description LIKE :search"), 
			Sequelize.literal("response_code LIKE :search"), 
			Sequelize.literal("response_description LIKE :search"), 
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("transactionDate LIKE :search"), 
			Sequelize.literal("payment_status LIKE :search"),
		];
	}

	
	
}
Transactions.init();
export default Transactions;
