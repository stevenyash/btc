

import { BaseModel, sequelize, Sequelize } from "./basemodel.js";



class SubscriberTracker extends BaseModel {

	static init() {

		return super.init(

			{

			

				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },

				phone: { type:Sequelize.STRING   },

				fingerprint: { type:Sequelize.STRING   },

				resumetime: { type:Sequelize.STRING   },

				timeviewtime: { type:Sequelize.STRING   },

				status: { type:Sequelize.STRING   },

				lesson_id: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				transaction_id: { type:Sequelize.STRING   },

				user_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },

				watchstart: { type:Sequelize.STRING   }

			},

			{ 

				sequelize,

				

				tableName: "subscriber_tracker",

				modelName: "subscriber_tracker",

			}

		);

	}

	

	static listFields() {

		return [

			'id', 

			'phone', 

			Sequelize.literal('fingerPrint AS fingerprint'), 

			Sequelize.literal('resumeTime AS resumetime'), 

			Sequelize.literal('timeViewTime AS timeviewtime'), 

			'status', 

			'lesson_id', 

			'transaction_id', 

			'user_id', 

			Sequelize.literal('watchStart AS watchstart')

		];

	}



	static viewFields() {

		return [

			'id', 

			'phone', 

			Sequelize.literal('fingerPrint AS fingerprint'), 

			Sequelize.literal('resumeTime AS resumetime'), 

			Sequelize.literal('timeViewTime AS timeviewtime'), 

			'status', 

			'lesson_id', 

			'transaction_id', 

			'user_id', 

			Sequelize.literal('watchStart AS watchstart')

		];

	}



	static editFields() {

		return [

			'id', 

			'phone', 

			Sequelize.literal('fingerPrint AS fingerprint'), 

			Sequelize.literal('resumeTime AS resumetime'), 

			Sequelize.literal('timeViewTime AS timeviewtime'), 

			'status', 

			'lesson_id', 

			'transaction_id', 

			'user_id'

		];

	}



	

	static searchFields(){

		return [

			Sequelize.literal("id LIKE :search"), 

			Sequelize.literal("phone LIKE :search"), 

			Sequelize.literal("fingerPrint LIKE :search"), 

			Sequelize.literal("resumeTime LIKE :search"), 

			Sequelize.literal("timeViewTime LIKE :search"), 

			Sequelize.literal("status LIKE :search"), 

			Sequelize.literal("lesson_id LIKE :search"), 

			Sequelize.literal("transaction_id LIKE :search"), 

			Sequelize.literal("watchStart LIKE :search"),

		];

	}



	

	

}

SubscriberTracker.init();

export default SubscriberTracker;

