import { BaseModel, sequelize, Sequelize } from "./basemodel.js";



class AssignRights extends BaseModel {


	static init() {


		return super.init(


			{


				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },


				description: { type:Sequelize.STRING   },


				permission: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }


			}, 


			{ 


				sequelize,


				tableName: "assign_rights",


				modelName: "assign_rights",


				indexes: [
					{
						name: 'unique_assign_rights_permission',
						unique: true,
						fields: ['permission']
					}
				]


			}


		);


	}


	


	static listFields() {


		return [


			'id', 


			'description', 


			'permission'


		];


	}





	static viewFields() {


		return [


			'id', 


			'description', 


			'permission'


		];


	}





	static editFields() {


		return [


			'id', 


			'description', 


			'permission'


		];


	}





	static searchFields(){


		return [


			Sequelize.literal("id LIKE :search"), 


			Sequelize.literal("description LIKE :search"), 


			Sequelize.literal("permission LIKE :search"),


		];


	}





}





AssignRights.init();





export default AssignRights;
