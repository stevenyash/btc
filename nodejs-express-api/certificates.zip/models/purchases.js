
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Purchases extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				package_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_status: { type:Sequelize.ENUM('pending','success','failed')   },
				payment_reference: { type:Sequelize.STRING   },
				amount_paid: { type:Sequelize.NUMBER   },
				expiry_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "purchases",
				modelName: "purchases",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'user_id', 
			'package_id', 
			'transaction_date', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date'
		];
	}

	static viewFields() {
		return [
			'id', 
			'user_id', 
			'package_id', 
			'transaction_date', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date'
		];
	}

	static editFields() {
		return [
			'user_id', 
			'package_id', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("payment_reference LIKE :search"),
		];
	}

	
	
}
Purchases.init();
export default Purchases;
