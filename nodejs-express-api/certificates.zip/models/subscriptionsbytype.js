
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class SubscriptionsByType extends BaseModel {
	static init() {
		return super.init(
			{
				
				subscription_type_id: { type: Sequelize.INTEGER, primaryKey: true },
				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				description: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				membership_fee: { type:Sequelize.NUMBER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				months: { type:Sequelize.STRING , allowNull: false  },
				total_subscriptions: { type:Sequelize.STRING , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "subscriptions_by_type",
				modelName: "subscriptions_by_type",
			}
		);
	}
	
	static listFields() {
		return [
			'subscription_type_id', 
			'name', 
			'description', 
			'membership_fee', 
			'months', 
			'total_subscriptions'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("subscription_type_id LIKE :search"), 
			Sequelize.literal("name LIKE :search"), 
			Sequelize.literal("description LIKE :search"), 
			Sequelize.literal("months LIKE :search"),
		];
	}

	
	
}
SubscriptionsByType.init();
export default SubscriptionsByType;
