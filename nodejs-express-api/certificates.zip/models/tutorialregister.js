
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class TutorialRegister extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type:Sequelize.INTEGER  ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_date: { type:Sequelize.STRING   },
				transaction_status: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				payment_reference: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				amount_paid: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				expiry_date: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				tutorial_id: { type:Sequelize.INTEGER   },
				phone: { type:Sequelize.STRING   },
				email: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "tutorial_register",
				modelName: "tutorial_register",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'user_id', 
			'transaction_date', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date', 
			'tutorial_id', 
			'phone', 
			'email'
		];
	}

	static viewFields() {
		return [
			'id', 
			'user_id', 
			'transaction_date', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date', 
			'tutorial_id', 
			'phone', 
			'email'
		];
	}

	static editFields() {
		return [
			'id', 
			'user_id', 
			'transaction_status', 
			'payment_reference', 
			'amount_paid', 
			'expiry_date', 
			'tutorial_id', 
			'phone', 
			'email'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("transaction_date LIKE :search"), 
			Sequelize.literal("transaction_status LIKE :search"), 
			Sequelize.literal("payment_reference LIKE :search"), 
			Sequelize.literal("expiry_date LIKE :search"), 
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("email LIKE :search"),
		];
	}

	
	
}
TutorialRegister.init();
export default TutorialRegister;
