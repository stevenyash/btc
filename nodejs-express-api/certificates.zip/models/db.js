import { Sequelize, sequelize } from './basemodel.js';

// Override timezone formatting
Sequelize.DATE.prototype._stringify = function _stringify(date, options) {
    return this._applyTimezone(date, options).format('YYYY-MM-DD HH:mm:ss');
};

import AboutUs from './aboutus.js';
import ActiveSubscriptions from './activesubscriptions.js';
import AssignRights from './assignrights.js';
import ContactUs from './contactus.js';
import ExpiredSubscriptions from './expiredsubscriptions.js';
import Grades from './grades.js';
import GuestTracker from './guesttracker.js';
import GuestUsers from './guestusers.js';
import Invites from './invites.js';
import LearningAreas from './learningareas.js';
import LearningLevels from './learninglevels.js';
import Lessons from './lessons.js';
import LessonSetting from './lessonsetting.js';
import LessonTrack from './lessontrack.js';
import LessonAccessLogs from './lessonaccesslogs.js';
import Marketers from './marketers.js';
import MarketerCommissions from './marketer_commissions.js';
import MarketerPointRedemptions from './marketer_point_redemptions.js';
import MarketerWithdrawals from './marketer_withdrawals.js';
import SystemSettings from './system_settings.js';
import MonthlySubscriptionSummary from './monthlysubscriptionsummary.js';
import NewsletterSubscribers from './newslettersubscribers.js';
import Packages from './packages.js';
import Permissions from './permissions.js';
import Purchases from './purchases.js';
import Questions from './questions.js';
import Rightslist from './rightslist.js';
import RolePermissions from './rolepermissions.js';
import Roles from './roles.js';
import Scheduler from './scheduler.js';
import ServicesSettings from './servicessettings.js';
import SubscriberTracker from './subscribertracker.js';
import Subscriptions from './subscriptions.js';
import SubscriptionsByType from './subscriptionsbytype.js';
import SubscriptionsPerUser from './subscriptionsperuser.js';
import SubscriptionsRenewal from './subscriptionsrenewal.js';
import SubscriptionStatusDistribution from './subscriptionstatusdistribution.js';
import SubscriptionTypes from './subscriptiontypes.js';
import Subtopics from './subtopics.js';
import Topics from './topics.js';
import Transactions from './transactions.js';
import TutorialRegister from './tutorialregister.js';
import TutorialsSettings from './tutorialssettings.js';
import UserActivity from './useractivity.js';
import UserGuide from './userguide.js';
import UserPrivileges from './userprivileges.js';
import Users from './users.js';
import Videos from './videos.js';

// Set up associations
// Scheduler associations
Scheduler.belongsTo(Users, { foreignKey: 'user_id', as: 'users' });
Scheduler.belongsTo(Users, { foreignKey: 'user_id', as: 'users2' });

// Users associations
Users.belongsTo(Roles, { foreignKey: 'user_role_id', as: 'roles' });
Users.belongsTo(Roles, { foreignKey: 'user_role_id', as: 'roles2' });

// Learning hierarchy associations
LearningLevels.hasMany(Grades, { foreignKey: 'level_id', as: 'grades' });
Grades.belongsTo(LearningLevels, { foreignKey: 'level_id', as: 'learning_level' });

Grades.hasMany(LearningAreas, { foreignKey: 'grade_id', as: 'learning_areas' });
LearningAreas.belongsTo(Grades, { foreignKey: 'grade_id', as: 'grade_info' });

LearningAreas.hasMany(Lessons, { foreignKey: 'area_id', as: 'lessons' });
Lessons.belongsTo(LearningAreas, { foreignKey: 'area_id', as: 'learning_area' });

// Topics and Subtopics associations
Topics.hasMany(Subtopics, { foreignKey: 'topic_id', as: 'subtopics' });
Subtopics.belongsTo(Topics, { foreignKey: 'topic_id', as: 'topic' });

// Lessons associations with Topics and Subtopics
Lessons.belongsTo(Topics, { foreignKey: 'topic_id', as: 'topic' });
Lessons.belongsTo(Subtopics, { foreignKey: 'subtopic_id', as: 'subtopic' });

// Lesson tracking associations


// GuestTracker and LessonAccessLogs associations
GuestTracker.hasMany(LessonAccessLogs, { 
    foreignKey: 'guest_tracker_id', 
    as: 'access_logs' 
});
LessonAccessLogs.belongsTo(GuestTracker, { 
    foreignKey: 'guest_tracker_id', 
    as: 'guest_tracker' 
});
// After the existing LessonTrack associations, add:

LessonTrack.belongsTo(Subscriptions, { 
    foreignKey: 'subscription_id', 
    as: 'subscription' 
});

LessonTrack.belongsTo(Packages, { 
    foreignKey: 'package_id', 
    as: 'package' 
});
// LessonTrack and LessonAccessLogs associations
LessonTrack.hasMany(LessonAccessLogs, { 
    foreignKey: 'lesson_track_id', 
    as: 'access_logs' 
});
LessonAccessLogs.belongsTo(LessonTrack, { 
    foreignKey: 'lesson_track_id', 
    as: 'lesson_track' 
});

// Users and LessonAccessLogs associations
Users.hasMany(LessonAccessLogs, { 
    foreignKey: 'user_id', 
    as: 'access_logs' 
});
LessonAccessLogs.belongsTo(Users, { 
    foreignKey: 'user_id', 
    as: 'user' 
});

// Lessons and LessonAccessLogs associations
Lessons.hasMany(LessonAccessLogs, { 
    foreignKey: 'lesson_id', 
    as: 'access_logs' 
});
LessonAccessLogs.belongsTo(Lessons, { 
    foreignKey: 'lesson_id', 
    as: 'lesson' 
});

// LessonSetting and LessonAccessLogs associations
LessonSetting.hasMany(LessonAccessLogs, { 
    foreignKey: 'lesson_setting_id', 
    as: 'access_logs' 
});
LessonAccessLogs.belongsTo(LessonSetting, { 
    foreignKey: 'lesson_setting_id', 
    as: 'lesson_setting' 
});

// Purchase associations
Users.hasMany(Purchases, { foreignKey: 'user_id', as: 'purchases' });
Purchases.belongsTo(Users, { foreignKey: 'user_id', as: 'user' });

Lessons.hasMany(Purchases, { foreignKey: 'lesson_id', as: 'purchases' });
Purchases.belongsTo(Lessons, { foreignKey: 'lesson_id', as: 'lesson' });

// Subscription associations
Users.hasMany(Subscriptions, { foreignKey: 'user_id', as: 'subscriptions' });
Subscriptions.belongsTo(Users, { foreignKey: 'user_id', as: 'user' });

SubscriptionTypes.hasMany(Subscriptions, { foreignKey: 'subscription_type_id', as: 'subscriptions' });
Subscriptions.belongsTo(SubscriptionTypes, { foreignKey: 'subscription_type_id', as: 'subscription_type' });

// Video associations
Lessons.hasMany(Videos, { foreignKey: 'lesson_id', as: 'videos' });
Videos.belongsTo(Lessons, { foreignKey: 'lesson_id', as: 'lesson' });

// Question associations
Topics.hasMany(Questions, { foreignKey: 'topic_id', as: 'questions' });
Questions.belongsTo(Topics, { foreignKey: 'topic_id', as: 'topic' });

Subtopics.hasMany(Questions, { foreignKey: 'subtopic_id', as: 'questions' });
Questions.belongsTo(Subtopics, { foreignKey: 'subtopic_id', as: 'subtopic' });

// Marketer associations
Marketers.hasMany(MarketerCommissions, { foreignKey: 'marketer_id', as: 'commissions' });
MarketerCommissions.belongsTo(Marketers, { foreignKey: 'marketer_id', as: 'marketer' });
MarketerCommissions.belongsTo(Users, { foreignKey: 'user_id', as: 'user' });
MarketerCommissions.belongsTo(Transactions, { foreignKey: 'transaction_id', as: 'transaction' });

Marketers.hasMany(MarketerPointRedemptions, { foreignKey: 'marketer_id', as: 'point_redemptions' });
MarketerPointRedemptions.belongsTo(Marketers, { foreignKey: 'marketer_id', as: 'marketer' });

Marketers.hasMany(MarketerWithdrawals, { foreignKey: 'marketer_id', as: 'withdrawals' });
MarketerWithdrawals.belongsTo(Marketers, { foreignKey: 'marketer_id', as: 'marketer' });

const op = Sequelize.Op;
const raw = Sequelize.literal; // use to include raw expression

// Convinient functions for performing raw queries
// return different value types
function rawQuery(queryText, options) {
    return sequelize.query(queryText, options);
}

async function rawQueryList(queryText, queryParams) {
    const records = await rawQuery(queryText, { replacements: queryParams, type: Sequelize.QueryTypes.SELECT });
    return records;
}

async function rawQueryOne(queryText, queryParams) {
    const records = await rawQueryList(queryText, queryParams);
    return records[0] || null;
}

async function rawQueryValue(queryText, queryParams) {
    const record = await rawQueryOne(queryText, queryParams);
    if (record) {
        return Object.values(record)[0];
    }
    return null;
}

function getOrderBy(req, sortField = null, sortType = 'desc') {
    const orderBy = req.query.orderby || sortField;
    const orderType = req.query.ordertype || sortType;
    if (orderBy) {
        let order = raw(`${orderBy} ${orderType}`);
        return [[order]];
    }
    return null;
}

export default {
    sequelize,
    op,
    filterBy: function(expression, value) {
        return sequelize.where(raw(expression), value);
    },
    raw,
    rawQuery,
    rawQueryList,
    rawQueryOne,
    rawQueryValue,
    getOrderBy,
    AboutUs,
    ActiveSubscriptions,
    AssignRights,
    ContactUs,
    ExpiredSubscriptions,
    Grades,
    GuestTracker,
    GuestUsers,
    Invites,
    LearningAreas,
    LearningLevels,
    Lessons,
    LessonSetting,
    LessonTrack,
    LessonAccessLogs,    
    Marketers,
    MarketerCommissions,
    MarketerPointRedemptions,
    MarketerWithdrawals,
    SystemSettings,
    MonthlySubscriptionSummary,
    NewsletterSubscribers,
    Packages,
    Permissions,
    Purchases,
    Questions,
    Rightslist,
    RolePermissions,
    Roles,
    Scheduler,
    ServicesSettings,
    SubscriberTracker,
    Subscriptions,
    SubscriptionsByType,
    SubscriptionsPerUser,
    SubscriptionsRenewal,
    SubscriptionStatusDistribution,
    SubscriptionTypes,
    Subtopics,
    Topics,
    Transactions,
    TutorialRegister,
    TutorialsSettings,
    UserActivity,
    UserGuide,
    UserPrivileges,
    Users,
    Videos
};