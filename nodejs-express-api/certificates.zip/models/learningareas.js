// models/LearningAreas.js
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LearningAreas extends BaseModel {
    static init() {
        return super.init(
            {
                id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
                name: { type: Sequelize.STRING },
                description: { type: Sequelize.TEXT },
                grade_id: { type: Sequelize.INTEGER },
                color: { type: Sequelize.STRING, defaultValue: '#1976D2' },
                icon: { type: Sequelize.STRING },
                is_active: { type: Sequelize.BOOLEAN, defaultValue: true }
            },
            {
                sequelize,
                tableName: "learning_areas",
                modelName: "learning_areas",
            }
        );
    }

    static listFields() {
        return [
            'id',
            'name',
            'description',
            'grade_id',
            'color',
            'icon',
            'is_active'
        ];
    }

    static viewFields() {
        return [
            'id',
            'name',
            'description',
            'grade_id',
            'color',
            'icon',
            'is_active'
        ];
    }

    static editFields() {
        return [
            'id',
            'name',
            'description',
            'grade_id',
            'color',
            'icon',
            'is_active'
        ];
    }

    static searchFields() {
        return [
            Sequelize.literal("id LIKE :search"),
            Sequelize.literal("name LIKE :search"),
            Sequelize.literal("description LIKE :search"),
        ];
    }

    // Define associations
    static associate(models) {
        this.belongsTo(models.Grades, {
            foreignKey: 'grade_id',
            as: 'grade_info'
        });
        
        this.hasMany(models.Lessons, {
            foreignKey: 'area_id',
            as: 'lessons'
        });
    }
}

LearningAreas.init();
export default LearningAreas;