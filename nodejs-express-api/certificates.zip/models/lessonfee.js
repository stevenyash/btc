
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LessonFee extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				fee: { type:Sequelize.STRING   },
				duaration: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "lesson_fee",
				modelName: "lesson_fee",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'fee', 
			'duaration'
		];
	}

	static viewFields() {
		return [
			'id', 
			'fee', 
			'duaration'
		];
	}

	static editFields() {
		return [
			'fee', 
			'duaration', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("fee LIKE :search"), 
			Sequelize.literal("duaration LIKE :search"),
		];
	}

	
	
}
LessonFee.init();
export default LessonFee;
