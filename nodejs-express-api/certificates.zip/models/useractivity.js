
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class UserActivity extends BaseModel {
	static init() {
		return super.init(
			{
				
				activity_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type:Sequelize.INTEGER   },
				fingerprint: { type:Sequelize.STRING   },
				session_duration: { type:Sequelize.INTEGER  ,defaultValue: Sequelize.literal('DEFAULT') },
				status: { type:Sequelize.ENUM('active','inactive')   },
				activity_type: { type:Sequelize.ENUM('login','logout')   },
				activity_time: { type:Sequelize.DATE   },
				platiform: { type:Sequelize.STRING   },
				device: { type:Sequelize.STRING   },
				ip_address: { type:Sequelize.STRING   },
				phone: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "user_activity",
				modelName: "user_activity",
			}
		);
	}
	
	static listFields() {
		return [
			'activity_id', 
			'user_id', 
			'fingerprint', 
			'session_duration', 
			'status', 
			'activity_type', 
			'activity_time', 
			'platiform', 
			'device', 
			'ip_address', 
			'phone'
		];
	}

	static viewFields() {
		return [
			'activity_id', 
			'user_id', 
			'fingerprint', 
			'session_duration', 
			'status', 
			'activity_type', 
			'activity_time', 
			'platiform', 
			'device', 
			'ip_address', 
			'phone'
		];
	}

	static editFields() {
		return [
			'activity_id', 
			'user_id', 
			'fingerprint', 
			'session_duration', 
			'status', 
			'activity_type', 
			'platiform', 
			'device', 
			'ip_address', 
			'phone'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("activity_id LIKE :search"), 
			Sequelize.literal("fingerprint LIKE :search"), 
			Sequelize.literal("platiform LIKE :search"), 
			Sequelize.literal("device LIKE :search"), 
			Sequelize.literal("ip_address LIKE :search"), 
			Sequelize.literal("phone LIKE :search"),
		];
	}

	
	
}
UserActivity.init();
export default UserActivity;
