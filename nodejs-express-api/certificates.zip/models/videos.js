import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Videos extends BaseModel {

	static init() {
		return super.init(
			{
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				file: { type: Sequelize.STRING },
				collection: { type: Sequelize.STRING },
				visibility: { type: Sequelize.STRING },
				filename: { type: Sequelize.STRING },
				status: { type: Sequelize.STRING },
				description: { type: Sequelize.STRING },
				category: { type: Sequelize.STRING },
				title: { type: Sequelize.STRING },

				// ✅ Newly added columns
				s3_key: { type: Sequelize.STRING(500) },
				s3_url: { type: Sequelize.STRING(500) },
				file_size: { type: Sequelize.BIGINT },
				uploaded_at: { type: Sequelize.DATE },
				upload_error: { type: Sequelize.TEXT }
			},
			{
				sequelize,
				tableName: "Videos",
				modelName: "Videos",
			}
		);
	}

	static listFields() {
		return [
			'id',
			'file',
			'collection',
			'visibility',
			'filename',
			'status',
			'description',
			'category',
			'title',
			's3_key',
			's3_url',
			'file_size',
			'uploaded_at',
			'upload_error'
		];
	}

	static viewFields() {
		return [
			'id',
			'file',
			'collection',
			'visibility',
			'filename',
			'status',
			'description',
			'category',
			'title',
			's3_key',
			's3_url',
			'file_size',
			'uploaded_at',
			'upload_error'
		];
	}

	static editFields() {
		return [
			'filename',
			'title',
			'file',
			'collection',
			'visibility',
			'status',
			'category',
			'description',
			's3_key',
			's3_url',
			'file_size',
			'uploaded_at',
			'upload_error',
			'id'
		];
	}

	static searchFields() {
		return [
			Sequelize.literal("id LIKE :search"),
			Sequelize.literal("collection LIKE :search"),
			Sequelize.literal("visibility LIKE :search"),
			Sequelize.literal("status LIKE :search"),
			Sequelize.literal("description LIKE :search"),
			Sequelize.literal("category LIKE :search"),
			Sequelize.literal("title LIKE :search"),
			Sequelize.literal("s3_key LIKE :search"),
			Sequelize.literal("s3_url LIKE :search"),
			Sequelize.literal("upload_error LIKE :search")
		];
	}
}

Videos.init();

export default Videos;