
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Topics extends BaseModel {
	static init() {
		return super.init(
			{
				
				topic_id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				area_id: { type:Sequelize.INTEGER   },
				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "topics",
				modelName: "topics",
			}
		);
	}
	
	static listFields() {
		return [
			'topic_id', 
			'area_id', 
			'name'
		];
	}

	static viewFields() {
		return [
			'topic_id', 
			'area_id', 
			'name'
		];
	}

	static editFields() {
		return [
			'topic_id', 
			'area_id', 
			'name'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("topic_id LIKE :search"), 
			Sequelize.literal("name LIKE :search"),
		];
	}

	
	
}
Topics.init();
export default Topics;
