
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class ActiveIndividualPackage extends BaseModel {
	static init() {
		return super.init(
			{
				
				purchase_id: { type: Sequelize.INTEGER, primaryKey: true },
				package_name: { type:Sequelize.STRING  ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				expiry_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				status: { type:Sequelize.STRING  ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "active_individual_package",
				modelName: "active_individual_package",
			}
		);
	}
	
	static listFields() {
		return [
			'purchase_id', 
			'buyer_phone', 
			'package_name', 
			'transaction_date', 
			'expiry_date', 
			'status'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("purchase_id LIKE :search"), 
			Sequelize.literal("buyer_phone LIKE :search"), 
			Sequelize.literal("package_name LIKE :search"), 
			Sequelize.literal("status LIKE :search"),
		];
	}

	
	
}
ActiveIndividualPackage.init();
export default ActiveIndividualPackage;
