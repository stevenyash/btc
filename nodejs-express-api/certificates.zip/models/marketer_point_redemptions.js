import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class MarketerPointRedemptions extends BaseModel {

  static init() {

    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
        marketer_id: { type: Sequelize.INTEGER, allowNull: false },
        points_redeemed: { type: Sequelize.INTEGER, allowNull: false },
        point_value: { type: Sequelize.DECIMAL(12, 2), allowNull: false },
        cash_amount: { type: Sequelize.DECIMAL(12, 2), allowNull: false },
        status: { type: Sequelize.ENUM('pending', 'approved', 'rejected'), defaultValue: 'pending' },
        remarks: { type: Sequelize.TEXT, allowNull: true },
        reviewed_by: { type: Sequelize.INTEGER, allowNull: true },
        reviewed_at: { type: Sequelize.DATE, allowNull: true },
        created_at: { type: Sequelize.DATE, defaultValue: Sequelize.NOW },
      },
      {
        sequelize,
        tableName: "marketer_point_redemptions",
        modelName: "marketer_point_redemptions",
        timestamps: false,
      }
    );
  }

  static listFields() {
    return [
      'id', 'marketer_id', 'points_redeemed', 'point_value',
      'cash_amount', 'status', 'remarks', 'reviewed_by',
      'reviewed_at', 'created_at'
    ];
  }

  static viewFields() {
    return [
      'id', 'marketer_id', 'points_redeemed', 'point_value',
      'cash_amount', 'status', 'remarks', 'reviewed_by',
      'reviewed_at', 'created_at'
    ];
  }

  static editFields() {
    return [
      'id', 'marketer_id', 'points_redeemed', 'point_value',
      'cash_amount', 'status', 'remarks', 'reviewed_by',
      'reviewed_at'
    ];
  }

  static searchFields() {
    return [
      Sequelize.literal("id LIKE :search"),
      Sequelize.literal("status LIKE :search"),
      Sequelize.literal("remarks LIKE :search"),
    ];
  }
}

MarketerPointRedemptions.init();

export default MarketerPointRedemptions;
