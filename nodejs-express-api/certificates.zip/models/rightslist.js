
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Rightslist extends BaseModel {
	static init() {
		return super.init(
			{
				
				user_id: { type:Sequelize.INTEGER , allowNull: false  },
				username: { type:Sequelize.STRING   },
				phone: { type:Sequelize.STRING   },
				email: { type:Sequelize.STRING   },
				image: { type:Sequelize.STRING   },
				role_id: { type:Sequelize.INTEGER , allowNull: false  },
				role_name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				permission_id: { type: Sequelize.INTEGER, primaryKey: true },
				description: { type:Sequelize.STRING   },
				has_right: { type:Sequelize.INTEGER , allowNull: false  },
				permission: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "rightslist",
				modelName: "rightslist",
			}
		);
	}
	
	static listFields() {
		return [
			'description', 
			'permission', 
			'has_right'
		];
	}

	static viewFields() {
		return [
			'user_id', 
			'username', 
			'phone', 
			'email', 
			'image', 
			'role_id', 
			'role_name', 
			'permission_id', 
			'description', 
			'right', 
			'has_right'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("description LIKE :search"), 
			Sequelize.literal("permission LIKE :search"),
		];
	}

	
	
}
Rightslist.init();
export default Rightslist;
