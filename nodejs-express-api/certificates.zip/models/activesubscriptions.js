
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class ActiveSubscriptions extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true },
				username: { type:Sequelize.STRING   },
				image: { type:Sequelize.STRING   },
				phone: { type:Sequelize.STRING   },
				email: { type:Sequelize.STRING   },
				subscription_code: { type:Sequelize.STRING   },
				referred_by: { type:Sequelize.STRING   },
				status: { type:Sequelize.STRING   },
				start_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				expiry_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "active_subscriptions",
				modelName: "active_subscriptions",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'username', 
			'image', 
			'phone', 
			'email', 
			'subscription_code', 
			'referred_by', 
			'status', 
			'start_date', 
			'expiry_date'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("username LIKE :search"), 
			Sequelize.literal("phone LIKE :search"), 
			Sequelize.literal("email LIKE :search"), 
			Sequelize.literal("subscription_code LIKE :search"), 
			Sequelize.literal("referred_by LIKE :search"), 
			Sequelize.literal("status LIKE :search"),
		];
	}

	
	
}
ActiveSubscriptions.init();
export default ActiveSubscriptions;
