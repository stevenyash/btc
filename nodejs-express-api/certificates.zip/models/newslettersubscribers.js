
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class NewsletterSubscribers extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				email: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				name: { type:Sequelize.STRING   },
				subscribed_at: { type:Sequelize.DATE   },
				status: { type:Sequelize.ENUM('subscribed','unsubscribed')   },
				phone: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "newsletter_subscribers",
				modelName: "newsletter_subscribers",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'email', 
			'name', 
			'subscribed_at', 
			'status', 
			'phone'
		];
	}

	static viewFields() {
		return [
			'id', 
			'email', 
			'name', 
			'subscribed_at', 
			'status', 
			'phone'
		];
	}

	static editFields() {
		return [
			'email', 
			'name', 
			'phone', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("email LIKE :search"), 
			Sequelize.literal("name LIKE :search"), 
			Sequelize.literal("phone LIKE :search"),
		];
	}

	
	
}
NewsletterSubscribers.init();
export default NewsletterSubscribers;
