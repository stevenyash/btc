
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Subscriptions extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				user_id: { type:Sequelize.STRING   },
				subscription_code: { type:Sequelize.STRING   },
				status: { type:Sequelize.STRING   },
				start_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') },
				transaction_id: { type:Sequelize.INTEGER , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				phone_no: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				subscription_type_id: { type:Sequelize.INTEGER   },
				expiry_date: { type:Sequelize.DATE  ,defaultValue: Sequelize.literal('DEFAULT') }
			}, 
			{ 
				sequelize,
				
				tableName: "subscriptions",
				modelName: "subscriptions",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'user_id', 
			'subscription_code', 
			'status', 
			'start_date', 
			'transaction_id', 
			'phone_no', 
			'subscription_type_id', 
			'expiry_date'
		];
	}

	static viewFields() {
		return [
			'id', 
			'user_id', 
			'subscription_code', 
			'status', 
			'start_date', 
			'transaction_id', 
			'phone_no', 
			'subscription_type_id', 
			'expiry_date'
		];
	}

	static editFields() {
		return [
			'user_id', 
			'subscription_code', 
			'status', 
			'start_date', 
			'transaction_id', 
			'phone_no', 
			'id', 
			'subscription_type_id', 
			'expiry_date'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("user_id LIKE :search"), 
			Sequelize.literal("subscription_code LIKE :search"), 
			Sequelize.literal("status LIKE :search"), 
			Sequelize.literal("start_date LIKE :search"), 
			Sequelize.literal("phone_no LIKE :search"),
		];
	}

	
	
}
Subscriptions.init();
export default Subscriptions;
