
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class UserGuideSetting extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				guide: { type:Sequelize.STRING   }
			}, 
			{ 
				sequelize,
				
				tableName: "user_guide_setting",
				modelName: "user_guide_setting",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'guide'
		];
	}

	static viewFields() {
		return [
			'id', 
			'guide'
		];
	}

	static editFields() {
		return [
			'guide', 
			'id'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("guide LIKE :search"),
		];
	}

	
	
}
UserGuideSetting.init();
export default UserGuideSetting;
