
import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class LearningServices extends BaseModel {
	static init() {
		return super.init(
			{
				
				id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
				name: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				label: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				description: { type:Sequelize.STRING , allowNull: false ,defaultValue: Sequelize.literal('DEFAULT') },
				created_at: { type:Sequelize.DATE , allowNull: false  },
				updated_at: { type:Sequelize.DATE , allowNull: false  }
			}, 
			{ 
				sequelize,
				
				tableName: "learning_services",
				modelName: "learning_services",
			}
		);
	}
	
	static listFields() {
		return [
			'id', 
			'name', 
			'label', 
			'description', 
			'created_at', 
			'updated_at'
		];
	}

	static viewFields() {
		return [
			'id', 
			'name', 
			'label', 
			'description', 
			'created_at', 
			'updated_at'
		];
	}

	static editFields() {
		return [
			'id', 
			'name', 
			'label', 
			'description'
		];
	}

	
	static searchFields(){
		return [
			Sequelize.literal("id LIKE :search"), 
			Sequelize.literal("name LIKE :search"), 
			Sequelize.literal("label LIKE :search"), 
			Sequelize.literal("description LIKE :search"),
		];
	}

	
	
}
LearningServices.init();
export default LearningServices;
