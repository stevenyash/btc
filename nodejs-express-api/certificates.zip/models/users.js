import { BaseModel, sequelize, Sequelize } from "./basemodel.js";

class Users extends BaseModel {
  static init() {
    return super.init(
      {
        id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },

        username: { type: Sequelize.STRING },

        password: { type: Sequelize.STRING },

        image: { type: Sequelize.STRING },

        phone: { type: Sequelize.STRING },

        email: { type: Sequelize.STRING },

        account_status: { type: Sequelize.STRING },

        user_role_id: { type: Sequelize.INTEGER },

        nhif: { type: Sequelize.STRING },

        nssf: { type: Sequelize.STRING },

        national_id: { type: Sequelize.STRING },

        subscription_code: { type: Sequelize.STRING },

        status: { type: Sequelize.INTEGER },

        referred_by: { type: Sequelize.STRING },
      },

      {
        sequelize,

        tableName: "users",

        modelName: "users",
      }
    );
  }

  static listFields() {
    return [
      Sequelize.literal("roles.role_name AS roles_role_name"),

      Sequelize.literal("users.username AS username"),

      Sequelize.literal("users.image AS image"),

      Sequelize.literal("users.phone AS phone"),

      Sequelize.literal("users.email AS email"),

      Sequelize.literal("users.nhif AS nhif"),

      Sequelize.literal("users.nssf AS nssf"),

      Sequelize.literal("users.national_id AS national_id"),

      Sequelize.literal("users.account_status AS account_status"),

      Sequelize.literal("users.id AS id"),

      Sequelize.literal("roles.role_id AS roles_role_id"),
    ];
  }

  static viewFields() {
    return [
      Sequelize.literal("users.id AS id"),

      Sequelize.literal("users.username AS username"),

      Sequelize.literal("users.phone AS phone"),

      Sequelize.literal("users.email AS email"),

      Sequelize.literal("users.account_status AS account_status"),

      Sequelize.literal("users.user_role_id AS user_role_id"),

      Sequelize.literal("users.nhif AS nhif"),

      Sequelize.literal("users.nssf AS nssf"),

      Sequelize.literal("users.national_id AS national_id"),

      Sequelize.literal("users.subscription_code AS subscription_code"),

      Sequelize.literal("users.status AS status"),

      Sequelize.literal("users.referred_by AS referred_by"),

      Sequelize.literal("roles.role_id AS roles_role_id"),

      Sequelize.literal("roles.role_name AS roles_role_name"),
    ];
  }

  static accounteditFields() {
    return [
      "image",

      "phone",

      "username",

      "status",

      "subscription_code",

      "user_role_id",

      "nhif",

      "nssf",

      "national_id",

      "password",

      "email",

      "referred_by",

      "id",
    ];
  }

  static accountviewFields() {
    return [
      "id",

      "username",

      "phone",

      "email",

      "account_status",

      "subscription_code",

      "status",

      "referred_by",
    ];
  }

  static editFields() {
    return [
      "image",

      "username",

      "phone",

      "user_role_id",

      "nhif",

      "nssf",

      "national_id",

      "account_status",

      "id",
    ];
  }

  static referralsFields() {
    return ["username", "email", "referred_by", "id"];
  }

  static searchFields() {
    return [
      Sequelize.literal("roles.role_name LIKE :search"),

      Sequelize.literal("users.username LIKE :search"),

      Sequelize.literal("users.phone LIKE :search"),

      Sequelize.literal("users.email LIKE :search"),

      Sequelize.literal("users.nhif LIKE :search"),

      Sequelize.literal("users.nssf LIKE :search"),

      Sequelize.literal("users.national_id LIKE :search"),

      Sequelize.literal("users.account_status LIKE :search"),

      Sequelize.literal("users.id LIKE :search"),

      Sequelize.literal("roles.role_id LIKE :search"),

      Sequelize.literal("users.subscription_code LIKE :search"),

      Sequelize.literal("users.referred_by LIKE :search"),
    ];
  }
}

Users.init();

export default Users;
