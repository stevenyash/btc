// services/videoSyncService.js

import AWS from 'aws-sdk';

import DB from '../models/db.js';

import databasePopulationService from './databasePopulationService.js';

import completeMigrationService from './completeMigrationService.js';



class VideoSyncService {

    constructor() {

        // AWS credentials

        const awsConfig = {

            secretAccessKey: "710hBsCQX6rIEI8h0TAP4BVQXGKwE4J6WvxTxjbW",

            accessKeyId: "AKIAXWHDMCUQNG6SNQMS"

        };



        // Africa Cape Town S3 client

        this.s3Africa = new AWS.S3({

            ...awsConfig,

            region: 'af-south-1'

        });



        this.africaBucket = 'tutorconnect-videos-af';

        this.cloudFrontDomain = null;

    }



    // Scan Africa bucket for new videos and sync with database

    async scanAndSyncNewVideos() {

        try {

            console.log('🔍 Scanning Africa bucket for new videos...');



            // Get CloudFront domain if not set

            if (!this.cloudFrontDomain) {

                await this.setCloudFrontDomain();

            }



            // Step 1: Get all videos from Africa bucket

            const africaVideos = await this.listAllAfricaVideos();

            console.log(`📹 Found ${africaVideos.length} videos in Africa bucket`);



            // Step 2: Get existing lessons from database

            const existingLessons = await this.getExistingLessons();

            console.log(`🗃️ Found ${existingLessons.length} existing lessons in database`);



            // Step 3: Find new videos (not in database)

            const newVideos = this.findNewVideos(africaVideos, existingLessons);

            console.log(`🆕 Found ${newVideos.length} new videos to sync`);



            if (newVideos.length === 0) {

                return {

                    success: true,

                    message: 'No new videos found. Database is already in sync.',

                    synced: 0,

                    total: africaVideos.length

                };

            }



            // Step 4: Create database entries for new videos

            const syncResults = await this.syncVideosToDatabase(newVideos);



            // Step 5: Verify sync

            const verification = await this.verifySync(newVideos.length);



            console.log('🎉 Video sync completed!');



            return {

                success: true,

                message: `Successfully synced ${syncResults.created} new videos`,

                data: {

                    scanned: africaVideos.length,

                    newVideos: newVideos.length,

                    synced: syncResults.created,

                    failed: syncResults.failed,

                    verification: verification

                }

            };



        } catch (error) {

            console.error('❌ Error scanning and syncing videos:', error);

            throw error;

        }

    }



    // List all videos from Africa bucket

    async listAllAfricaVideos(prefix = '') {

        try {

            let allObjects = [];

            let continuationToken = null;



            do {

                const params = {

                    Bucket: this.africaBucket,

                    Prefix: prefix,

                    ContinuationToken: continuationToken

                };



                const response = await this.s3Africa.listObjectsV2(params).promise();



                if (response.Contents) {

                    allObjects = allObjects.concat(response.Contents);

                }



                continuationToken = response.NextContinuationToken;



            } while (continuationToken);



            // Filter out folders and return only video files

            return allObjects.filter(obj =>

                !obj.Key.endsWith('/') &&

                this.isVideoFile(obj.Key)

            );

        } catch (error) {

            console.error('Error listing Africa bucket objects:', error);

            throw error;

        }

    }



    // Check if file is a video

    isVideoFile(filename) {

        const videoExtensions = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.m4v'];

        return videoExtensions.some(ext =>

            filename.toLowerCase().endsWith(ext)

        );

    }



    // Get existing lessons from database

    async getExistingLessons() {

        try {

            const lessons = await DB.Lessons.findAll({

                attributes: ['id', 's3_key', 'title', 'filename'],

                raw: true

            });

            return lessons;

        } catch (error) {

            console.error('Error getting existing lessons:', error);

            throw error;

        }

    }



    // Find videos that exist in S3 but not in database

    findNewVideos(africaVideos, existingLessons) {

        const existingS3Keys = new Set(existingLessons.map(lesson => lesson.s3_key));



        return africaVideos.filter(video =>

            !existingS3Keys.has(video.Key)

        );

    }



    // Set CloudFront domain

    async setCloudFrontDomain() {

        try {

            // Try to get from complete migration service first

            if (completeMigrationService.destCloudFrontDomain) {

                this.cloudFrontDomain = completeMigrationService.destCloudFrontDomain;

            } else {

                // Fallback: Use the standard CloudFront domain pattern

                // You might want to query CloudFront API to get the actual domain

                this.cloudFrontDomain = await this.getCloudFrontDomainFromAPI();

            }



            console.log(`🌐 Using CloudFront domain: ${this.cloudFrontDomain}`);

        } catch (error) {

            console.error('Error setting CloudFront domain:', error);

            // Use fallback domain pattern

            this.cloudFrontDomain = `https://${this.africaBucket}.s3.af-south-1.amazonaws.com`;

        }

    }



    // Get CloudFront domain from API (placeholder implementation)

    async getCloudFrontDomainFromAPI() {

        // This would typically query CloudFront API to get the distribution domain

        // For now, we'll use a pattern or get it from environment/config

        return `https://d111111abcdef8.cloudfront.net`; // Example pattern

    }



    // Sync new videos to database

    async syncVideosToDatabase(newVideos) {

        try {

            console.log(`🔄 Syncing ${newVideos.length} new videos to database...`);



            let created = 0;

            let failed = 0;

            const failedVideos = [];



            // Group videos by folder to use existing hierarchy mapping

            const videosByFolder = this.groupVideosByFolder(newVideos);



            for (const [folderName, videos] of Object.entries(videosByFolder)) {

                console.log(`\n📂 Processing folder: ${folderName} (${videos.length} videos)`);



                try {

                    const folderResults = await this.syncFolderVideos(folderName, videos);

                    created += folderResults.created;

                    failed += folderResults.failed;

                    failedVideos.push(...folderResults.failedVideos);

                } catch (folderError) {

                    console.error(`❌ Error processing folder ${folderName}:`, folderError);

                    failed += videos.length;

                    videos.forEach(video => {

                        failedVideos.push({

                            video: video.Key,

                            error: folderError.message

                        });

                    });

                }

            }



            return {

                created,

                failed,

                failedVideos

            };



        } catch (error) {

            console.error('Error syncing videos to database:', error);

            throw error;

        }

    }



    // Group videos by their folder

    groupVideosByFolder(videos) {

        const grouped = {};



        videos.forEach(video => {

            const folder = video.Key.split('/')[0];

            if (!grouped[folder]) {

                grouped[folder] = [];

            }

            grouped[folder].push(video);

        });



        return grouped;

    }



    // Sync videos from a specific folder

    async syncFolderVideos(folderName, videos) {

        const folderMap = databasePopulationService.getFolderToHierarchyMap();

        const hierarchy = folderMap[folderName];



        if (!hierarchy) {

            console.log(`⚠️ No hierarchy mapping for folder: ${folderName}`);

            return {

                created: 0,

                failed: videos.length,

                failedVideos: videos.map(v => ({

                    video: v.Key,

                    error: `No hierarchy mapping for folder: ${folderName}`

                }))

            };

        }



        // Get or create hierarchy entities

        const level = await databasePopulationService.getOrCreateLevel(hierarchy.level_name);

        const grade = await databasePopulationService.getOrCreateGrade(hierarchy.grade_name, level.level_id);

        const area = await databasePopulationService.getOrCreateArea(hierarchy.area_name, grade.id);



        let created = 0;

        let failed = 0;

        const failedVideos = [];



        // Create lessons for each video in this folder

        for (const video of videos) {

            try {

                await databasePopulationService.createLessonFromFile(

                    video,

                    area,

                    this.cloudFrontDomain

                );

                created++;

                console.log(`✅ Synced: ${video.Key}`);

            } catch (error) {

                console.error(`❌ Failed to sync: ${video.Key}`, error.message);

                failed++;

                failedVideos.push({

                    video: video.Key,

                    error: error.message

                });

            }

        }



        return { created, failed, failedVideos };

    }



    // Verify the sync operation

    async verifySync(expectedCount) {

        try {

            const totalLessons = await DB.Lessons.count();

            const lessonsWithFiles = await DB.Lessons.count({

                where: { s3_key: { [DB.Op.ne]: null } }

            });



            return {

                totalLessons,

                lessonsWithFiles,

                syncSuccess: lessonsWithFiles >= expectedCount

            };

        } catch (error) {

            console.error('Error verifying sync:', error);

            return { error: error.message };

        }

    }



    // Get sync status (what would be synced)

    async getSyncStatus() {

        try {

            const africaVideos = await this.listAllAfricaVideos();

            const existingLessons = await this.getExistingLessons();

            const newVideos = this.findNewVideos(africaVideos, existingLessons);



            // Group by folder for reporting

            const newVideosByFolder = this.groupVideosByFolder(newVideos);



            return {

                totalVideosInBucket: africaVideos.length,

                totalLessonsInDb: existingLessons.length,

                newVideosToSync: newVideos.length,

                newVideosByFolder: Object.keys(newVideosByFolder).reduce((acc, folder) => {

                    acc[folder] = newVideosByFolder[folder].length;

                    return acc;

                }, {}),

                isSyncNeeded: newVideos.length > 0

            };

        } catch (error) {

            console.error('Error getting sync status:', error);

            throw error;

        }

    }



    // Sync specific folder only
    async syncSpecificFolder(folderName) {
        try {
            console.log(`🔍 Scanning folder: ${folderName} for new videos...`);

            const folderVideos = await this.listAllAfricaVideos(folderName + '/');
            const existingLessons = await this.getExistingLessons();
            const newVideos = this.findNewVideos(folderVideos, existingLessons);

            if (newVideos.length === 0) {
                return {
                    success: true,
                    message: `No new videos found in folder: ${folderName}`,
                    synced: 0
                };
            }

            const syncResults = await this.syncFolderVideos(folderName, newVideos);

            return {
                success: true,
                message: `Synced folder: ${folderName}`,
                data: {
                    scanned: folderVideos.length,
                    newVideos: newVideos.length,
                    created: syncResults.created,
                    failed: syncResults.failed
                }
            };

        } catch (error) {
            console.error(`Error syncing folder ${folderName}:`, error);
            throw error;
        }
    }

    // Clean up orphaned lessons (lessons without S3 files)
    async cleanupOrphanedLessons() {
        try {
            console.log('🧹 Cleaning up orphaned lessons...');

            // Get all videos from S3
            const africaVideos = await this.listAllAfricaVideos();
            const s3Keys = new Set(africaVideos.map(video => video.Key));

            // Get all lessons from database
            const allLessons = await this.getExistingLessons();

            // Find lessons without S3 files
            const orphanedLessons = allLessons.filter(lesson => 
                lesson.s3_key && !s3Keys.has(lesson.s3_key)
            );

            console.log(`Found ${orphanedLessons.length} orphaned lessons`);

            if (orphanedLessons.length === 0) {
                return {
                    success: true,
                    message: 'No orphaned lessons found',
                    removed: 0,
                    orphanedLessons: []
                };
            }

            // Delete orphaned lessons
            const orphanedIds = orphanedLessons.map(lesson => lesson.id);
            const deleted = await DB.Lessons.destroy({
                where: { id: orphanedIds }
            });

            console.log(`✅ Removed ${deleted} orphaned lessons`);

            return {
                success: true,
                message: `Removed ${deleted} orphaned lessons`,
                removed: deleted,
                orphanedLessons: orphanedLessons.map(l => ({
                    id: l.id,
                    title: l.title,
                    s3_key: l.s3_key
                }))
            };

        } catch (error) {
            console.error('Error cleaning up orphaned lessons:', error);
            throw error;
        }
    }

    // Full sync: Add new videos and remove orphaned lessons
    async fullSync() {
        try {
            console.log('🔄 Starting full sync (add new + remove orphaned)...');

            // Step 1: Sync new videos
            const syncResults = await this.scanAndSyncNewVideos();

            // Step 2: Clean up orphaned lessons
            const cleanupResults = await this.cleanupOrphanedLessons();

            // Step 3: Get final status
            const finalStatus = await this.getSyncStatus();

            return {
                success: true,
                message: 'Full sync completed',
                sync: syncResults.data || syncResults,
                cleanup: cleanupResults,
                finalStatus: finalStatus
            };

        } catch (error) {
            console.error('Error during full sync:', error);
            throw error;
        }
    }
}

export default new VideoSyncService();