// services/completeMigrationService.js
import AWS from 'aws-sdk';
import cloudFrontService from './cloudFrontService.js';
import databasePopulationService from './databasePopulationService.js';

class CompleteMigrationService {
  constructor() {
    // AWS credentials (shared between regions)
    const awsConfig = {
      secretAccessKey: "710hBsCQX6rIEI8h0TAP4BVQXGKwE4J6WvxTxjbW",
      accessKeyId: "AKIAXWHDMCUQNG6SNQMS"
    };

    // Source: Stockholm (eu-north-1)
    this.s3Source = new AWS.S3({
      ...awsConfig,
      region: 'eu-north-1'
    });
    
    // Destination: Cape Town (af-south-1)
    this.s3Dest = new AWS.S3({
      ...awsConfig,
      region: 'af-south-1'
    });
    
    // Bucket names
    this.sourceBucket = 'bitstutorconnect';
    this.destBucket = 'tutorconnect-videos-af';
    
    // Will be set after CloudFront setup
    this.destCloudFrontDomain = null;
  }

  // Complete migration: Files + Database Population
  async completeMigration() {
    try {
      console.log('🚀 COMPLETE MIGRATION: Files + Database');
      console.log('=======================================');
      console.log('📁 S3 Source: bitstutorconnect (eu-north-1 - Stockholm)');
      console.log('📁 S3 Destination: tutorconnect-videos-af (af-south-1 - Cape Town)');
      console.log('🏫 Hierarchy: Junior Secondary + Senior Secondary');
      console.log('=======================================\n');
      
      // Step 1: Setup CloudFront
      console.log('🌐 Step 1: Setting up CloudFront...');
      const cloudFrontResult = await this.setupCloudFront();
      
      // Step 2: Test connections
      console.log('\n🔗 Step 2: Testing S3 connections...');
      await this.testConnections();
      
      // Step 3: Get migration stats
      console.log('\n📊 Step 3: Gathering migration statistics...');
      const stats = await this.getMigrationStats();
      console.log('📦 Migration Overview:');
      console.log(`- Total files to migrate: ${stats.totalFiles}`);
      console.log(`- Estimated size: ${stats.estimatedTotalSize}`);
      console.log(`- Folders found: ${stats.folders.join(', ')}`);
      
      // Step 4: Migrate all S3 files
      console.log('\n🔄 Step 4: Migrating S3 files...');
      const s3Files = await this.listAllS3Objects();
      const migrationResults = await this.migrateAllS3Files(s3Files);
      
      // Step 5: Populate database
      console.log('\n🗃️ Step 5: Populating database with lessons...');
      const populationResults = await databasePopulationService.populateDatabaseFromS3(
        s3Files, 
        this.destCloudFrontDomain
      );
      
      // Step 6: Verify everything
      console.log('\n🔍 Step 6: Verifying migration...');
      const verification = await databasePopulationService.verifyPopulation();
      const fileVerification = await this.quickVerification(5);
      
      // Final report
      console.log('\n🎉 COMPLETE MIGRATION FINISHED!');
      console.log('=============================');
      console.log(`📊 Files migrated: ${migrationResults.successful}/${migrationResults.total}`);
      console.log(`🗃️ Lessons created: ${populationResults.createdCount}`);
      console.log(`🌐 CloudFront: ${this.destCloudFrontDomain}`);
      console.log(`🔍 Database verified: ${verification.lessonsWithFiles}/${verification.totalLessons} lessons with files`);
      
      console.log('\n💡 NEXT STEPS:');
      console.log('1. Your app is now ready with complete lesson database');
      console.log('2. All files migrated to Africa region for better performance');
      console.log('3. CloudFront CDN set up for fast video delivery');
      console.log('4. Complete hierarchy: Levels → Grades → Areas → Topics → Subtopics → Lessons');
      console.log('5. Test your application thoroughly');
      
      return {
        migration: migrationResults,
        population: populationResults,
        verification: verification,
        cloudFront: this.destCloudFrontDomain
      };
      
    } catch (error) {
      console.error('💥 Complete migration failed:', error);
      throw error;
    }
  }

  // Setup CloudFront for destination bucket
  async setupCloudFront() {
    try {
      console.log('Setting up CloudFront for Africa bucket...');
      
      const cloudFrontResult = await cloudFrontService.setupAfricaCloudFront();
      this.destCloudFrontDomain = cloudFrontResult.domainName;
      
      console.log(`✅ CloudFront setup complete: ${this.destCloudFrontDomain}`);
      
      return cloudFrontResult;
      
    } catch (error) {
      console.error('❌ CloudFront setup failed:', error);
      throw error;
    }
  }

  // Test connection to both buckets
  async testConnections() {
    try {
      console.log('Testing S3 connections...');
      
      // Test source connection
      await this.s3Source.listObjectsV2({
        Bucket: this.sourceBucket,
        MaxKeys: 1
      }).promise();
      console.log('✅ Source S3 connection successful');
      
      // Test destination connection
      await this.s3Dest.listObjectsV2({
        Bucket: this.destBucket,
        MaxKeys: 1
      }).promise();
      console.log('✅ Destination S3 connection successful');
      
    } catch (error) {
      console.error('❌ S3 connection test failed:', error.message);
      throw error;
    }
  }

  // Get migration statistics
  async getMigrationStats() {
    try {
      // Get all S3 objects to estimate total migration size
      const allObjects = await this.listAllS3Objects();
      
      // Filter out folders and calculate total size
      const files = allObjects.filter(obj => !obj.Key.endsWith('/'));
      const folders = [...new Set(allObjects.map(obj => obj.Key.split('/')[0]).filter(Boolean))];
      const totalSize = files.reduce((sum, obj) => sum + (obj.Size || 0), 0);
      
      return {
        totalFiles: files.length,
        estimatedTotalSize: this.formatFileSize(totalSize),
        folders: folders,
        sourceRegion: 'eu-north-1 (Stockholm)',
        sourceBucket: this.sourceBucket,
        destinationRegion: 'af-south-1 (Cape Town)',
        destinationBucket: this.destBucket
      };
      
    } catch (error) {
      console.error('Error getting migration stats:', error);
      throw error;
    }
  }

  // List all objects in source S3 bucket
  async listAllS3Objects(prefix = '') {
    try {
      let allObjects = [];
      let continuationToken = null;
      
      do {
        const params = {
          Bucket: this.sourceBucket,
          Prefix: prefix,
          ContinuationToken: continuationToken
        };
        
        const response = await this.s3Source.listObjectsV2(params).promise();
        
        if (response.Contents) {
          allObjects = allObjects.concat(response.Contents);
        }
        
        continuationToken = response.NextContinuationToken;
        
      } while (continuationToken);
      
      return allObjects;
    } catch (error) {
      console.error('Error listing S3 objects:', error);
      throw error;
    }
  }

  // Migrate ALL files from source S3 bucket
  async migrateAllS3Files(s3Files = null) {
    try {
      console.log('Migrating all files from S3 bucket...');
      
      // Get all objects if not provided
      const allObjects = s3Files || await this.listAllS3Objects();
      const files = allObjects.filter(obj => !obj.Key.endsWith('/'));
      
      console.log(`Found ${files.length} files to migrate`);
      
      const migrationResults = {
        total: 0,
        successful: 0,
        failed: 0,
        details: []
      };
      
      // Migrate each file
      for (const file of files) {
        const result = await this.migrateFile(file.Key);
        migrationResults.total++;
        
        if (result.success) {
          migrationResults.successful++;
        } else {
          migrationResults.failed++;
        }
        
        migrationResults.details.push(result);
        
        // Progress logging
        if (migrationResults.total % 10 === 0) {
          console.log(`Progress: ${migrationResults.total}/${files.length} files processed`);
        }
      }
      
      console.log('S3 files migration completed!');
      console.log(`Results: ${migrationResults.successful} successful, ${migrationResults.failed} failed`);
      
      return migrationResults;
      
    } catch (error) {
      console.error('Error migrating S3 files:', error);
      throw error;
    }
  }

  // Migrate a single file
  async migrateFile(sourceKey) {
    const fileResult = {
      sourceKey,
      destKey: sourceKey,
      success: false,
      error: null,
      size: 0
    };
    
    try {
      // Skip if it's a folder
      if (sourceKey.endsWith('/')) {
        fileResult.success = true;
        fileResult.skipped = true;
        return fileResult;
      }
      
      // Check if file exists in source
      const headResponse = await this.s3Source.headObject({
        Bucket: this.sourceBucket,
        Key: sourceKey
      }).promise();
      
      fileResult.size = headResponse.ContentLength;
      
      // Copy file to destination
      await this.s3Dest.copyObject({
        Bucket: this.destBucket,
        Key: sourceKey,
        CopySource: `${this.sourceBucket}/${sourceKey}`,
        MetadataDirective: 'COPY',
        TaggingDirective: 'COPY'
      }).promise();
      
      fileResult.success = true;
      console.log(`✅ Migrated: ${sourceKey} (${this.formatFileSize(fileResult.size)})`);
      
    } catch (error) {
      console.error(`❌ Failed to migrate: ${sourceKey}`, error.message);
      fileResult.error = error.message;
    }
    
    return fileResult;
  }

  // Format file size for logging
  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Quick verification of migrated files
  async quickVerification(sampleSize = 5) {
    try {
      console.log('Performing quick file verification...');
      
      const allObjects = await this.listAllS3Objects();
      const files = allObjects.filter(obj => !obj.Key.endsWith('/'));
      const sampleFiles = files.slice(0, Math.min(sampleSize, files.length));
      
      let verified = 0;
      
      for (const file of sampleFiles) {
        const isVerified = await this.verifyFile(file.Key);
        if (isVerified) verified++;
      }
      
      console.log(`✅ Quick verification: ${verified}/${sampleFiles.length} files verified`);
      return { verified, total: sampleFiles.length };
      
    } catch (error) {
      console.error('Error during verification:', error);
      return { verified: 0, total: 0 };
    }
  }

  // Verify a single file
  async verifyFile(key) {
    try {
      // Skip folders
      if (key.endsWith('/')) return true;
      
      // Get source file info
      const sourceHead = await this.s3Source.headObject({
        Bucket: this.sourceBucket,
        Key: key
      }).promise();
      
      // Get destination file info
      const destHead = await this.s3Dest.headObject({
        Bucket: this.destBucket,
        Key: key
      }).promise();
      
      // Compare size and ETag
      return sourceHead.ContentLength === destHead.ContentLength &&
             sourceHead.ETag === destHead.ETag;
             
    } catch (error) {
      console.error(`Verification failed for ${key}:`, error.message);
      return false;
    }
  }

  // Individual migration methods if needed separately
  async migrateOnlyFiles() {
    try {
      console.log('🔄 Migrating only S3 files (no database changes)...');
      
      await this.testConnections();
      const stats = await this.getMigrationStats();
      const results = await this.migrateAllS3Files();
      
      console.log(`✅ File migration completed: ${results.successful}/${results.total} files`);
      return results;
      
    } catch (error) {
      console.error('Error in file-only migration:', error);
      throw error;
    }
  }

  async populateOnlyDatabase() {
    try {
      console.log('🗃️ Populating only database (assumes files already migrated)...');
      
      if (!this.destCloudFrontDomain) {
        await this.setupCloudFront();
      }
      
      const s3Files = await this.listAllS3Objects();
      const results = await databasePopulationService.populateDatabaseFromS3(
        s3Files, 
        this.destCloudFrontDomain
      );
      
      console.log(`✅ Database population completed: ${results.createdCount} lessons`);
      return results;
      
    } catch (error) {
      console.error('Error in database-only population:', error);
      throw error;
    }
  }
}

export default new CompleteMigrationService();