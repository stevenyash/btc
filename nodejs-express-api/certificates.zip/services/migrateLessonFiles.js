// scripts/migrateLessonFiles.js
import lessonFilesMigrationService from '../services/lessonFilesMigrationService.js';

async function runLessonFilesMigration() {
  try {
    console.log('🚀 Starting Lesson Files Migration');
    console.log('=================================');
    console.log('Source: eu-north-1 (Stockholm)');
    console.log('Destination: af-south-1 (Cape Town)');
    console.log('Bucket: tutorconnect-videos-af');
    console.log('=================================\n');
    
    // Step 1: Get migration statistics
    console.log('📊 Step 1: Gathering migration statistics...');
    const stats = await lessonFilesMigrationService.getMigrationStats();
    console.log('Migration Overview:');
    console.log(`- Lessons to migrate: ${stats.totalLessons}`);
    console.log(`- Total files: ${stats.totalFiles}`);
    console.log(`- Estimated size: ${stats.estimatedTotalSize}`);
    console.log(`- Destination: ${stats.destinationBucket} in ${stats.destinationRegion}`);
    
    // Confirm before proceeding
    console.log('\n⚠️  Are you sure you want to proceed? This will copy all lesson files to the new region.');
    console.log('Press Ctrl+C to cancel, or wait 10 seconds to continue...');
    
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    // Step 2: Run migration
    console.log('\n🔄 Step 2: Starting file migration...');
    const migrationResults = await lessonFilesMigrationService.migrateAllLessonFiles();
    
    // Step 3: Verify migration
    console.log('\n✅ Step 3: Verifying migration...');
    const verificationResults = await lessonFilesMigrationService.verifyLessonFilesMigration();
    
    // Final report
    console.log('\n🎉 MIGRATION COMPLETED!');
    console.log('======================');
    console.log(`Files migrated: ${migrationResults.successful}/${migrationResults.total} lessons successful`);
    console.log(`Verification: ${verificationResults.successful}/${verificationResults.total} lessons fully verified`);
    
    if (migrationResults.failed > 0) {
      console.log(`\n❌ ${migrationResults.failed} lessons had issues:`);
      migrationResults.details
        .filter(r => !r.success)
        .forEach(failed => {
          console.log(`   - Lesson ${failed.lessonId}: ${failed.lessonTitle}`);
          console.log(`     Errors: ${failed.errors.join(', ')}`);
        });
    }
    
  } catch (error) {
    console.error('\n💥 Migration failed:', error);
    process.exit(1);
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runLessonFilesMigration();
}

export { runLessonFilesMigration };