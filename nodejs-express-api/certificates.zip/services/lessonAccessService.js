import DB from '../models/db.js';

export class LessonAccessService {
    /**
     * Validate guest subscription access using ONLY LessonAccessLogs
     */
    async validateGuestSubscriptionAccess(phone, lesson_id = null) {
        const now = new Date();
        
        const whereClause = { 
            phone: phone,
            status: 'active',
            expires_at: { [DB.op.gt]: now }
        };
        
        if (lesson_id) {
            whereClause.lesson_id = lesson_id;
        }
        
        const activeSession = await DB.LessonAccessLogs.findOne({ 
            where: whereClause,
            order: [['created_at', 'DESC']]
        });
        
        if (!activeSession) {
            return { 
                valid: false, 
                reason: 'No active guest access found',
                code: 'NO_ACCESS'
            };
        }
        
        return { 
            valid: true, 
            activeSession: activeSession,
            type: 'guest',
            views_remaining: 'infinite',
            canResumeSession: true
        };
    }

    /**
     * Validate non-guest subscription access
     */
    async validateNonGuestSubscriptionAccess(user_id) {
        const now = new Date();
        
        // Check for active session in LessonAccessLogs first
        const activeSession = await DB.LessonAccessLogs.findOne({
            where: {
                user_id: user_id,
                status: 'active',
                expires_at: { [DB.op.gt]: now }
            },
            order: [['created_at', 'DESC']]
        });
        console.log("activeSession",activeSession)
        if (activeSession) {
            return { 
                valid: true, 
                activeSession: activeSession,
                type: 'subscriber',
                canResumeSession: true
            };
        }
        
        // If no active session, check subscription status
        const subscription = await DB.LessonTrack.findOne({
            where: {
                user_id: user_id,
                status: 'active'
            },
            include: [
                {
                    model: DB.Subscriptions,
                    as: 'subscription',
                    attributes: ['id', 'expiry_date', 'status', 'start_date']
                }
            ],
            order: [['created_at', 'DESC']]
        });
        console.log("in service",subscription)
        if (!subscription) {
            return { 
                valid: false, 
                reason: 'No active subscription found',
                code: 'NO_SUBSCRIPTION'
            };
        }
        
        // Check parent subscription expiration
        if (subscription.subscription) {
            const subExpiresAt = new Date(subscription.subscription.expires_at);
            if (subExpiresAt < now) {
                await DB.LessonTrack.update(
                    { status: 'expired' },
                    { where: { id: subscription.id } }
                );
                return { 
                    valid: false, 
                    reason: 'Subscription has expired',
                    code: 'SUBSCRIPTION_EXPIRED'
                };
            }
            
            if (subscription.subscription.status !== 'active') {
                return { 
                    valid: false, 
                    reason: `Subscription is ${subscription.subscription.status}`,
                    code: 'SUBSCRIPTION_INACTIVE'
                };
            }
        }
        
        // Check lesson balance
        if (subscription.lesson_balance <= 0) {
            await DB.LessonTrack.update(
                { status: 'exhausted' },
                { where: { id: subscription.id } }
            );
            return { 
                valid: false, 
                reason: 'No lesson balance available',
                code: 'BALANCE_EXHAUSTED'
            };
        }
        
        return { 
            valid: true, 
            subscription: subscription,
            type: 'subscriber',
            canResumeSession: false,
            lesson_balance: subscription.lesson_balance,
            no_of_lessons: subscription.no_of_lessons, // FIXED: Use no_of_lessons
            lessons_viewed: subscription.lessons_viewed
        };
    }

    /**
     * Create or update lesson access log
     */
    async createOrUpdateAccessLog(accessData, existingSession = null) {
        const now = new Date();
        
        if (existingSession) {
            // Update existing session
            return await DB.LessonAccessLogs.update({
                accessed_at: now,
                ip_address: accessData.ip_address,
                user_agent: accessData.user_agent
            }, {
                where: { id: existingSession.id }
            });
        } else {
            // Create new access log entry
            return await DB.LessonAccessLogs.create({
                user_id: accessData.user_id,
                phone: accessData.phone,
                lesson_id: accessData.lesson_id,
                access_type: accessData.access_type,
                ip_address: accessData.ip_address,
                user_agent: accessData.user_agent,
                session_id: accessData.session_id,
                expires_at: accessData.expires_at,
                accessed_at: now,
                lesson_setting_id: accessData.lesson_setting_id,
                status: 'active'
            });
        }
    }

    /**
     * Mark session as completed or expired
     */
    async completeSession(sessionId, completionData = {}) {
        const { status = 'completed', watch_time = 0, completion_percentage = 0 } = completionData;

        // Update the access log
        const updated = await DB.LessonAccessLogs.update(
            {
                status: status,
                watch_time: watch_time,
                completion_percentage: completion_percentage,
                completed_at: new Date()
            },
            {
                where: { session_id: sessionId }
            }
        );

        if (updated[0] === 0) {
            throw new Error('Session not found');
        }

        // If session expired naturally, check if we need to update tracker status
        if (status === 'expired') {
            const accessLog = await DB.LessonAccessLogs.findOne({
                where: { session_id: sessionId }
            });

            if (accessLog && accessLog.lesson_track_id) {
                const lessonTrack = await DB.LessonTrack.findByPk(accessLog.lesson_track_id);
                if (lessonTrack && lessonTrack.lesson_balance <= 0) {
                    await DB.LessonTrack.update(
                        { status: 'exhausted' },
                        { where: { id: lessonTrack.id } }
                    );
                }
            }
        }

        return { success: true, message: `Session marked as ${status}` };
    }
}