// services/databasePopulationService.js
import DB from '../models/db.js';

class DatabasePopulationService {
  
  // Map folder names to database hierarchy
  getFolderToHierarchyMap() {
    return {
      // Junior Secondary (Grade 6-9)
      'Grade 7 Maths': { 
        level_name: 'Junior Secondary', 
        grade_name: 'Grade 7', 
        area_name: 'Mathematics' 
      },
      'Grade 8 Business': { 
        level_name: 'Junior Secondary', 
        grade_name: 'Grade 8', 
        area_name: 'Business Studies' 
      },
      'Grade 8 Kiswahili': { 
        level_name: 'Junior Secondary', 
        grade_name: 'Grade 8', 
        area_name: 'Kiswahili' 
      },
      
      // Senior Secondary (Form 1-4)
      'Form 3 Biology': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3', 
        area_name: 'Biology' 
      },
      'Form 3 Chemistry': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3', 
        area_name: 'Chemistry' 
      },
      'Form 3 Kiswahili': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3', 
        area_name: 'Kiswahili' 
      },
      'Form 3 Maths': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3', 
        area_name: 'Mathematics' 
      },
      'Form 3 Physics': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3', 
        area_name: 'Physics' 
      },
      'Form 4 Biology': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 4', 
        area_name: 'Biology' 
      },
      'Form 4 Chemistry': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 4', 
        area_name: 'Chemistry' 
      },
      'Form 4 Maths': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 4', 
        area_name: 'Mathematics' 
      },
      'Form 4 Physics': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 4', 
        area_name: 'Physics' 
      },
      'Form 3 4 Kiswahili': { 
        level_name: 'Senior Secondary', 
        grade_name: 'Form 3 & 4', 
        area_name: 'Kiswahili' 
      },
      
      // General/BTC Lessons
      'BTC Lessons': { 
        level_name: 'General', 
        grade_name: 'All Grades', 
        area_name: 'General Education' 
      }
    };
  }

  // Check if hierarchy levels already exist in database
  async checkExistingHierarchy() {
    try {
      console.log('🔍 Checking existing database hierarchy...');
      
      const levels = await DB.LearningLevels.findAll({ raw: true });
      const grades = await DB.Grades.findAll({ raw: true });
      const areas = await DB.LearningAreas.findAll({ raw: true });
      const topics = await DB.Topics.findAll({ raw: true });
      const subtopics = await DB.Subtopics.findAll({ raw: true });
      const lessons = await DB.Lessons.count();
      
      console.log('📊 Existing Database Structure:');
      console.log(`- Learning Levels: ${levels.length}`);
      console.log(`- Grades: ${grades.length}`);
      console.log(`- Learning Areas: ${areas.length}`);
      console.log(`- Topics: ${topics.length}`);
      console.log(`- Subtopics: ${subtopics.length}`);
      console.log(`- Lessons: ${lessons}`);
      
      return { levels, grades, areas, topics, subtopics, lessons };
      
    } catch (error) {
      console.error('Error checking existing hierarchy:', error);
      throw error;
    }
  }

  // Create database entries for all lessons
  async populateDatabaseFromS3(s3Files, cloudFrontDomain) {
    try {
      console.log('🗃️ Populating database from S3 files...');
      
      // First check what already exists
      const existing = await this.checkExistingHierarchy();
      
      const folderMap = this.getFolderToHierarchyMap();
      let createdCount = 0;
      
      // Group files by folder
      const filesByFolder = this.groupFilesByFolder(s3Files);
      
      console.log('\n📁 Processing S3 Folders:');
      for (const [folderName, files] of Object.entries(filesByFolder)) {
        const hierarchy = folderMap[folderName];
        
        if (!hierarchy) {
          console.log(`⚠️  No hierarchy mapping for folder: ${folderName}`);
          continue;
        }
        
        console.log(`\n📂 Processing ${folderName}: ${files.length} files`);
        console.log(`   → Level: ${hierarchy.level_name}, Grade: ${hierarchy.grade_name}, Area: ${hierarchy.area_name}`);
        
        // Get or create hierarchy entities
        const level = await this.getOrCreateLevel(hierarchy.level_name);
        const grade = await this.getOrCreateGrade(hierarchy.grade_name, level.level_id);
        const area = await this.getOrCreateArea(hierarchy.area_name, grade.id);
        
        // Create lessons for each file in this folder
        for (const file of files) {
          await this.createLessonFromFile(file, area, cloudFrontDomain);
          createdCount++;
        }
        
        console.log(`   ✅ Created ${files.length} lessons`);
      }
      
      console.log(`\n🎉 Database population completed: ${createdCount} lessons created`);
      return { success: true, createdCount };
      
    } catch (error) {
      console.error('Error populating database:', error);
      throw error;
    }
  }

  // Group S3 files by folder
  groupFilesByFolder(s3Files) {
    const filesByFolder = {};
    
    s3Files.forEach(file => {
      if (file.Key.endsWith('/')) return; // Skip folders
      
      const folder = file.Key.split('/')[0];
      if (!filesByFolder[folder]) {
        filesByFolder[folder] = [];
      }
      filesByFolder[folder].push(file);
    });
    
    return filesByFolder;
  }

  // Get or create learning level
  async getOrCreateLevel(levelName) {
    let level = await DB.LearningLevels.findOne({
      where: { name: levelName }
    });
    
    if (!level) {
      level = await DB.LearningLevels.create({
        name: levelName,
        description: `${levelName} Level`,
        sort_order: await this.getNextSortOrder(DB.LearningLevels),
        is_active: true
      });
      console.log(`   ✅ Created new level: ${levelName}`);
    } else {
      console.log(`   ✅ Using existing level: ${levelName}`);
    }
    
    return level;
  }

  // Get or create grade
  async getOrCreateGrade(gradeName, levelId) {
    let grade = await DB.Grades.findOne({
      where: { 
        name: gradeName,
        level_id: levelId
      }
    });
    
    if (!grade) {
      grade = await DB.Grades.create({
        name: gradeName,
        description: `${gradeName} Grade`,
        level_id: levelId,
        sort_order: await this.getNextSortOrder(DB.Grades),
        is_active: true
      });
      console.log(`   ✅ Created new grade: ${gradeName}`);
    } else {
      console.log(`   ✅ Using existing grade: ${gradeName}`);
    }
    
    return grade;
  }

  // Get or create learning area
  async getOrCreateArea(areaName, gradeId) {
    let area = await DB.LearningAreas.findOne({
      where: { 
        name: areaName,
        grade_id: gradeId
      }
    });
    
    if (!area) {
      area = await DB.LearningAreas.create({
        name: areaName,
        description: `${areaName} Learning Area`,
        grade_id: gradeId,
        color: this.getRandomColor(),
        icon: 'book',
        is_active: true
      });
      console.log(`   ✅ Created new area: ${areaName}`);
    } else {
      console.log(`   ✅ Using existing area: ${areaName}`);
    }
    
    return area;
  }

  // Get or create topic and subtopic
  async getOrCreateTopicAndSubtopic(areaId, filename) {
    // Extract topic and subtopic from filename
    const { topicName, subtopicName } = this.extractTopicAndSubtopic(filename);
    
    // Get or create topic
    let topic = await DB.Topics.findOne({
      where: { 
        name: topicName,
        area_id: areaId
      }
    });
    
    if (!topic) {
      topic = await DB.Topics.create({
        name: topicName,
        area_id: areaId
      });
    }
    
    // Get or create subtopic
    let subtopic = await DB.Subtopics.findOne({
      where: { 
        name: subtopicName,
        topic_id: topic.topic_id
      }
    });
    
    if (!subtopic) {
      subtopic = await DB.Subtopics.create({
        name: subtopicName,
        topic_id: topic.topic_id
      });
    }
    
    return { topic, subtopic };
  }

  // Extract topic and subtopic from filename
  extractTopicAndSubtopic(filename) {
    // Example: "Form 3 4 Kiswahili - Maigizo - Drama.mp4"
    // → Topic: "Maigizo", Subtopic: "Drama"
    
    const cleanName = filename.replace('.mp4', '');
    const parts = cleanName.split(' - ');
    
    let topicName = 'General';
    let subtopicName = 'Introduction';
    
    if (parts.length >= 3) {
      // Format: "Folder - Topic - Subtopic"
      topicName = parts[1] || 'General';
      subtopicName = parts[2] || 'Introduction';
    } else if (parts.length === 2) {
      // Format: "Folder - Topic"
      topicName = parts[1] || 'General';
      subtopicName = 'Introduction';
    } else {
      // Format: just filename
      topicName = cleanName;
      subtopicName = 'Introduction';
    }
    
    return { topicName, subtopicName };
  }

  // Create lesson from S3 file
  async createLessonFromFile(s3File, area, cloudFrontDomain) {
    try {
      const s3Key = s3File.Key;
      const filename = s3Key.split('/').pop();
      
      // Extract topic and subtopic from filename
      const { topicName, subtopicName } = this.extractTopicAndSubtopic(filename);
      const { topic, subtopic } = await this.getOrCreateTopicAndSubtopic(area.id, filename);
      
      // Generate title and description
      const title = topicName;
      const description = subtopicName;
      
      // Check if lesson already exists
      const existingLesson = await DB.Lessons.findOne({
        where: { s3_key: s3Key }
      });
      
      if (existingLesson) {
        console.log(`   ⚠️  Lesson already exists: ${title} - ${description}`);
        return existingLesson;
      }
      
      const lessonData = {
        area_id: area.id,
        topic_id: topic.topic_id,
        subtopic_id: subtopic.subtopic_id,
        title: title,
        description: description,
        s3_key: s3Key,
        s3_url: `${cloudFrontDomain}/${s3Key}`,
        file: filename,
        filename: filename,
        file_size: s3File.Size || 0,
        duration: 0, // Can be updated later from video metadata
        thumbnail_url: this.generateThumbnailUrl(s3Key, cloudFrontDomain),
        price: 0.00,
        is_preview_available: false,
        preview_duration: 0,
        sort_order: await this.getNextLessonSortOrder(area.id),
        is_active: true
      };
      
      const lesson = await DB.Lessons.create(lessonData);
      console.log(`   ✅ Created lesson: ${title} - ${description}`);
      return lesson;
      
    } catch (error) {
      console.error(`Error creating lesson for file ${s3File.Key}:`, error);
      throw error;
    }
  }

  // Generate thumbnail URL (placeholder - you can add actual thumbnails later)
  generateThumbnailUrl(s3Key, cloudFrontDomain) {
    // For now, return null - you can implement thumbnail generation later
    return null;
  }

  // Get next sort order for a model
  async getNextSortOrder(Model) {
    const lastItem = await Model.findOne({
      order: [['sort_order', 'DESC']]
    });
    
    return (lastItem?.sort_order || 0) + 1;
  }

  // Get next lesson sort order for an area
  async getNextLessonSortOrder(areaId) {
    const lastLesson = await DB.Lessons.findOne({
      where: { area_id: areaId },
      order: [['sort_order', 'DESC']]
    });
    
    return (lastLesson?.sort_order || 0) + 1;
  }

  // Get random color for learning area
  getRandomColor() {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  // Verify database population
  async verifyPopulation() {
    try {
      const totalLessons = await DB.Lessons.count();
      const lessonsWithFiles = await DB.Lessons.count({
        where: { s3_key: { [DB.Op.ne]: null } }
      });
      
      const levels = await DB.LearningLevels.count();
      const grades = await DB.Grades.count();
      const areas = await DB.LearningAreas.count();
      const topics = await DB.Topics.count();
      const subtopics = await DB.Subtopics.count();
      
      console.log('\n📊 FINAL DATABASE VERIFICATION:');
      console.log('=============================');
      console.log(`🏫 Learning Levels: ${levels}`);
      console.log(`📚 Grades: ${grades}`);
      console.log(`📖 Learning Areas: ${areas}`);
      console.log(`📝 Topics: ${topics}`);
      console.log(`📄 Subtopics: ${subtopics}`);
      console.log(`🎓 Lessons: ${totalLessons}`);
      console.log(`📹 Lessons with S3 files: ${lessonsWithFiles}`);
      
      // Show sample of created lessons
      const sampleLessons = await DB.Lessons.findAll({
        include: [
          { model: DB.LearningAreas, as: 'area' },
          { model: DB.Topics, as: 'topic' },
          { model: DB.Subtopics, as: 'subtopic' }
        ],
        limit: 5,
        order: [['id', 'ASC']]
      });
      
      console.log('\n📋 Sample Lessons Created:');
      sampleLessons.forEach(lesson => {
        console.log(`   - ${lesson.title} → ${lesson.description}`);
        console.log(`     Area: ${lesson.area?.name}, Topic: ${lesson.topic?.name}, Subtopic: ${lesson.subtopic?.name}`);
      });
      
      return { 
        levels, 
        grades, 
        areas, 
        topics,
        subtopics,
        totalLessons, 
        lessonsWithFiles 
      };
      
    } catch (error) {
      console.error('Error verifying population:', error);
      throw error;
    }
  }
}

export default new DatabasePopulationService();