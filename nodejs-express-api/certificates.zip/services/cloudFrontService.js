// services/cloudFrontService.js
import AWS from 'aws-sdk';

class CloudFrontService {
  constructor() {
    this.cloudfront = new AWS.CloudFront({
      region: 'us-east-1',
      accessKeyId: "AKIAXWHDMCUQNG6SNQMS",
      secretAccessKey: "710hBsCQX6rIEI8h0TAP4BVQXGKwE4J6WvxTxjbW"
    });
  }

  // Check if distribution already exists for Africa bucket
  async getExistingDistribution() {
    try {
      const result = await this.cloudfront.listDistributions().promise();
      
      if (!result.DistributionList.Items) {
        return null;
      }

      // Look for distribution that points to our Africa bucket
      const africaDistribution = result.DistributionList.Items.find(dist => {
        return dist.Origins.Items.some(origin => 
          origin.DomainName === 'tutorconnect-videos-af.s3.af-south-1.amazonaws.com'
        );
      });

      return africaDistribution || null;
    } catch (error) {
      console.error('Error checking existing distributions:', error);
      return null;
    }
  }

  // Create new CloudFront distribution for Africa bucket
  async createAfricaDistribution() {
    try {
      const params = {
        DistributionConfig: {
          CallerReference: `tutorconnect-af-${Date.now()}`,
          Comment: 'CloudFront for TutorConnect Africa videos (Cape Town)',
          Origins: {
            Quantity: 1,
            Items: [
              {
                Id: 'tutorconnect-af-south-1',
                DomainName: 'tutorconnect-videos-af.s3.af-south-1.amazonaws.com',
                S3OriginConfig: {
                  OriginAccessIdentity: ''
                }
              }
            ]
          },
          DefaultCacheBehavior: {
            TargetOriginId: 'tutorconnect-af-south-1',
            ViewerProtocolPolicy: 'redirect-to-https',
            TrustedSigners: {
              Enabled: false,
              Quantity: 0
            },
            ForwardedValues: {
              QueryString: false,
              Cookies: { Forward: 'none' },
              Headers: { Quantity: 0 }
            },
            MinTTL: 0,
            Compress: true,
            DefaultTTL: 86400,
            MaxTTL: 31536000
          },
          Enabled: true,
          PriceClass: 'PriceClass_200' // Africa, Middle East, Europe
        }
      };

      const result = await this.cloudfront.createDistribution(params).promise();
      
      console.log('✅ Created new CloudFront distribution for Africa bucket');
      console.log(`🌐 Domain: ${result.Distribution.DomainName}`);
      console.log(`📦 Distribution ID: ${result.Distribution.Id}`);
      
      return {
        distributionId: result.Distribution.Id,
        domainName: result.Distribution.DomainName,
        status: result.Distribution.Status
      };
      
    } catch (error) {
      console.error('Error creating CloudFront distribution:', error);
      throw error;
    }
  }

  // Update existing distribution (if we need to modify it)
  async updateDistribution(distributionId, updates = {}) {
    try {
      // First get the current distribution config
      const current = await this.cloudfront.getDistributionConfig({
        Id: distributionId
      }).promise();

      const config = current.DistributionConfig;
      
      // Apply updates
      if (updates.comment) {
        config.Comment = updates.comment;
      }
      
      if (updates.enabled !== undefined) {
        config.Enabled = updates.enabled;
      }
      
      if (updates.priceClass) {
        config.PriceClass = updates.priceClass;
      }

      // Update the distribution
      const result = await this.cloudfront.updateDistribution({
        Id: distributionId,
        IfMatch: current.ETag,
        DistributionConfig: config
      }).promise();

      console.log('✅ Updated CloudFront distribution');
      return result.Distribution;

    } catch (error) {
      console.error('Error updating CloudFront distribution:', error);
      throw error;
    }
  }

  // Main method to ensure Africa bucket has CloudFront
  async setupAfricaCloudFront() {
    try {
      console.log('Setting up CloudFront for Africa bucket...');
      
      // Check if distribution already exists
      const existing = await this.getExistingDistribution();
      
      if (existing) {
        console.log('✅ CloudFront distribution already exists for Africa bucket');
        console.log(`🌐 Domain: ${existing.DomainName}`);
        console.log(`📦 Distribution ID: ${existing.Id}`);
        console.log(`📊 Status: ${existing.Status}`);
        
        return {
          distributionId: existing.Id,
          domainName: existing.DomainName,
          status: existing.Status,
          action: 'existing'
        };
      } else {
        console.log('No existing CloudFront found for Africa bucket, creating new one...');
        const newDistribution = await this.createAfricaDistribution();
        return {
          ...newDistribution,
          action: 'created'
        };
      }
      
    } catch (error) {
      console.error('Error setting up CloudFront:', error);
      throw error;
    }
  }

  // Wait for distribution to deploy (useful after creation/update)
  async waitForDeployment(distributionId, maxWaitMinutes = 30) {
    console.log('⏳ Waiting for CloudFront deployment...');
    
    const startTime = Date.now();
    const maxWaitTime = maxWaitMinutes * 60 * 1000;
    
    while (Date.now() - startTime < maxWaitTime) {
      try {
        const distribution = await this.cloudfront.getDistribution({
          Id: distributionId
        }).promise();
        
        if (distribution.Distribution.Status === 'Deployed') {
          console.log('✅ CloudFront distribution deployed and ready!');
          return true;
        }
        
        const elapsed = Math.floor((Date.now() - startTime) / 1000);
        console.log(`⏳ Still deploying... (${elapsed}s elapsed)`);
        await new Promise(resolve => setTimeout(resolve, 30000)); // Wait 30 seconds
        
      } catch (error) {
        console.error('Error checking deployment status:', error);
        return false;
      }
    }
    
    console.log('⚠️  Deployment taking longer than expected...');
    return false;
  }
}

export default new CloudFrontService();