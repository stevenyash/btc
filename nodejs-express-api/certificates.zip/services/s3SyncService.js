// services/s3SyncService.js
import s3CloudFrontService from './s3CloudFrontService.js';
import learningHierarchyService from './learningHierarchyService.js';
import DB from '../models/db.js';

class S3SyncService {
  
  // Sync complete learning hierarchy with S3
  async syncLearningHierarchy() {
    try {
      console.log('Starting learning hierarchy sync with S3...');
      
      const hierarchy = await learningHierarchyService.getCompleteHierarchy();
      
      // Create S3 folder structure based on hierarchy
      for (const level of hierarchy) {
        await this.syncLearningLevel(level);
        
        for (const grade of level.grades || []) {
          await this.syncGrade(grade, level);
          
          for (const area of grade.learning_areas || []) {
            await this.syncLearningArea(area, grade, level);
            
            for (const lesson of area.lessons || []) {
              await this.syncLesson(lesson, area, grade, level);
            }
          }
        }
      }
      
      console.log('Learning hierarchy sync completed successfully');
      return { success: true, message: 'Hierarchy synced with S3' };
      
    } catch (error) {
      console.error('Error syncing learning hierarchy:', error);
      throw error;
    }
  }

  // Sync individual learning level
  async syncLearningLevel(level) {
    try {
      const levelFolder = `learning-hierarchy/levels/${level.level_id}`;
      
      // Create level metadata file
      const levelMetadata = {
        id: level.level_id,
        name: level.name,
        description: level.description,
        sort_order: level.sort_order,
        is_active: level.is_active,
        created_at: level.created_at,
        updated_at: level.updated_at,
        type: 'learning_level'
      };
      
      await s3CloudFrontService.uploadJsonToS3(
        `${levelFolder}/metadata.json`,
        levelMetadata
      );
      
      console.log(`Synced level: ${level.name}`);
      return levelMetadata;
      
    } catch (error) {
      console.error(`Error syncing level ${level.level_id}:`, error);
      throw error;
    }
  }

  // Sync grade with S3
  async syncGrade(grade, level) {
    try {
      const gradeFolder = `learning-hierarchy/levels/${level.level_id}/grades/${grade.id}`;
      
      const gradeMetadata = {
        id: grade.id,
        name: grade.name,
        description: grade.description,
        level_id: grade.level_id,
        level_name: level.name,
        sort_order: grade.sort_order,
        is_active: grade.is_active,
        created_at: grade.created_at,
        updated_at: grade.updated_at,
        type: 'grade'
      };
      
      await s3CloudFrontService.uploadJsonToS3(
        `${gradeFolder}/metadata.json`,
        gradeMetadata
      );
      
      console.log(`Synced grade: ${grade.name} (Level: ${level.name})`);
      return gradeMetadata;
      
    } catch (error) {
      console.error(`Error syncing grade ${grade.id}:`, error);
      throw error;
    }
  }

  // Sync learning area with S3
  async syncLearningArea(area, grade, level) {
    try {
      const areaFolder = `learning-hierarchy/levels/${level.level_id}/grades/${grade.id}/areas/${area.id}`;
      
      const areaMetadata = {
        id: area.id,
        name: area.name,
        description: area.description,
        grade_id: area.grade,
        grade_name: grade.name,
        level_id: level.level_id,
        level_name: level.name,
        color: area.color,
        icon: area.icon,
        is_active: area.is_active,
        created_at: area.created_at,
        updated_at: area.updated_at,
        type: 'learning_area'
      };
      
      await s3CloudFrontService.uploadJsonToS3(
        `${areaFolder}/metadata.json`,
        areaMetadata
      );
      
      console.log(`Synced area: ${area.name} (Grade: ${grade.name}, Level: ${level.name})`);
      return areaMetadata;
      
    } catch (error) {
      console.error(`Error syncing area ${area.id}:`, error);
      throw error;
    }
  }

  // Sync lesson with S3
  async syncLesson(lesson, area, grade, level) {
    try {
      const lessonFolder = `learning-hierarchy/levels/${level.level_id}/grades/${grade.id}/areas/${area.id}/lessons/${lesson.id}`;
      
      const lessonMetadata = {
        id: lesson.id,
        title: lesson.title,
        description: lesson.description,
        area_id: lesson.area_id,
        area_name: area.name,
        grade_id: grade.id,
        grade_name: grade.name,
        level_id: level.level_id,
        level_name: level.name,
        s3_key: lesson.s3_key,
        s3_url: lesson.s3_url,
        file_size: lesson.file_size,
        duration: lesson.duration,
        thumbnail_url: lesson.thumbnail_url,
        price: lesson.price,
        is_preview_available: lesson.is_preview_available,
        preview_duration: lesson.preview_duration,
        sort_order: lesson.sort_order,
        is_active: lesson.is_active,
        created_at: lesson.created_at,
        updated_at: lesson.updated_at,
        type: 'lesson'
      };
      
      await s3CloudFrontService.uploadJsonToS3(
        `${lessonFolder}/metadata.json`,
        lessonMetadata
      );
      
      console.log(`Synced lesson: ${lesson.title} (Area: ${area.name})`);
      return lessonMetadata;
      
    } catch (error) {
      console.error(`Error syncing lesson ${lesson.id}:`, error);
      throw error;
    }
  }

  // Get hierarchy from S3 (useful for caching)
  async getHierarchyFromS3() {
    try {
      const hierarchy = {};
      
      // List all levels
      const levelsPrefix = 'learning-hierarchy/levels/';
      const levelFolders = await s3CloudFrontService.listFolders(levelsPrefix);
      
      hierarchy.levels = await Promise.all(
        levelFolders.map(async (levelFolder) => {
          const levelData = await this.getLevelFromS3(levelFolder);
          levelData.grades = await this.getGradesFromS3(levelFolder);
          return levelData;
        })
      );
      
      return hierarchy;
    } catch (error) {
      console.error('Error getting hierarchy from S3:', error);
      throw error;
    }
  }

  async getLevelFromS3(levelFolder) {
    try {
      const metadata = await s3CloudFrontService.getJsonFromS3(`${levelFolder}/metadata.json`);
      return metadata;
    } catch (error) {
      console.error(`Error getting level from S3: ${levelFolder}`, error);
      return null;
    }
  }

  async getGradesFromS3(levelFolder) {
    try {
      const gradesPrefix = `${levelFolder}/grades/`;
      const gradeFolders = await s3CloudFrontService.listFolders(gradesPrefix);
      
      return await Promise.all(
        gradeFolders.map(async (gradeFolder) => {
          const gradeData = await this.getGradeFromS3(gradeFolder);
          gradeData.learning_areas = await this.getLearningAreasFromS3(gradeFolder);
          return gradeData;
        })
      );
    } catch (error) {
      console.error(`Error getting grades from S3: ${levelFolder}`, error);
      return [];
    }
  }

  async getLearningAreasFromS3(gradeFolder) {
    try {
      const areasPrefix = `${gradeFolder}/areas/`;
      const areaFolders = await s3CloudFrontService.listFolders(areasPrefix);
      
      return await Promise.all(
        areaFolders.map(async (areaFolder) => {
          const areaData = await this.getLearningAreaFromS3(areaFolder);
          areaData.lessons = await this.getLessonsFromS3(areaFolder);
          return areaData;
        })
      );
    } catch (error) {
      console.error(`Error getting areas from S3: ${gradeFolder}`, error);
      return [];
    }
  }

  async getLessonsFromS3(areaFolder) {
    try {
      const lessonsPrefix = `${areaFolder}/lessons/`;
      const lessonFolders = await s3CloudFrontService.listFolders(lessonsPrefix);
      
      return await Promise.all(
        lessonFolders.map(async (lessonFolder) => {
          return await this.getLessonFromS3(lessonFolder);
        })
      );
    } catch (error) {
      console.error(`Error getting lessons from S3: ${areaFolder}`, error);
      return [];
    }
  }

  async getGradeFromS3(gradeFolder) {
    try {
      return await s3CloudFrontService.getJsonFromS3(`${gradeFolder}/metadata.json`);
    } catch (error) {
      console.error(`Error getting grade from S3: ${gradeFolder}`, error);
      return null;
    }
  }

  async getLearningAreaFromS3(areaFolder) {
    try {
      return await s3CloudFrontService.getJsonFromS3(`${areaFolder}/metadata.json`);
    } catch (error) {
      console.error(`Error getting area from S3: ${areaFolder}`, error);
      return null;
    }
  }

  async getLessonFromS3(lessonFolder) {
    try {
      return await s3CloudFrontService.getJsonFromS3(`${lessonFolder}/metadata.json`);
    } catch (error) {
      console.error(`Error getting lesson from S3: ${lessonFolder}`, error);
      return null;
    }
  }

  // Clean up orphaned S3 folders (when database records are deleted)
  async cleanupOrphanedS3Folders() {
    try {
      console.log('Cleaning up orphaned S3 folders...');
      
      const dbHierarchy = await learningHierarchyService.getCompleteHierarchy();
      const s3Hierarchy = await this.getHierarchyFromS3();
      
      const orphanedItems = this.findOrphanedItems(dbHierarchy, s3Hierarchy);
      
      for (const orphan of orphanedItems) {
        await s3CloudFrontService.deleteFolder(orphan.s3Path);
        console.log(`Deleted orphaned S3 folder: ${orphan.s3Path}`);
      }
      
      console.log(`Cleanup completed. Removed ${orphanedItems.length} orphaned folders.`);
      return { success: true, removed: orphanedItems.length };
      
    } catch (error) {
      console.error('Error cleaning up orphaned S3 folders:', error);
      throw error;
    }
  }

  findOrphanedItems(dbHierarchy, s3Hierarchy) {
    const orphaned = [];
    
    // Compare levels
    // const dbLevelIds = new Set(dbHierarchy.levels.map(l => l.level_id));
    // for (const s3Level of s3Hierarchy.levels) {
    //   if (!dbLevelIds.has(s3Level.id)) { 

    
    return orphaned;
  }

  // Real-time sync when database changes
  async setupRealtimeSync() {
    // This would set up database triggers or hooks to automatically sync changes
    console.log('Setting up real-time S3 sync...');
    
    // You can implement database triggers here based on your DB system

    //  use your ORM's hooks/events system
    
    return { success: true, message: 'Real-time sync setup completed' };
  }
}

export default new S3SyncService();