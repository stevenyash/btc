// services/s3CloudFrontService.js
import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand, ListObjectsV2Command, CopyObjectCommand, HeadBucketCommand } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import config from '../config.js';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

class S3CloudFrontService {
  constructor() {
    this.s3 = new S3Client({
      credentials: {
        accessKeyId: config.s3.accessKeyId,
        secretAccessKey: config.s3.secretAccessKey,
      },
      region: config.s3.region,
    });
    this.bucket = config.s3.bucket;
    this.cloudFrontDomain = config.s3.cloudFront;
    
    // Local storage for caching (minimizes AWS requests)
    this.localCache = new Map();
    this.tokenStore = new Map();
    this.accessLogs = [];
    this.securityEvents = [];
    this.videoMetadataCache = new Map();
    
    // Cache statistics
    this.cacheStats = {
      hits: 0,
      misses: 0,
      sets: 0
    };
    
    this.securityConfig = {
      defaultExpiry: 7200, // 2 hours
      maxPlaysPerToken: 3,
      tokenCleanupInterval: 3600000, // 1 hour
      cacheTTL: 300000, // 5 minutes
      maxCacheSize: 1000,
      maxLogSize: 10000,
      batchFlushSize: 100,
      batchFlushInterval: 300000 // 5 minutes
    };
    
    // Start cleanup schedulers
    this.startCleanupSchedulers();
  }

  // ==================== LOCAL CACHE MANAGEMENT ====================

  setCache(key, value, ttl = this.securityConfig.cacheTTL) {
    if (this.localCache.size >= this.securityConfig.maxCacheSize) {
      // Remove oldest entry using LRU
      const firstKey = this.localCache.keys().next().value;
      this.localCache.delete(firstKey);
    }
    
    this.localCache.set(key, {
      value,
      expiry: Date.now() + ttl,
      createdAt: Date.now(),
      accessCount: 0
    });
    
    this.cacheStats.sets++;
  }

  getCache(key) {
    const item = this.localCache.get(key);
    if (!item) {
      this.cacheStats.misses++;
      return null;
    }
    
    if (Date.now() > item.expiry) {
      this.localCache.delete(key);
      this.cacheStats.misses++;
      return null;
    }
    
    item.accessCount++;
    item.lastAccessed = Date.now();
    this.cacheStats.hits++;
    return item.value;
  }

  clearCache() {
    this.localCache.clear();
    this.cacheStats = { hits: 0, misses: 0, sets: 0 };
  }

  getCacheStats() {
    const hitRate = this.cacheStats.hits + this.cacheStats.misses > 0 
      ? (this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses)) * 100 
      : 0;
    
    return {
      ...this.cacheStats,
      hitRate: hitRate.toFixed(2) + '%',
      size: this.localCache.size,
      maxSize: this.securityConfig.maxCacheSize
    };
  }

  // Token storage in memory (fast access)
  storeToken(tokenId, tokenData) {
    this.tokenStore.set(tokenId, {
      ...tokenData,
      storedAt: Date.now(),
      accessCount: 0
    });
  }

  getToken(tokenId) {
    const token = this.tokenStore.get(tokenId);
    if (!token) return null;
    
    if (Date.now() > token.expiresAt) {
      this.tokenStore.delete(tokenId);
      return null;
    }
    
    token.accessCount++;
    token.lastAccessed = Date.now();
    return token;
  }

  updateToken(tokenId, updates) {
    const token = this.getToken(tokenId);
    if (!token) return null;
    
    const updatedToken = { ...token, ...updates };
    this.tokenStore.set(tokenId, updatedToken);
    
    // Async persistence to S3 for durability
    this.persistTokenToS3(tokenId, updatedToken).catch(console.error);
    
    return updatedToken;
  }

  // ==================== SECURITY FEATURES ====================

  async generateSecureSignedUrl(s3Key, userId, lessonId, options = {}) {
    const cacheKey = `signed_url:${s3Key}:${userId}:${JSON.stringify(options)}`;
    const cached = this.getCache(cacheKey);
    
    if (cached && !options.forceRefresh) {
      await this.logVideoAccess(s3Key, userId, lessonId, 'cached_stream_access');
      return cached;
    }

    const {
      expiresIn = this.securityConfig.defaultExpiry,
      ipAddress = null,
      userAgent = null,
      maxPlays = this.securityConfig.maxPlaysPerToken,
      disableDownload = true
    } = options;

    try {
      // Create access token stored locally
      const tokenId = this.generateVideoAccessToken(s3Key, userId, {
        expiresIn,
        maxPlays,
        ipRestriction: ipAddress,
        userAgentRestriction: userAgent
      });

      // Only AWS call - generate signed URL
      const command = new GetObjectCommand({
        Bucket: this.bucket,
        Key: s3Key,
        ResponseCacheControl: 'no-cache, no-store, must-revalidate',
        ResponseContentDisposition: disableDownload ? 'inline' : 'attachment',
      });

      const signedUrl = await getSignedUrl(this.s3, command, { 
        expiresIn,
      });

      const result = {
        signedUrl,
        tokenId,
        expiresAt: Date.now() + (expiresIn * 1000),
        security: {
          ipRestricted: !!ipAddress,
          userAgentRestricted: !!userAgent,
          maxPlays,
          disableDownload
        }
      };

      // Cache the result
      this.setCache(cacheKey, result, expiresIn * 1000);

      await this.logVideoAccess(s3Key, userId, lessonId, 'stream_access', {
        tokenId,
        ipAddress,
        userAgent
      });

      return result;

    } catch (error) {
      console.error('Error generating secure signed URL:', error);
      await this.logSecurityEvent('URL_GENERATION_ERROR', { 
        s3Key, userId, error: error.message 
      });
      throw error;
    }
  }

  generateVideoAccessToken(videoKey, userId, options = {}) {
    const {
      expiresIn = this.securityConfig.defaultExpiry,
      maxPlays = 1,
      ipRestriction = null,
      userAgentRestriction = null
    } = options;

    const tokenId = this.generateTokenId();
    
    const tokenData = {
      videoKey,
      userId,
      expiresAt: Date.now() + (expiresIn * 1000),
      maxPlays,
      plays: 0,
      ip: ipRestriction,
      userAgent: userAgentRestriction,
      tokenId,
      createdAt: new Date().toISOString(),
      lastAccessed: null,
      lastAccessFrom: null
    };

    // Store locally for fast access
    this.storeToken(tokenId, tokenData);

    // Async persistence to S3
    this.persistTokenToS3(tokenId, tokenData).catch(console.error);

    return tokenId;
  }

  async validateVideoAccessToken(tokenId, userId, clientInfo = {}) {
    // Try local storage first (fast)
    let tokenData = this.getToken(tokenId);
    
    // If not found locally, try S3 (slow path)
    if (!tokenData) {
      tokenData = await this.getTokenFromS3(tokenId);
      if (tokenData) {
        this.storeToken(tokenId, tokenData);
      }
    }

    if (!tokenData) {
      await this.logSecurityEvent('INVALID_TOKEN', { tokenId, userId });
      throw new Error('Invalid token');
    }

    // Security validations
    if (Date.now() > tokenData.expiresAt) {
      this.tokenStore.delete(tokenId);
      await this.logSecurityEvent('EXPIRED_TOKEN', { tokenId, userId });
      throw new Error('Token expired');
    }

    if (tokenData.userId !== userId) {
      await this.logSecurityEvent('USER_MISMATCH', { 
        tokenId, userId, expectedUser: tokenData.userId 
      });
      throw new Error('User mismatch');
    }

    if (tokenData.ip && clientInfo.ipAddress && tokenData.ip !== clientInfo.ipAddress) {
      await this.logSecurityEvent('IP_VIOLATION', { 
        tokenId, userId, 
        expectedIp: tokenData.ip, 
        actualIp: clientInfo.ipAddress 
      });
      throw new Error('IP address not allowed');
    }

    if (tokenData.userAgent && clientInfo.userAgent && tokenData.userAgent !== clientInfo.userAgent) {
      await this.logSecurityEvent('USER_AGENT_VIOLATION', { 
        tokenId, userId, 
        expectedUA: tokenData.userAgent, 
        actualUA: clientInfo.userAgent 
      });
      throw new Error('User agent not allowed');
    }

    if (tokenData.plays >= tokenData.maxPlays) {
      await this.logSecurityEvent('MAX_PLAYS_EXCEEDED', { 
        tokenId, userId, 
        maxPlays: tokenData.maxPlays,
        currentPlays: tokenData.plays 
      });
      throw new Error('Maximum plays exceeded');
    }

    // Update token
    tokenData.plays += 1;
    tokenData.lastAccessed = new Date().toISOString();
    tokenData.lastAccessFrom = clientInfo.ipAddress;
    
    this.storeToken(tokenId, tokenData);
    this.persistTokenToS3(tokenId, tokenData).catch(console.error);

    await this.logSecurityEvent('TOKEN_VALIDATED', { 
      tokenId, userId, 
      plays: tokenData.plays,
      videoKey: tokenData.videoKey 
    });

    return tokenData.videoKey;
  }

  // ==================== LOCAL LOGGING SYSTEM ====================

  async logVideoAccess(videoKey, userId, lessonId, action = 'access', metadata = {}) {
    const logEntry = {
      videoKey,
      userId,
      lessonId,
      action,
      timestamp: new Date().toISOString(),
      ip: metadata.ipAddress || 'unknown',
      userAgent: metadata.userAgent || 'unknown',
      tokenId: metadata.tokenId,
      ...metadata
    };

    this.accessLogs.push(logEntry);

    // Batch persistence to reduce AWS requests
    if (this.accessLogs.length >= this.securityConfig.batchFlushSize) {
      await this.flushAccessLogs();
    }

    return true;
  }

  async logSecurityEvent(eventType, details = {}) {
    const event = {
      eventType,
      timestamp: new Date().toISOString(),
      ...details
    };

    this.securityEvents.push(event);
    console.log(`Security Event: ${eventType}`, details);

    if (this.securityEvents.length >= this.securityConfig.batchFlushSize) {
      await this.flushSecurityEvents();
    }
  }

  // ==================== BATCH PERSISTENCE ====================

  async flushAccessLogs() {
    if (this.accessLogs.length === 0) return;

    try {
      const batchId = Date.now();
      const logKey = `security/logs/batch-${batchId}.json`;
      
      await this.uploadJsonToS3(logKey, {
        batchId,
        logs: this.accessLogs,
        count: this.accessLogs.length,
        flushedAt: new Date().toISOString()
      });

      console.log(`Flushed ${this.accessLogs.length} access logs to S3`);
      this.accessLogs = [];
    } catch (error) {
      console.error('Error flushing access logs:', error);
    }
  }

  async flushSecurityEvents() {
    if (this.securityEvents.length === 0) return;

    try {
      const batchId = Date.now();
      const eventKey = `security/events/batch-${batchId}.json`;
      
      await this.uploadJsonToS3(eventKey, {
        batchId,
        events: this.securityEvents,
        count: this.securityEvents.length,
        flushedAt: new Date().toISOString()
      });

      console.log(`Flushed ${this.securityEvents.length} security events to S3`);
      this.securityEvents = [];
    } catch (error) {
      console.error('Error flushing security events:', error);
    }
  }

  async persistTokenToS3(tokenId, tokenData) {
    try {
      const tokenKey = `security/tokens/${tokenId}.json`;
      await this.uploadJsonToS3(tokenKey, tokenData);
    } catch (error) {
      console.error('Error persisting token to S3:', error);
    }
  }

  async getTokenFromS3(tokenId) {
    try {
      const tokenKey = `security/tokens/${tokenId}.json`;
      return await this.getJsonFromS3(tokenKey);
    } catch (error) {
      return null;
    }
  }

  // ==================== CLEANUP SCHEDULERS ====================

  startCleanupSchedulers() {
    // Cleanup expired tokens
    setInterval(() => {
      this.cleanupExpiredTokens().catch(console.error);
    }, this.securityConfig.tokenCleanupInterval);

    // Flush logs periodically
    setInterval(() => {
      this.flushAccessLogs().catch(console.error);
      this.flushSecurityEvents().catch(console.error);
    }, this.securityConfig.batchFlushInterval);

    // Cleanup expired cache
    setInterval(() => {
      this.cleanupExpiredCache().catch(console.error);
    }, 60000);
  }

  async cleanupExpiredTokens() {
    const now = Date.now();
    let cleanedCount = 0;

    for (const [tokenId, token] of this.tokenStore.entries()) {
      if (now > token.expiresAt) {
        this.tokenStore.delete(tokenId);
        cleanedCount++;
      }
    }

    if (cleanedCount > 0) {
      console.log(`Cleaned ${cleanedCount} expired tokens from local storage`);
    }
  }

  async cleanupExpiredCache() {
    const now = Date.now();
    let cleanedCount = 0;

    for (const [key, item] of this.localCache.entries()) {
      if (now > item.expiry) {
        this.localCache.delete(key);
        cleanedCount++;
      }
    }

    if (cleanedCount > 0) {
      console.log(`Cleaned ${cleanedCount} expired cache entries`);
    }
  }

  // ==================== EXISTING S3 METHODS WITH CACHING ====================

  async checkBucketAccess() {
    const cacheKey = 'bucket_access';
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      const command = new HeadBucketCommand({
        Bucket: this.bucket,
      });
      await this.s3.send(command);
      this.setCache(cacheKey, true, 60000); // Cache for 1 minute
      return true;
    } catch (error) {
      console.error('Bucket access error:', error);
      return false;
    }
  }

  async uploadVideo(filePath, fileName, options = {}) {
    const cacheKey = `video_upload:${fileName}`;
    
    try {
      const resolvedFilePath = path.resolve(`assets/${filePath}`);
      console.log('Resolved File Path:', resolvedFilePath);

      if (!fs.existsSync(resolvedFilePath)) {
        throw new Error(`File not found at path: ${resolvedFilePath}`);
      }

      const fileExt = path.extname(fileName);
      const baseName = path.basename(fileName, fileExt);
      const timestamp = Date.now();
      
      let prefix = 'videos';
      if (options.collection && options.collection !== 'videos') {
        const collectionName = this.sanitizeCollectionName(options.collection);
        prefix = `learningareas/${collectionName}`;
      }
      
      const s3Key = `${prefix}/${baseName}-${timestamp}${fileExt}`;

      console.log('Uploading to S3 with key:', s3Key);

      const fileStream = fs.createReadStream(resolvedFilePath);
      
      const upload = new Upload({
        client: this.s3,
        params: {
          Bucket: this.bucket,
          Key: s3Key,
          Body: fileStream,
          ContentType: this.getContentType(fileExt),
          Metadata: {
            title: options.title || baseName,
            description: options.description || '',
            category: options.category || '',
            visibility: options.visibility || 'private',
            securityLevel: options.securityLevel || 'standard',
            uploadedBy: options.userId || 'system',
            uploadTimestamp: timestamp.toString(),
            collection: options.collection && typeof options.collection === 'object' ? JSON.stringify(options.collection) : options.collection,
            ...options.customFields
          }
        }
      });

      const result = await upload.done();

      console.log('Upload successful:', result);
      
      const videoData = {
        id: s3Key,
        key: s3Key,
        url: `${this.cloudFrontDomain}/${s3Key}`,
        secureUrl: null,
        size: fs.statSync(resolvedFilePath).size,
        title: options.title || baseName,
        description: options.description,
        collection: options.collection && typeof options.collection === 'object' ? 'videos' : options.collection,
        security: {
          level: options.securityLevel || 'standard',
          visibility: options.visibility || 'private',
          requiresAuth: (options.visibility || 'private') === 'private'
        },
        metadata: result.Metadata
      };

      // Cache the video metadata
      this.setCache(`video:${s3Key}`, videoData);
      this.setCache(cacheKey, videoData);

      await this.logSecurityEvent('VIDEO_UPLOADED', {
        videoKey: s3Key,
        userId: options.userId,
        size: videoData.size,
        securityLevel: options.securityLevel
      });
      
      return videoData;

    } catch (error) {
      console.error('Error uploading video:', error.message);
      await this.logSecurityEvent('UPLOAD_ERROR', { error: error.message, fileName });
      throw error;
    }
  }

  async uploadVideoFromBuffer(buffer, fileName, options = {}) {
    try {
      const fileExt = path.extname(fileName);
      const baseName = path.basename(fileName, fileExt);
      const timestamp = Date.now();
      
      let prefix = 'videos';
      if (options.collection && options.collection !== 'videos') {
        const collectionName = this.sanitizeCollectionName(options.collection);
        prefix = `learningareas/${collectionName}`;
      }
      
      const s3Key = `${prefix}/${baseName}-${timestamp}${fileExt}`;

      const upload = new Upload({
        client: this.s3,
        params: {
          Bucket: this.bucket,
          Key: s3Key,
          Body: buffer,
          ContentType: this.getContentType(fileExt),
          Metadata: {
            title: options.title || baseName,
            description: options.description || '',
            collection: options.collection && typeof options.collection === 'object' ? JSON.stringify(options.collection) : options.collection,
            ...options.customFields
          }
        }
      });

      const result = await upload.done();

      const videoData = {
        id: s3Key,
        key: s3Key,
        url: `${this.cloudFrontDomain}/${s3Key}`,
        size: buffer.length,
        title: options.title || baseName,
        description: options.description,
        collection: options.collection && typeof options.collection === 'object' ? 'videos' : options.collection,
        metadata: result.Metadata
      };

      this.setCache(`video:${s3Key}`, videoData);

      return videoData;

    } catch (error) {
      console.error('Error uploading video from buffer:', error.message);
      throw error;
    }
  }

  async generateSignedUrl(s3Key, expiresIn = 3600) {
    return this.generateSecureSignedUrl(s3Key, 'system', 'system', { expiresIn });
  }

  async generateCloudFrontUrl(s3Key) {
    return `${this.cloudFrontDomain}/${s3Key}`;
  }

  async getVideo(s3Key) {
    const cacheKey = `video:${s3Key}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      const command = new GetObjectCommand({
        Bucket: this.bucket,
        Key: s3Key,
      });

      const response = await this.s3.send(command);
      
      const videoData = {
        id: s3Key,
        key: s3Key,
        url: `${this.cloudFrontDomain}/${s3Key}`,
        size: response.ContentLength,
        contentType: response.ContentType,
        lastModified: response.LastModified,
        metadata: response.Metadata,
        etag: response.ETag
      };

      this.setCache(cacheKey, videoData, 120000); // Cache for 2 minutes
      return videoData;

    } catch (error) {
      if (error.name === 'NoSuchKey') {
        return null;
      }
      console.error('Error getting video:', error);
      throw error;
    }
  }

  async listVideos(prefix = '', maxKeys = 100) {
    const cacheKey = `video_list:${prefix}:${maxKeys}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    console.log("Listing videos with prefix:", prefix);
    try {
      const command = new ListObjectsV2Command({
        Bucket: this.bucket,
        Prefix: prefix,
        MaxKeys: maxKeys,
      });

      const response = await this.s3.send(command);
      console.log("S3 response for prefix", prefix, ":", {
        keyCount: response.KeyCount,
        contents: response.Contents ? response.Contents.length : 0,
        commonPrefixes: response.CommonPrefixes ? response.CommonPrefixes.length : 0
      });
      
      if (!response.Contents) {
        return [];
      }

      const videos = response.Contents.map(item => ({
        id: item.Key,
        key: item.Key,
        url: `${this.cloudFrontDomain}/${item.Key}`,
        size: item.Size,
        lastModified: item.LastModified,
        etag: item.ETag
      }));

      this.setCache(cacheKey, videos, 300000); // Cache for 5 minutes
      return videos;

    } catch (error) {
      console.error('Error listing videos:', error);
      throw error;
    }
  }

  async deleteVideo(s3Key, userId = 'system') {
    try {
      const command = new DeleteObjectCommand({
        Bucket: this.bucket,
        Key: s3Key,
      });

      await this.s3.send(command);
      
      // Clear cache
      this.localCache.delete(`video:${s3Key}`);
      
      await this.logSecurityEvent('VIDEO_DELETED', {
        videoKey: s3Key,
        userId
      });

      return {
        success: true,
        message: `Video ${s3Key} deleted successfully`
      };

    } catch (error) {
      console.error('Error deleting video:', error);
      await this.logSecurityEvent('DELETE_ERROR', { videoKey: s3Key, error: error.message });
      throw error;
    }
  }

  async updateVideo(s3Key, updates) {
    try {
      const sourceVideo = await this.getVideo(s3Key);
      if (!sourceVideo) {
        throw new Error('Video not found');
      }

      const newMetadata = {
        ...sourceVideo.metadata,
        ...updates,
        lastUpdated: Date.now().toString()
      };

      const copyCommand = new CopyObjectCommand({
        Bucket: this.bucket,
        CopySource: `${this.bucket}/${s3Key}`,
        Key: s3Key,
        Metadata: newMetadata,
        MetadataDirective: 'REPLACE',
      });

      await this.s3.send(copyCommand);

      // Clear cache
      this.localCache.delete(`video:${s3Key}`);

      return {
        id: s3Key,
        key: s3Key,
        url: `${this.cloudFrontDomain}/${s3Key}`,
        metadata: newMetadata
      };

    } catch (error) {
      console.error('Error updating video:', error);
      throw error;
    }
  }

  // ==================== COLLECTION MANAGEMENT ====================

  async createCollection(collectionData, metadata = {}) {
    try {
      let collectionName;
      
      if (typeof collectionData === 'string') {
        collectionName = this.sanitizeCollectionName(collectionData);
      } else if (collectionData && typeof collectionData === 'object') {
        collectionName = this.sanitizeCollectionName(collectionData.name || collectionData.title || collectionData.id || 'default_collection');
      } else {
        throw new Error('Invalid collection data provided');
      }

      console.log('Creating collection with name:', collectionName);

      const collectionKey = `learningareas/${collectionName}/.collection`;
      
      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: collectionKey,
        Body: JSON.stringify({
          name: collectionName,
          created: new Date().toISOString(),
          originalData: collectionData,
          ...metadata
        }),
        ContentType: 'application/json',
      });

      await this.s3.send(command);

      // Clear collection cache
      this.localCache.delete('learning_areas');

      return {
        id: collectionName,
        name: collectionName,
        key: collectionKey,
        created: new Date().toISOString(),
        ...metadata
      };

    } catch (error) {
      console.error('Error creating collection:', error);
      throw error;
    }
  }

  async listLearningAreas() {
    const cacheKey = 'learning_areas';
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    console.log("Listing learning areas");
    try {
      const hasAccess = await this.checkBucketAccess();
      if (!hasAccess) {
        throw new Error('Cannot access S3 bucket');
      }

      const command = new ListObjectsV2Command({
        Bucket: this.bucket,
        Prefix: 'learningareas/',
        Delimiter: '/',
        MaxKeys: 1000
      });

      const response = await this.s3.send(command);
      console.log("Learning areas S3 response:", {
        keyCount: response.KeyCount,
        commonPrefixes: response.CommonPrefixes ? response.CommonPrefixes.map(cp => cp.Prefix) : 'none',
        contents: response.Contents ? response.Contents.map(c => c.Key) : 'none'
      });

      const learningAreas = [];

      if (response.CommonPrefixes && response.CommonPrefixes.length > 0) {
        for (const prefix of response.CommonPrefixes) {
          const collectionName = prefix.Prefix.replace('learningareas/', '').replace('/', '');
          
          if (collectionName === '[object Object]') {
            console.warn('Skipping invalid collection name: [object Object]');
            continue;
          }
          
          const videos = await this.listVideos(prefix.Prefix);
          const videoCount = videos.filter(v => 
            !v.key.endsWith('.collection') && 
            !v.key.includes('/thumbnails/') && 
            !v.key.includes('/subtitles/')
          ).length;

          learningAreas.push({
            id: collectionName,
            name: collectionName,
            prefix: prefix.Prefix,
            videoCount: videoCount
          });
        }
      }

      console.log("Valid learning areas found:", learningAreas);
      this.setCache(cacheKey, learningAreas, 300000); // Cache for 5 minutes
      return learningAreas;

    } catch (error) {
      console.error('Error listing learning areas:', error);
      throw error;
    }
  }

  async getLearningArea(collectionName) {
    const cacheKey = `learning_area:${collectionName}`;
    const cached = this.getCache(cacheKey);
    if (cached) return cached;

    try {
      const prefix = `learningareas/${collectionName}/`;
      const videos = await this.listVideos(prefix);
      
      const learningAreaVideos = videos.filter(video => 
        !video.key.endsWith('.collection') && 
        !video.key.includes('/thumbnails/') && 
        !video.key.includes('/subtitles/')
      );

      const learningArea = {
        id: collectionName,
        name: collectionName,
        videoCount: learningAreaVideos.length,
        videos: learningAreaVideos,
        totalSize: learningAreaVideos.reduce((sum, video) => sum + video.size, 0)
      };

      this.setCache(cacheKey, learningArea, 300000);
      return learningArea;

    } catch (error) {
      console.error('Error getting learning area:', error);
      throw error;
    }
  }

  async deleteLearningArea(collectionName) {
    try {
      const prefix = `learningareas/${collectionName}/`;
      const objects = await this.listVideos(prefix);
      
      if (objects.length > 0) {
        await Promise.all(
          objects.map(item => this.deleteVideo(item.key))
        );
      }

      // Clear caches
      this.localCache.delete('learning_areas');
      this.localCache.delete(`learning_area:${collectionName}`);

      return {
        success: true,
        message: `Learning area ${collectionName} deleted successfully`
      };

    } catch (error) {
      console.error('Error deleting learning area:', error);
      throw error;
    }
  }

  // ==================== UTILITY METHODS ====================

  sanitizeCollectionName(collection) {
    if (typeof collection === 'string') {
      return collection.replace(/[^a-zA-Z0-9-_]/g, '_');
    } else if (collection && typeof collection === 'object') {
      if (collection.name && typeof collection.name === 'string') {
        return this.sanitizeCollectionName(collection.name);
      } else if (collection.title && typeof collection.title === 'string') {
        return this.sanitizeCollectionName(collection.title);
      } else if (collection.id && typeof collection.id === 'string') {
        return this.sanitizeCollectionName(collection.id);
      }
    }
    console.warn('Invalid collection format, using default:', collection);
    return 'default_collection';
  }

  getContentType(fileExt) {
    const contentTypes = {
      '.mp4': 'video/mp4',
      '.mov': 'video/quicktime',
      '.avi': 'video/x-msvideo',
      '.mkv': 'video/x-matroska',
      '.webm': 'video/webm',
      '.vtt': 'text/vtt',
      '.srt': 'text/plain',
      '.jpg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
    };

    return contentTypes[fileExt.toLowerCase()] || 'application/octet-stream';
  }

  generateTokenId() {
    return `token_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
  }

  // ==================== PERSISTENCE METHODS ====================

  async uploadJsonToS3(key, jsonData) {
    try {
      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: JSON.stringify(jsonData, null, 2),
        ContentType: 'application/json',
        Metadata: {
          'upload-timestamp': Date.now().toString(),
          'data-type': 'metadata'
        }
      });

      await this.s3.send(command);
      return { success: true, key };
    } catch (error) {
      console.error('Error uploading JSON to S3:', error);
      throw error;
    }
  }

  async getJsonFromS3(key) {
    try {
      const command = new GetObjectCommand({
        Bucket: this.bucket,
        Key: key,
      });

      const response = await this.s3.send(command);
      const jsonString = await response.Body.transformToString();
      return JSON.parse(jsonString);
    } catch (error) {
      if (error.name === 'NoSuchKey') {
        return null;
      }
      console.error('Error getting JSON from S3:', error);
      throw error;
    }
  }

  async listFolders(prefix) {
    try {
      const command = new ListObjectsV2Command({
        Bucket: this.bucket,
        Prefix: prefix,
        Delimiter: '/',
      });

      const response = await this.s3.send(command);
      
      if (!response.CommonPrefixes) {
        return [];
      }

      return response.CommonPrefixes.map(prefix => prefix.Prefix);
    } catch (error) {
      console.error('Error listing folders:', error);
      throw error;
    }
  }

  async deleteFolder(prefix) {
    try {
      const objects = await this.listVideos(prefix);
      
      if (objects.length > 0) {
        await Promise.all(
          objects.map(obj => this.deleteVideo(obj.key))
        );
      }
      
      return { success: true, deleted: objects.length };
    } catch (error) {
      console.error('Error deleting folder:', error);
      throw error;
    }
  }

  // ==================== SECURITY ANALYTICS ====================

  getSecurityAnalytics(timeframe = '7d') {
    const now = Date.now();
    const timeframeMs = timeframe === '24h' ? 86400000 : 604800000;
    
    const recentLogs = this.accessLogs.filter(log => 
      new Date(log.timestamp).getTime() > now - timeframeMs
    );
    
    const recentEvents = this.securityEvents.filter(event => 
      new Date(event.timestamp).getTime() > now - timeframeMs
    );

    const uniqueUsers = new Set(recentLogs.map(log => log.userId)).size;
    const securityEventsByType = recentEvents.reduce((acc, event) => {
      acc[event.eventType] = (acc[event.eventType] || 0) + 1;
      return acc;
    }, {});

    return {
      totalAccess: recentLogs.length,
      uniqueUsers,
      securityEvents: recentEvents.length,
      securityEventsByType,
      cacheStats: this.getCacheStats(),
      activeTokens: this.tokenStore.size,
      pendingLogs: this.accessLogs.length,
      pendingEvents: this.securityEvents.length,
      timeframe
    };
  }

  // ==================== SYSTEM MANAGEMENT ====================

  getSystemStats() {
    return {
      cache: this.getCacheStats(),
      tokens: {
        active: this.tokenStore.size
      },
      logs: {
        accessLogs: this.accessLogs.length,
        securityEvents: this.securityEvents.length
      },
      security: {
        config: this.securityConfig
      }
    };
  }

  updateSecurityConfig(newConfig) {
    this.securityConfig = {
      ...this.securityConfig,
      ...newConfig
    };
    
    console.log('Security configuration updated:', this.securityConfig);
    return this.securityConfig;
  }

  // Graceful shutdown
  async shutdown() {
    console.log('Shutting down S3 service...');
    
    // Flush all pending logs
    await this.flushAccessLogs();
    await this.flushSecurityEvents();
    
    console.log('S3 service shutdown complete');
  }

  // Debug method to clear everything
  async clearAll() {
    this.clearCache();
    this.tokenStore.clear();
    this.accessLogs = [];
    this.securityEvents = [];
    this.videoMetadataCache.clear();
    this.cacheStats = { hits: 0, misses: 0, sets: 0 };
    
    console.log('All local storage cleared');
  }
}

export default new S3CloudFrontService();