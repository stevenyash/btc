// services/learningHierarchyService.js
import DB from '../models/db.js';

class LearningHierarchyService {
  
  // Learning Levels
  async getLearningLevels() {
    try {
      const levels = await DB.LearningLevels.findAll({
        where: { is_active: true },
        order: [['sort_order', 'ASC']],
        raw: true
      });
      return levels;
    } catch (error) {
      console.error('Error getting learning levels:', error);
      throw error;
    }
  }

  // Grades by Level
  async getGradesByLevel(levelId) {
    try {
      const grades = await DB.Grades.findAll({
        where: { 
          level_id: levelId,
          is_active: true 
        },
        order: [['sort_order', 'ASC']],
        raw: true
      });
      return grades;
    } catch (error) {
      console.error('Error getting grades:', error);
      throw error;
    }
  }

  // Learning Areas by Grade
  async getLearningAreasByGrade(gradeId) {
    try {
      const areas = await DB.LearningAreas.findAll({
        where: { 
          grade: gradeId,
          is_active: true 
        },
        order: [['name', 'ASC']],
        raw: true
      });
      return areas;
    } catch (error) {
      console.error('Error getting learning areas:', error);
      throw error;
    }
  }

  // Lessons by Learning Area
  async getLessonsByArea(areaId) {
    try {
      const lessons = await DB.Lessons.findAll({
        where: { 
          area_id: areaId,
          is_active: true 
        },
        order: [['sort_order', 'ASC'], ['title', 'ASC']],
        raw: true
      });
      return lessons;
    } catch (error) {
      console.error('Error getting lessons:', error);
      throw error;
    }
  }

  // Get complete hierarchy
  async getCompleteHierarchy() {
    try {
      const levels = await this.getLearningLevels();
      
      const hierarchy = await Promise.all(
        levels.map(async (level) => {
          const grades = await this.getGradesByLevel(level.level_id);
          
          const gradesWithAreas = await Promise.all(
            grades.map(async (grade) => {
              const areas = await this.getLearningAreasByGrade(grade.id);
              
              const areasWithLessons = await Promise.all(
                areas.map(async (area) => {
                  const lessons = await this.getLessonsByArea(area.id);
                  return {
                    ...area,
                    lessons: lessons
                  };
                })
              );
              
              return {
                ...grade,
                learning_areas: areasWithLessons
              };
            })
          );
          
          return {
            ...level,
            grades: gradesWithAreas
          };
        })
      );
      
      return hierarchy;
    } catch (error) {
      console.error('Error getting complete hierarchy:', error);
      throw error;
    }
  }

  // Search lessons across hierarchy
  async searchLessons(query) {
    try {
      const lessons = await DB.Lessons.findAll({
        where: {
          title: {
            [DB.Op.like]: `%${query}%`
          },
          is_active: true
        },
        order: [['title', 'ASC']],
        raw: true
      });
      
      return lessons;
    } catch (error) {
      console.error('Error searching lessons:', error);
      throw error;
    }
  }

  // Get learning path for navigation
  async getLearningPath(lessonId) {
    try {
      const lesson = await DB.Lessons.findOne({
        where: { id: lessonId },
        raw: true
      });

      if (!lesson) return null;

      const area = await DB.LearningAreas.findOne({
        where: { id: lesson.area_id },
        raw: true
      });

      const grade = await DB.Grades.findOne({
        where: { id: area?.grade },
        raw: true
      });

      const level = await DB.LearningLevels.findOne({
        where: { level_id: grade?.level_id },
        raw: true
      });

      return {
        level: level,
        grade: grade,
        area: area,
        lesson: lesson
      };
    } catch (error) {
      console.error('Error getting learning path:', error);
      throw error;
    }
  }

  // Get popular learning areas (for dashboard)
  async getPopularLearningAreas(limit = 6) {
    try {
      const areas = await DB.LearningAreas.findAll({
        where: { is_active: true },
        order: [['name', 'ASC']],
        limit: limit,
        raw: true
      });
      
      return areas;
    } catch (error) {
      console.error('Error getting popular areas:', error);
      throw error;
    }
  }
}

export default new LearningHierarchyService();