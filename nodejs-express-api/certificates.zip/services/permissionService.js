/**
 * Permission Service
 * 
 * Centralized service for managing permissions across the application.
 * Provides methods for inserting, checking, and managing permissions.
 */

import DB from '../models/db.js';

class PermissionService {
    
    /**
     * Insert a new permission with duplicate checking
     * @param {Object} permissionData - Permission data to insert
     * @returns {Object} Result with success status and the created permission or error
     */
    async insertPermission(permissionData) {
        const { permission, role_id, user_id } = permissionData;
        
        // Normalize the permission name
        const normalizedPermission = permission.trim();
        
        if (!normalizedPermission) {
            return { 
                success: false, 
                error: 'Permission name is required' 
            };
        }
        
        // Check for existing permission
        const existing = await this.findPermission(normalizedPermission, role_id, user_id);
        if (existing) {
            return { 
                success: false, 
                error: 'This permission already exists for the specified role/user',
                existing 
            };
        }
        
        try {
            const newPermission = await DB.Permissions.create({
                permission: normalizedPermission,
                role_id: role_id || null,
                user_id: user_id || null
            });
            
            return { 
                success: true, 
                permission: newPermission 
            };
        } catch (err) {
            return { 
                success: false, 
                error: err.message 
            };
        }
    }
    
    /**
     * Insert multiple permissions at once
     * @param {Array} permissions - Array of permission objects
     * @returns {Object} Result with success status and detailed results
     */
    async insertMultiplePermissions(permissions) {
        const results = {
            success: true,
            created: [],
            duplicates: [],
            errors: []
        };
        
        for (const perm of permissions) {
            const result = await this.insertPermission(perm);
            
            if (result.success) {
                results.created.push({
                    permission: perm.permission,
                    id: result.permission.permission_id
                });
            } else if (result.existing) {
                results.duplicates.push({
                    permission: perm.permission,
                    existing_id: result.existing.permission_id
                });
            } else {
                results.errors.push({
                    permission: perm.permission,
                    error: result.error
                });
                results.success = false;
            }
        }
        
        return results;
    }
    
    /**
     * Find a permission by its attributes
     * @param {string} permission - Permission name
     * @param {number} roleId - Role ID (optional)
     * @param {number} userId - User ID (optional)
     * @returns {Object|null} The found permission or null
     */
    async findPermission(permission, roleId = null, userId = null) {
        const where = { permission: permission.trim() };
        
        if (roleId) where.role_id = roleId;
        if (userId) where.user_id = userId;
        
        return await DB.Permissions.findOne({ where });
    }
    
    /**
     * Find all permissions for a specific role
     * @param {number} roleId - Role ID
     * @returns {Array} Array of permissions
     */
    async findPermissionsByRole(roleId) {
        return await DB.Permissions.findAll({
            where: { role_id: roleId },
            order: [['permission', 'ASC']]
        });
    }
    
    /**
     * Find all permissions for a specific user
     * @param {number} userId - User ID
     * @returns {Array} Array of permissions
     */
    async findPermissionsByUser(userId) {
        return await DB.Permissions.findAll({
            where: { user_id: userId },
            order: [['permission', 'ASC']]
        });
    }
    
    /**
     * Get all unique permission names
     * @returns {Array} Array of unique permission names
     */
    async getAllUniquePermissions() {
        const permissions = await DB.Permissions.findAll({
            attributes: ['permission'],
            group: ['permission'],
            raw: true
        });
        
        return permissions.map(p => p.permission).sort();
    }
    
    /**
     * Check if a permission exists
     * @param {string} permission - Permission name
     * @param {number} roleId - Role ID (optional)
     * @param {number} userId - User ID (optional)
     * @param {number} excludeId - Permission ID to exclude (optional)
     * @returns {boolean} True if exists, false otherwise
     */
    async permissionExists(permission, roleId = null, userId = null, excludeId = null) {
        const where = { permission: permission.trim() };
        
        if (roleId) where.role_id = roleId;
        if (userId) where.user_id = userId;
        if (excludeId) where.permission_id = { [DB.op.ne]: excludeId };
        
        const existing = await DB.Permissions.findOne({ where });
        return !!existing;
    }
    
    /**
     * Delete a permission
     * @param {number} permissionId - Permission ID to delete
     * @returns {Object} Result with success status
     */
    async deletePermission(permissionId) {
        try {
            const deleted = await DB.Permissions.destroy({
                where: { permission_id: permissionId }
            });
            
            return { 
                success: true, 
                deleted: deleted > 0 
            };
        } catch (err) {
            return { 
                success: false, 
                error: err.message 
            };
        }
    }
    
    /**
     * Update a permission
     * @param {number} permissionId - Permission ID to update
     * @param {Object} updates - Fields to update
     * @returns {Object} Result with success status
     */
    async updatePermission(permissionId, updates) {
        try {
            // Check for duplicates if updating permission name
            if (updates.permission) {
                const existing = await this.findPermission(
                    updates.permission,
                    updates.role_id || null,
                    null // Keep current user_id
                );
                
                if (existing && existing.permission_id !== permissionId) {
                    return { 
                        success: false, 
                        error: 'This permission already exists for the specified role' 
                    };
                }
            }
            
            await DB.Permissions.update(updates, {
                where: { permission_id: permissionId }
            });
            
            const updated = await DB.Permissions.findByPk(permissionId);
            
            return { 
                success: true, 
                permission: updated 
            };
        } catch (err) {
            return { 
                success: false, 
                error: err.message 
            };
        }
    }
    
    /**
     * Copy permissions from one role to another
     * @param {number} sourceRoleId - Source role ID
     * @param {number} targetRoleId - Target role ID
     * @returns {Object} Result with success status and copied count
     */
    async copyPermissions(sourceRoleId, targetRoleId) {
        try {
            const sourcePerms = await this.findPermissionsByRole(sourceRoleId);
            
            let copied = 0;
            for (const perm of sourcePerms) {
                const result = await this.insertPermission({
                    permission: perm.permission,
                    role_id: targetRoleId,
                    user_id: null
                });
                
                if (result.success) {
                    copied++;
                }
            }
            
            return { 
                success: true, 
                copied 
            };
        } catch (err) {
            return { 
                success: false, 
                error: err.message 
            };
        }
    }
    
    /**
     * Get permission statistics
     * @returns {Object} Statistics about permissions
     */
    async getStatistics() {
        const [total] = await DB.sequelize.query(
            'SELECT COUNT(*) as count FROM permissions',
            { type: Sequelize.QueryTypes.SELECT }
        );
        
        const [uniqueCount] = await DB.sequelize.query(
            'SELECT COUNT(DISTINCT permission) as count FROM permissions',
            { type: Sequelize.QueryTypes.SELECT }
        );
        
        const [roleCount] = await DB.sequelize.query(
            'SELECT COUNT(DISTINCT role_id) as count FROM permissions WHERE role_id IS NOT NULL',
            { type: Sequelize.QueryTypes.SELECT }
        );
        
        const [userCount] = await DB.sequelize.query(
            'SELECT COUNT(DISTINCT user_id) as count FROM permissions WHERE user_id IS NOT NULL',
            { type: Sequelize.QueryTypes.SELECT }
        );
        
        return {
            total: total.count,
            uniquePermissions: uniqueCount.count,
            rolesWithPermissions: roleCount.count,
            usersWithPermissions: userCount.count
        };
    }
}

// Export singleton instance
export default new PermissionService();
