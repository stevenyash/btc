import s3CloudFrontService from './s3CloudFrontService.js';
import uploader from '../helpers/uploader.js';
import DB from '../models/db.js';

export class FileUploadService {
    constructor(config = {}) {
        this.config = {
            maxRetries: 3,
            retryDelay: 2000,
            ...config
        };
    }

    /**
     * Upload lesson video to S3 with retries
     */
    async uploadLessonToS3WithRetries(filePath, fileName, options = {}) {
        const { maxRetries, retryDelay } = this.config;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                console.log(`Attempt ${attempt} to upload lesson video to S3: ${fileName}`);
                return await s3CloudFrontService.uploadVideo(filePath, fileName, options);
            } catch (error) {
                const isRetryable = error.code === 'ECONNABORTED' || error.code === 'ENOTFOUND' || error.name === 'TimeoutError';
                if (attempt === maxRetries || !isRetryable) {
                    console.error(`S3 upload failed after ${attempt} attempts:`, error.message);
                    throw error;
                }
                console.warn(`Retrying S3 upload in ${retryDelay / 1000} seconds... (${attempt}/${maxRetries})`);
                await new Promise((resolve) => setTimeout(resolve, retryDelay));
            }
        }
    }

    /**
     * Process and upload lesson files
     */
    async processLessonFiles(modeldata, currentRecord = null) {
        const processedData = { ...modeldata };

        // Process video file
        if (processedData.file !== undefined && processedData.file !== '') {
            const fileInfo = uploader.moveUploadedFiles(processedData.file, 'file');
            processedData.file = fileInfo.filepath;
            processedData.filename = fileInfo.filename;
            processedData.file_size = fileInfo.filesize;
        }

        // Process thumbnail
        if (processedData.thumbnail_url !== undefined && processedData.thumbnail_url !== '') {
            const thumbnailInfo = uploader.moveUploadedFiles(processedData.thumbnail_url, 'thumbnail_url');
            processedData.thumbnail_url = thumbnailInfo.filepath;
        }

        return processedData;
    }

    /**
     * Clean up old files
     */
    async cleanupOldFiles(record, fileTypes = ['file', 'thumbnail']) {
        for (const fileType of fileTypes) {
            const fieldName = fileType === 'file' ? 'file' : 'thumbnail_url';
            if (record[fieldName]) {
                try {
                    if (fileType === 'file' && record.s3_key) {
                        await s3CloudFrontService.deleteVideo(record.s3_key);
                    }
                    uploader.deleteRecordFiles(record[fieldName], fileType);
                } catch (error) {
                    console.warn(`Could not delete old ${fileType} file:`, error.message);
                }
            }
        }
    }

    /**
     * Get collection path for S3 organization
     */
    async getCollectionPath(areaId, topicId = null, subtopicId = null) {
        const learningArea = await DB.LearningAreas.findOne({
            where: { id: areaId },
            raw: true
        });

        const grade = learningArea ? await DB.Grades.findOne({
            where: { id: learningArea.grade_id },
            raw: true
        }) : null;

        const level = grade ? await DB.LearningLevels.findOne({
            where: { level_id: grade.level_id },
            raw: true
        }) : null;

        const topic = topicId ? await DB.Topics.findOne({
            where: { topic_id: topicId },
            raw: true
        }) : null;

        const subtopic = subtopicId ? await DB.Subtopics.findOne({
            where: { subtopic_id: subtopicId },
            raw: true
        }) : null;

        return {
            collection: `${level?.name || 'general'}/${grade?.name || 'unknown'}/${learningArea?.name || 'subject'}`,
            topic: topic?.name,
            subtopic: subtopic?.name
        };
    }
}