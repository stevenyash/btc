// services/thumbnailService.js
import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import fs from 'fs';
import uploader from '../helpers/uploader.js';
import s3CloudFrontService from './s3CloudFrontService.js';

class ThumbnailService {
    /**
     * Generate thumbnails from video file
     * @param {string} videoPath - Path to video file
     * @param {string} outputDir - Directory to save thumbnails
     * @param {Object} options - Thumbnail options
     */
    async generateThumbnails(videoPath, outputDir, options = {}) {
        return new Promise((resolve, reject) => {
            const {
                count = 3,
                quality = 8, // 1-31 where 1 is highest quality
                filename = 'thumbnail',
                size = '320x240'
            } = options;

            const thumbnails = [];
            const baseName = path.basename(videoPath, path.extname(videoPath));
            
            // Ensure output directory exists
            if (!fs.existsSync(outputDir)) {
                fs.mkdirSync(outputDir, { recursive: true });
            }

            ffmpeg(videoPath)
                .on('filenames', (filenames) => {
                    console.log('Will generate thumbnails:', filenames);
                })
                .on('end', () => {
                    console.log('Thumbnails generated successfully');
                    resolve(thumbnails);
                })
                .on('error', (err) => {
                    console.error('Error generating thumbnails:', err);
                    reject(err);
                })
                .screenshots({
                    count: count,
                    filename: `${filename}-%i.jpg`,
                    folder: outputDir,
                    size: size,
                    quality: quality
                });
        });
    }

    /**
     * Generate a single thumbnail at specific timestamp
     */
    async generateThumbnailAtTime(videoPath, outputPath, timestamp = '00:00:05') {
        return new Promise((resolve, reject) => {
            ffmpeg(videoPath)
                .screenshots({
                    timestamps: [timestamp],
                    filename: path.basename(outputPath),
                    folder: path.dirname(outputPath),
                    size: '320x240'
                })
                .on('end', () => resolve(outputPath))
                .on('error', reject);
        });
    }

    /**
     * Upload thumbnails to S3
     */
    async uploadThumbnailsToS3(thumbnailPaths, collection, lessonId) {
        const uploadedThumbnails = [];
        
        for (let i = 0; i < thumbnailPaths.length; i++) {
            const thumbPath = thumbnailPaths[i];
            const fileName = `thumbnails/${collection}/lesson-${lessonId}-${i + 1}.jpg`;
            
            try {
                const uploadResult = await s3CloudFrontService.uploadImage(
                    thumbPath,
                    fileName,
                    {
                        collection: collection,
                        visibility: 'public'
                    }
                );
                
                uploadedThumbnails.push({
                    url: uploadResult.url,
                    key: uploadResult.key,
                    size: uploadResult.size,
                    index: i + 1
                });
                
                // Delete local thumbnail after upload
                fs.unlinkSync(thumbPath);
                
            } catch (error) {
                console.error(`Failed to upload thumbnail ${i + 1}:`, error);
            }
        }
        
        return uploadedThumbnails;
    }
}

export default new ThumbnailService();