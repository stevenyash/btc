import express from 'express';
import compression from 'compression';
import cors from 'cors';
import ejs from 'ejs';
import config from './config.js';
import extendExpressMiddleware from './helpers/express_middleware.js';
import { passportJwtLogin, authMiddleware } from './helpers/auth_middleware.js';
import AuthController from './controllers/auth.js';
import AccountController from './controllers/account.js';
import HomeController from './controllers/home.js';
import ComponentsDataController from './controllers/components_data.js';
import FileUploaderController from './controllers/fileuploader.js';
import S3UploaderController from './controllers/s3uploader.js';
import AboutUsController from  './controllers/aboutus.js';
import ActiveSubscriptionsController from  './controllers/activesubscriptions.js';
import AssignRightsController from  './controllers/assignrights.js';
import ContactUsController from  './controllers/contactus.js';
import ExpiredSubscriptionsController from  './controllers/expiredsubscriptions.js';
import GradesController from  './controllers/grades.js';
import GuestTrackerController from  './controllers/guesttracker.js';
import GuestUsersController from  './controllers/guestusers.js';
import InvitesController from  './controllers/invites.js';
import LearningAreasController from  './controllers/learningareas.js';
import LearningLevelsController from  './controllers/learninglevels.js';
import LessonSettingController from  './controllers/lessonsetting.js';
import LessonTrackController from  './controllers/lessontrack.js';
import LessonsController from  './controllers/lessons.js';
import MarketersController from  './controllers/marketers.js';
import MarketerEarningsController from  './controllers/marketer_earnings.js';
import MonthlySubscriptionSummaryController from  './controllers/monthlysubscriptionsummary.js';
import NewsletterSubscribersController from  './controllers/newslettersubscribers.js';
import PackagesController from  './controllers/packages.js';
import PermissionsController from  './controllers/permissions.js';
import PurchasesController from  './controllers/purchases.js';
import QuestionsController from  './controllers/questions.js';
import RightslistController from  './controllers/rightslist.js';
import RolePermissionsController from  './controllers/rolepermissions.js';
import RolesController from  './controllers/roles.js';
import SchedulerController from  './controllers/scheduler.js';
import ServicesSettingsController from  './controllers/servicessettings.js';
import SubscriberTrackerController from  './controllers/subscribertracker.js';
import SubscriptionsController from  './controllers/subscriptions.js';
import SubscriptionsByTypeController from  './controllers/subscriptionsbytype.js';
import SubscriptionsPerUserController from  './controllers/subscriptionsperuser.js';
import SubscriptionsRenewalController from  './controllers/subscriptionsrenewal.js';
import SubscriptionStatusDistributionController from  './controllers/subscriptionstatusdistribution.js';
import SubscriptionTypesController from  './controllers/subscriptiontypes.js';
import SubtopicsController from  './controllers/subtopics.js';
import TopicsController from  './controllers/topics.js';
import TransactionsController from  './controllers/transactions.js';
import TutorialRegisterController from  './controllers/tutorialregister.js';
import TutorialsSettingsController from  './controllers/tutorialssettings.js';
import UserActivityController from  './controllers/useractivity.js';
import UserGuideController from  './controllers/userguide.js';
import UserPrivilegesController from  './controllers/userprivileges.js';
import UsersController from  './controllers/users.js';
import VideosController from  './controllers/videos.js';
import s3SyncController from  './controllers/s3SyncController.js'
import MigrationRoutes from './controllers/migrationroutes.js'
// Import Learning Hierarchy Routes
import LearningHierarchyRoutes from './routes/learningHierarchyRoutes.js';

const app = express();

//set view engine use to return Html
app.set('views', 'views');
app.engine('html', ejs.renderFile);
app.set('view engine', 'ejs');

// compress all responses
app.use(compression({ threshold: 0 }));

//allow cors on localhost
app.use(cors()); // disable when deploy to production

app.use(express.static(config.app.publicDir))
app.use(express.json()) // Parses json, multi-part (file), url-encoded
app.use(express.urlencoded({ extended:true, limit:'50mb' }));

extendExpressMiddleware(app);
app.use(passportJwtLogin);

// OAuth callback route - must be before authMiddleware to allow public access
import { exchangeCodeForTokens } from './helpers/googleMeet.js';
app.get('/oauthcallback', async (req, res) => {
    try {
        const code = req.query.code;
        if (!code) {
            return res.status(400).send('<h1>❌ Authorization Failed</h1><p>No authorization code provided.</p>');
        }
        console.log('OAuth callback: Received authorization code, exchanging for tokens...');
        await exchangeCodeForTokens(code);
        console.log('OAuth callback: Authorization successful!');
        return res.send(`
            <html>
                <head><title>Authorization Successful</title></head>
                <body style="font-family: Arial, sans-serif; padding: 40px; text-align: center;">
                    <h1 style="color: #4caf50;">✅ Authorization Successful!</h1>
                    <p>Google Calendar has been authorized successfully.</p>
                    <p>You can now close this window and try scheduling a class again.</p>
                    <script>setTimeout(() => window.close(), 5000);</script>
                </body>
            </html>
        `);
    } catch (error) {
        console.error('OAuth callback error:', error);
        return res.status(500).send(`<h1>❌ Authorization Failed</h1><p>Error: ${error.message}</p>`);
    }
});

app.use('/api/', authMiddleware);

//bind page route to the controllers

app.use('/api/', HomeController);
app.use('/api/auth', AuthController);
app.use('/api/account', AccountController);
app.use('/api/migrationroutes',MigrationRoutes);
// Learning Hierarchy Routes
app.use('/api/learning-hierarchy', LearningHierarchyRoutes);

// Existing CRUD Routes
app.use('/api/aboutus', AboutUsController);
app.use('/api/activesubscriptions', ActiveSubscriptionsController);
app.use('/api/assignrights', AssignRightsController);
app.use('/api/contactus', ContactUsController);
app.use('/api/expiredsubscriptions', ExpiredSubscriptionsController);
app.use('/api/grades', GradesController);
app.use('/api/guesttracker', GuestTrackerController);
app.use('/api/guestusers', GuestUsersController);
app.use('/api/invites', InvitesController);
app.use('/api/learningareas', LearningAreasController);
app.use('/api/learninglevels', LearningLevelsController);
app.use('/api/lessonsetting', LessonSettingController);
app.use('/api/lessontrack', LessonTrackController);
app.use('/api/lessons', LessonsController);
app.use('/api/marketers', MarketersController);
app.use('/api/marketer_earnings', MarketerEarningsController);
app.use('/api/monthlysubscriptionsummary', MonthlySubscriptionSummaryController);
app.use('/api/newslettersubscribers', NewsletterSubscribersController);
app.use('/api/packages', PackagesController);
app.use('/api/permissions', PermissionsController);
app.use('/api/purchases', PurchasesController);
app.use('/api/questions', QuestionsController);
app.use('/api/rightslist', RightslistController);
app.use('/api/rolepermissions', RolePermissionsController);
app.use('/api/roles', RolesController);
app.use('/api/scheduler', SchedulerController);
app.use('/api/servicessettings', ServicesSettingsController);
app.use('/api/subscribertracker', SubscriberTrackerController);
app.use('/api/subscriptions', SubscriptionsController);
app.use('/api/subscriptionsbytype', SubscriptionsByTypeController);
app.use('/api/subscriptionsperuser', SubscriptionsPerUserController);
app.use('/api/subscriptionsrenewal', SubscriptionsRenewalController);
app.use('/api/subscriptionstatusdistribution', SubscriptionStatusDistributionController);
app.use('/api/subscriptiontypes', SubscriptionTypesController);
app.use('/api/subtopics', SubtopicsController);
app.use('/api/topics', TopicsController);
app.use('/api/transactions', TransactionsController);
app.use('/api/tutorialregister', TutorialRegisterController);
app.use('/api/tutorialssettings', TutorialsSettingsController);
app.use('/api/useractivity', UserActivityController);
app.use('/api/userguide', UserGuideController);
app.use('/api/userprivileges', UserPrivilegesController);
app.use('/api/users', UsersController);
app.use('/api/videos', VideosController);
app.use('/api/components_data', ComponentsDataController);
app.use('/api/fileuploader', FileUploaderController);
app.use('/api/s3uploader', S3UploaderController);
app.use('/api/s3Sync',s3SyncController)
app.get('*', function(req, res){
    res.status(404).json("Page not found");
});

let port = 8060;

//start app
app.listen(port, () => {
    console.log('Server is up and running on port: ' + port);
    console.log('Learning Hierarchy API available at: /api/learning-hierarchy');
});